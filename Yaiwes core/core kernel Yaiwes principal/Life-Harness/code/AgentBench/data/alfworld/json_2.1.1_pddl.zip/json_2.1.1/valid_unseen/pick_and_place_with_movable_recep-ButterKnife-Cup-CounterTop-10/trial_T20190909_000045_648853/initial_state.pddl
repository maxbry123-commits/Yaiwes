
(define (problem plan_trial_T20190909_000045_648853)
(:domain alfred)
(:objects
agent1 - agent
RemoteControl - object
        Laptop - object
        Kettle - object
        Pen - object
        Fork - object
        Cloth - object
        HousePlant - object
        Plunger - object
        SoapBottle - object
        Cup - object
        Candle - object
        Tomato - object
        Television - object
        TennisRacket - object
        Towel - object
        SaltShaker - object
        Spoon - object
        Apple - object
        Poster - object
        Curtains - object
        Footstool - object
        AlarmClock - object
        Ladle - object
        PaperTowelRoll - object
        BaseballBat - object
        Knife - object
        Spatula - object
        SoapBar - object
        CreditCard - object
        Sink - object
        Newspaper - object
        LaundryHamperLid - object
        KeyChain - object
        Glassbottle - object
        ButterKnife - object
        Chair - object
        HandTowel - object
        ToiletPaperRoll - object
        Plate - object
        Pot - object
        WineBottle - object
        Boots - object
        PepperShaker - object
        PaperTowel - object
        Bowl - object
        SprayBottle - object
        ScrubBrush - object
        Box - object
        CD - object
        Pan - object
        Statue - object
        Vase - object
        ShowerGlass - object
        DishSponge - object
        Egg - object
        Lettuce - object
        Book - object
        TeddyBear - object
        ToiletPaper - object
        ShowerDoor - object
        Window - object
        Blinds - object
        CellPhone - object
        FloorLamp - object
        Pillow - object
        Mirror - object
        Painting - object
        TissueBox - object
        Pencil - object
        Potato - object
        LightSwitch - object
        StoveKnob - object
        Mug - object
        Bathtub - object
        DeskLamp - object
        Watch - object
        WateringCan - object
        BasketBall - object
        Bread - object
RemoteControlType - otype
        LaptopType - otype
        KettleType - otype
        PenType - otype
        ForkType - otype
        ClothType - otype
        HousePlantType - otype
        PlungerType - otype
        SoapBottleType - otype
        CupType - otype
        CandleType - otype
        TomatoType - otype
        TelevisionType - otype
        TennisRacketType - otype
        TowelType - otype
        SaltShakerType - otype
        SpoonType - otype
        AppleType - otype
        PosterType - otype
        CurtainsType - otype
        FootstoolType - otype
        AlarmClockType - otype
        LadleType - otype
        PaperTowelRollType - otype
        BaseballBatType - otype
        KnifeType - otype
        SpatulaType - otype
        SoapBarType - otype
        CreditCardType - otype
        SinkType - otype
        NewspaperType - otype
        LaundryHamperLidType - otype
        KeyChainType - otype
        GlassbottleType - otype
        ButterKnifeType - otype
        ChairType - otype
        HandTowelType - otype
        ToiletPaperRollType - otype
        PlateType - otype
        PotType - otype
        WineBottleType - otype
        BootsType - otype
        PepperShakerType - otype
        PaperTowelType - otype
        BowlType - otype
        SprayBottleType - otype
        ScrubBrushType - otype
        BoxType - otype
        CDType - otype
        PanType - otype
        StatueType - otype
        VaseType - otype
        ShowerGlassType - otype
        DishSpongeType - otype
        EggType - otype
        LettuceType - otype
        BookType - otype
        TeddyBearType - otype
        ToiletPaperType - otype
        ShowerDoorType - otype
        WindowType - otype
        BlindsType - otype
        CellPhoneType - otype
        FloorLampType - otype
        PillowType - otype
        MirrorType - otype
        PaintingType - otype
        TissueBoxType - otype
        PencilType - otype
        PotatoType - otype
        LightSwitchType - otype
        StoveKnobType - otype
        MugType - otype
        BathtubType - otype
        DeskLampType - otype
        WatchType - otype
        WateringCanType - otype
        BasketBallType - otype
        BreadType - otype
SinkBasinType - rtype
        GarbageCanType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype
        CabinetType - rtype
        SideTableType - rtype
        DiningTableType - rtype
        CoffeeTableType - rtype
        SafeType - rtype
        DresserType - rtype
        DeskType - rtype
        BedType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        MicrowaveType - rtype
        SofaType - rtype
        CartType - rtype
        ArmChairType - rtype
        HandTowelHolderType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CoffeeMachineType - rtype
        ToasterType - rtype
        LaundryHamperType - rtype
        DrawerType - rtype
        FridgeType - rtype
        ToiletType - rtype
        ShelfType - rtype
        PaintingHangerType - rtype
        CounterTopType - rtype


        Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25 - object
        Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54 - object
        Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13 - object
        Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44 - object
        Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73 - object
        ButterKnife_bar__minus_01_dot_23_bar__plus_00_dot_93_bar__minus_00_dot_38 - object
        ButterKnife_bar__minus_01_dot_29_bar__plus_00_dot_93_bar__minus_00_dot_91 - object
        CellPhone_bar__plus_00_dot_79_bar__plus_00_dot_70_bar__minus_00_dot_69 - object
        CellPhone_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__plus_00_dot_14 - object
        CellPhone_bar__minus_01_dot_47_bar__plus_00_dot_55_bar__plus_02_dot_72 - object
        Chair_bar__minus_01_dot_90_bar__plus_00_dot_00_bar__minus_01_dot_00 - object
        Chair_bar__minus_01_dot_93_bar__plus_00_dot_00_bar__minus_00_dot_03 - object
        CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_01_dot_97 - object
        CreditCard_bar__plus_00_dot_92_bar__plus_00_dot_49_bar__minus_00_dot_69 - object
        Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08 - object
        Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92 - object
        Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83 - object
        DishSponge_bar__plus_00_dot_91_bar__plus_00_dot_15_bar__minus_00_dot_73 - object
        DishSponge_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_73 - object
        DishSponge_bar__plus_01_dot_20_bar__plus_00_dot_91_bar__minus_00_dot_73 - object
        Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54 - object
        Faucet_bar__minus_00_dot_87_bar__plus_01_dot_16_bar__minus_00_dot_65 - object
        Fork_bar__plus_00_dot_79_bar__plus_00_dot_49_bar__minus_00_dot_65 - object
        Fork_bar__plus_00_dot_88_bar__plus_00_dot_49_bar__minus_00_dot_77 - object
        Fork_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_38 - object
        Glassbottle_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_41 - object
        HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 - object
        Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_03 - object
        Knife_bar__minus_00_dot_70_bar__plus_00_dot_96_bar__minus_01_dot_46 - object
        Knife_bar__minus_01_dot_10_bar__plus_00_dot_96_bar__minus_01_dot_17 - object
        Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56 - object
        LightSwitch_bar__minus_02_dot_37_bar__plus_01_dot_22_bar__plus_03_dot_05 - object
        Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37 - object
        Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34 - object
        Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66 - object
        Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35 - object
        PaperTowelRoll_bar__minus_00_dot_48_bar__plus_01_dot_04_bar__plus_00_dot_32 - object
        PepperShaker_bar__minus_01_dot_88_bar__plus_00_dot_55_bar__plus_02_dot_62 - object
        Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15 - object
        Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12 - object
        Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79 - object
        Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50 - object
        SaltShaker_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_77 - object
        SaltShaker_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_01_dot_88 - object
        SaltShaker_bar__plus_01_dot_19_bar__plus_01_dot_66_bar__minus_00_dot_59 - object
        Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65 - object
        SoapBottle_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__minus_01_dot_39 - object
        Spatula_bar__plus_00_dot_75_bar__plus_00_dot_72_bar__minus_00_dot_61 - object
        Spatula_bar__plus_01_dot_11_bar__plus_00_dot_93_bar__minus_00_dot_21 - object
        Spatula_bar__minus_00_dot_81_bar__plus_00_dot_80_bar__minus_00_dot_75 - object
        Spoon_bar__plus_00_dot_79_bar__plus_00_dot_16_bar__minus_00_dot_65 - object
        Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_09 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_24 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_37 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_52 - object
        Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97 - object
        Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58 - object
        Vase_bar__plus_01_dot_10_bar__plus_01_dot_67_bar__minus_02_dot_03 - object
        Vase_bar__minus_01_dot_42_bar__plus_00_dot_17_bar__plus_02_dot_62 - object
        Window_bar__plus_00_dot_02_bar__plus_01_dot_00_bar__minus_02_dot_64 - object
        Window_bar__minus_03_dot_00_bar__plus_01_dot_00_bar__minus_02_dot_64 - object
        Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24 - receptacle
        Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78 - receptacle
        CoffeeMachine_bar__plus_01_dot_02_bar__plus_00_dot_90_bar__minus_02_dot_18 - receptacle
        CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21 - receptacle
        CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05 - receptacle
        CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64 - receptacle
        Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65 - receptacle
        Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65 - receptacle
        Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65 - receptacle
        Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25 - receptacle
        GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58 - receptacle
        Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30 - receptacle
        Shelf_bar__minus_01_dot_69_bar__plus_00_dot_16_bar__plus_02_dot_72 - receptacle
        Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72 - receptacle
        Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72 - receptacle
        Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin - receptacle
        StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_10 - receptacle
        StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50 - receptacle
        StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_10 - receptacle
        StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50 - receptacle
        Toaster_bar__plus_00_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_33 - receptacle
        loc_bar__minus_10_bar_0_bar_1_bar_60 - location
        loc_bar_1_bar__minus_1_bar_1_bar_45 - location
        loc_bar__minus_3_bar__minus_8_bar_0_bar_30 - location
        loc_bar_1_bar__minus_7_bar_1_bar__minus_30 - location
        loc_bar_1_bar__minus_4_bar_1_bar_45 - location
        loc_bar_0_bar__minus_3_bar_3_bar_45 - location
        loc_bar_1_bar__minus_6_bar_1_bar_60 - location
        loc_bar_0_bar_4_bar_3_bar_60 - location
        loc_bar_1_bar_1_bar_1_bar_45 - location
        loc_bar_0_bar_5_bar_1_bar_60 - location
        loc_bar_1_bar__minus_8_bar_1_bar_45 - location
        loc_bar_1_bar__minus_5_bar_1_bar_60 - location
        loc_bar_1_bar__minus_8_bar_1_bar__minus_30 - location
        loc_bar_1_bar__minus_3_bar_1_bar__minus_30 - location
        loc_bar_0_bar__minus_6_bar_0_bar_45 - location
        loc_bar_1_bar__minus_1_bar_1_bar__minus_30 - location
        loc_bar__minus_6_bar_6_bar_0_bar_45 - location
        loc_bar_1_bar__minus_4_bar_1_bar_60 - location
        loc_bar__minus_1_bar_3_bar_1_bar_60 - location
        loc_bar_0_bar__minus_6_bar_0_bar_60 - location
        loc_bar_1_bar__minus_6_bar_1_bar_45 - location
        loc_bar_0_bar__minus_8_bar_1_bar_60 - location
        loc_bar__minus_9_bar__minus_3_bar_1_bar_60 - location
        loc_bar_1_bar__minus_5_bar_1_bar_0 - location
        loc_bar__minus_10_bar_10_bar_0_bar_45 - location
        loc_bar__minus_9_bar_7_bar_0_bar_45 - location
        loc_bar_0_bar__minus_4_bar_1_bar_60 - location
        loc_bar__minus_12_bar__minus_8_bar_2_bar_45 - location
        loc_bar__minus_9_bar_6_bar_0_bar_45 - location
        loc_bar_0_bar__minus_8_bar_2_bar_45 - location
        loc_bar__minus_13_bar__minus_4_bar_0_bar_30 - location
        )
    

(:init


        (receptacleType Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30 MicrowaveType)
        (receptacleType Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65 DrawerType)
        (receptacleType Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72 ShelfType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76 CabinetType)
        (receptacleType Shelf_bar__minus_01_dot_69_bar__plus_00_dot_16_bar__plus_02_dot_72 ShelfType)
        (receptacleType Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24 CabinetType)
        (receptacleType StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_10 StoveBurnerType)
        (receptacleType CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21 CounterTopType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14 CabinetType)
        (receptacleType Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72 CabinetType)
        (receptacleType StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_10 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78 CabinetType)
        (receptacleType Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65 DrawerType)
        (receptacleType CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64 CounterTopType)
        (receptacleType CoffeeMachine_bar__plus_01_dot_02_bar__plus_00_dot_90_bar__minus_02_dot_18 CoffeeMachineType)
        (receptacleType StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38 CabinetType)
        (receptacleType Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin SinkBasinType)
        (receptacleType GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58 GarbageCanType)
        (receptacleType CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05 CounterTopType)
        (receptacleType StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50 StoveBurnerType)
        (receptacleType Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25 FridgeType)
        (receptacleType Toaster_bar__plus_00_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_33 ToasterType)
        (receptacleType Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72 ShelfType)
        (receptacleType Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65 DrawerType)
        (objectType HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 HousePlantType)
        (objectType CellPhone_bar__minus_01_dot_47_bar__plus_00_dot_55_bar__plus_02_dot_72 CellPhoneType)
        (objectType Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37 MugType)
        (objectType SaltShaker_bar__plus_01_dot_19_bar__plus_01_dot_66_bar__minus_00_dot_59 SaltShakerType)
        (objectType Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79 PotatoType)
        (objectType Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35 PanType)
        (objectType Spoon_bar__plus_00_dot_79_bar__plus_00_dot_16_bar__minus_00_dot_65 SpoonType)
        (objectType Spatula_bar__plus_00_dot_75_bar__plus_00_dot_72_bar__minus_00_dot_61 SpatulaType)
        (objectType Window_bar__plus_00_dot_02_bar__plus_01_dot_00_bar__minus_02_dot_64 WindowType)
        (objectType PaperTowelRoll_bar__minus_00_dot_48_bar__plus_01_dot_04_bar__plus_00_dot_32 PaperTowelRollType)
        (objectType ButterKnife_bar__minus_01_dot_23_bar__plus_00_dot_93_bar__minus_00_dot_38 ButterKnifeType)
        (objectType Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58 TomatoType)
        (objectType Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66 MugType)
        (objectType Chair_bar__minus_01_dot_90_bar__plus_00_dot_00_bar__minus_01_dot_00 ChairType)
        (objectType Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12 PlateType)
        (objectType Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92 CupType)
        (objectType Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54 AppleType)
        (objectType Knife_bar__minus_01_dot_10_bar__plus_00_dot_96_bar__minus_01_dot_17 KnifeType)
        (objectType Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97 TomatoType)
        (objectType CellPhone_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__plus_00_dot_14 CellPhoneType)
        (objectType Fork_bar__plus_00_dot_88_bar__plus_00_dot_49_bar__minus_00_dot_77 ForkType)
        (objectType CellPhone_bar__plus_00_dot_79_bar__plus_00_dot_70_bar__minus_00_dot_69 CellPhoneType)
        (objectType DishSponge_bar__plus_00_dot_91_bar__plus_00_dot_15_bar__minus_00_dot_73 DishSpongeType)
        (objectType CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_01_dot_97 CreditCardType)
        (objectType Vase_bar__minus_01_dot_42_bar__plus_00_dot_17_bar__plus_02_dot_62 VaseType)
        (objectType Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25 AppleType)
        (objectType Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56 LettuceType)
        (objectType Vase_bar__plus_01_dot_10_bar__plus_01_dot_67_bar__minus_02_dot_03 VaseType)
        (objectType Knife_bar__minus_00_dot_70_bar__plus_00_dot_96_bar__minus_01_dot_46 KnifeType)
        (objectType Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73 BreadType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_52 StoveKnobType)
        (objectType SaltShaker_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_77 SaltShakerType)
        (objectType Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15 PlateType)
        (objectType CreditCard_bar__plus_00_dot_92_bar__plus_00_dot_49_bar__minus_00_dot_69 CreditCardType)
        (objectType Spatula_bar__minus_00_dot_81_bar__plus_00_dot_80_bar__minus_00_dot_75 SpatulaType)
        (objectType Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_03 KnifeType)
        (objectType Fork_bar__plus_00_dot_79_bar__plus_00_dot_49_bar__minus_00_dot_65 ForkType)
        (objectType SaltShaker_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_01_dot_88 SaltShakerType)
        (objectType ButterKnife_bar__minus_01_dot_29_bar__plus_00_dot_93_bar__minus_00_dot_91 ButterKnifeType)
        (objectType Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13 AppleType)
        (objectType DishSponge_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_73 DishSpongeType)
        (objectType PepperShaker_bar__minus_01_dot_88_bar__plus_00_dot_55_bar__plus_02_dot_62 PepperShakerType)
        (objectType Glassbottle_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_41 GlassbottleType)
        (objectType LightSwitch_bar__minus_02_dot_37_bar__plus_01_dot_22_bar__plus_03_dot_05 LightSwitchType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_37 StoveKnobType)
        (objectType Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50 PotType)
        (objectType Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65 SinkType)
        (objectType DishSponge_bar__plus_01_dot_20_bar__plus_00_dot_91_bar__minus_00_dot_73 DishSpongeType)
        (objectType Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08 CupType)
        (objectType Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34 MugType)
        (objectType Chair_bar__minus_01_dot_93_bar__plus_00_dot_00_bar__minus_00_dot_03 ChairType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_09 StoveKnobType)
        (objectType Fork_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_38 ForkType)
        (objectType SoapBottle_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__minus_01_dot_39 SoapBottleType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_24 StoveKnobType)
        (objectType Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44 BowlType)
        (objectType Window_bar__minus_03_dot_00_bar__plus_01_dot_00_bar__minus_02_dot_64 WindowType)
        (objectType Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54 EggType)
        (objectType Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 StatueType)
        (objectType Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83 CupType)
        (objectType Spatula_bar__plus_01_dot_11_bar__plus_00_dot_93_bar__minus_00_dot_21 SpatulaType)
        (canContain MicrowaveType AppleType)
        (canContain MicrowaveType GlassbottleType)
        (canContain MicrowaveType MugType)
        (canContain MicrowaveType TomatoType)
        (canContain MicrowaveType BowlType)
        (canContain MicrowaveType CupType)
        (canContain MicrowaveType PlateType)
        (canContain MicrowaveType EggType)
        (canContain MicrowaveType PotatoType)
        (canContain MicrowaveType BreadType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType DishSpongeType)
        (canContain ShelfType PepperShakerType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType SoapBottleType)
        (canContain ShelfType CupType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType StatueType)
        (canContain ShelfType SaltShakerType)
        (canContain ShelfType VaseType)
        (canContain ShelfType GlassbottleType)
        (canContain ShelfType MugType)
        (canContain ShelfType PlateType)
        (canContain ShelfType DishSpongeType)
        (canContain ShelfType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain ShelfType PepperShakerType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType SoapBottleType)
        (canContain ShelfType CupType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType StatueType)
        (canContain ShelfType SaltShakerType)
        (canContain ShelfType VaseType)
        (canContain ShelfType GlassbottleType)
        (canContain ShelfType MugType)
        (canContain ShelfType PlateType)
        (canContain ShelfType DishSpongeType)
        (canContain ShelfType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType SpatulaType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType CreditCardType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType StatueType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType VaseType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType GlassbottleType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType BreadType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType DishSpongeType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType SpatulaType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType CreditCardType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType StatueType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType VaseType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType GlassbottleType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType BreadType)
        (canContain CoffeeMachineType MugType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain SinkBasinType ForkType)
        (canContain SinkBasinType KnifeType)
        (canContain SinkBasinType BowlType)
        (canContain SinkBasinType SpatulaType)
        (canContain SinkBasinType CupType)
        (canContain SinkBasinType TomatoType)
        (canContain SinkBasinType PanType)
        (canContain SinkBasinType PotatoType)
        (canContain SinkBasinType SpoonType)
        (canContain SinkBasinType AppleType)
        (canContain SinkBasinType GlassbottleType)
        (canContain SinkBasinType MugType)
        (canContain SinkBasinType ButterKnifeType)
        (canContain SinkBasinType PlateType)
        (canContain SinkBasinType DishSpongeType)
        (canContain SinkBasinType EggType)
        (canContain SinkBasinType PotType)
        (canContain SinkBasinType LettuceType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType TomatoType)
        (canContain GarbageCanType PotatoType)
        (canContain GarbageCanType AppleType)
        (canContain GarbageCanType BreadType)
        (canContain GarbageCanType DishSpongeType)
        (canContain GarbageCanType EggType)
        (canContain GarbageCanType LettuceType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType SpatulaType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType CreditCardType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType StatueType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType VaseType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType GlassbottleType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType BreadType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain FridgeType BowlType)
        (canContain FridgeType CupType)
        (canContain FridgeType TomatoType)
        (canContain FridgeType PanType)
        (canContain FridgeType PotatoType)
        (canContain FridgeType AppleType)
        (canContain FridgeType GlassbottleType)
        (canContain FridgeType MugType)
        (canContain FridgeType PlateType)
        (canContain FridgeType BreadType)
        (canContain FridgeType EggType)
        (canContain FridgeType PotType)
        (canContain FridgeType LettuceType)
        (canContain ShelfType PepperShakerType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType SoapBottleType)
        (canContain ShelfType CupType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType StatueType)
        (canContain ShelfType SaltShakerType)
        (canContain ShelfType VaseType)
        (canContain ShelfType GlassbottleType)
        (canContain ShelfType MugType)
        (canContain ShelfType PlateType)
        (canContain ShelfType DishSpongeType)
        (canContain ShelfType PotType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType DishSpongeType)
        (pickupable CellPhone_bar__minus_01_dot_47_bar__plus_00_dot_55_bar__plus_02_dot_72)
        (pickupable Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37)
        (pickupable SaltShaker_bar__plus_01_dot_19_bar__plus_01_dot_66_bar__minus_00_dot_59)
        (pickupable Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79)
        (pickupable Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35)
        (pickupable Spoon_bar__plus_00_dot_79_bar__plus_00_dot_16_bar__minus_00_dot_65)
        (pickupable Spatula_bar__plus_00_dot_75_bar__plus_00_dot_72_bar__minus_00_dot_61)
        (pickupable PaperTowelRoll_bar__minus_00_dot_48_bar__plus_01_dot_04_bar__plus_00_dot_32)
        (pickupable ButterKnife_bar__minus_01_dot_23_bar__plus_00_dot_93_bar__minus_00_dot_38)
        (pickupable Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58)
        (pickupable Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66)
        (pickupable Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12)
        (pickupable Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92)
        (pickupable Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54)
        (pickupable Knife_bar__minus_01_dot_10_bar__plus_00_dot_96_bar__minus_01_dot_17)
        (pickupable Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97)
        (pickupable CellPhone_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__plus_00_dot_14)
        (pickupable Fork_bar__plus_00_dot_88_bar__plus_00_dot_49_bar__minus_00_dot_77)
        (pickupable CellPhone_bar__plus_00_dot_79_bar__plus_00_dot_70_bar__minus_00_dot_69)
        (pickupable DishSponge_bar__plus_00_dot_91_bar__plus_00_dot_15_bar__minus_00_dot_73)
        (pickupable CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_01_dot_97)
        (pickupable Vase_bar__minus_01_dot_42_bar__plus_00_dot_17_bar__plus_02_dot_62)
        (pickupable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25)
        (pickupable Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56)
        (pickupable Vase_bar__plus_01_dot_10_bar__plus_01_dot_67_bar__minus_02_dot_03)
        (pickupable Knife_bar__minus_00_dot_70_bar__plus_00_dot_96_bar__minus_01_dot_46)
        (pickupable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73)
        (pickupable SaltShaker_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_77)
        (pickupable Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15)
        (pickupable CreditCard_bar__plus_00_dot_92_bar__plus_00_dot_49_bar__minus_00_dot_69)
        (pickupable Spatula_bar__minus_00_dot_81_bar__plus_00_dot_80_bar__minus_00_dot_75)
        (pickupable Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_03)
        (pickupable Fork_bar__plus_00_dot_79_bar__plus_00_dot_49_bar__minus_00_dot_65)
        (pickupable SaltShaker_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_01_dot_88)
        (pickupable ButterKnife_bar__minus_01_dot_29_bar__plus_00_dot_93_bar__minus_00_dot_91)
        (pickupable Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13)
        (pickupable DishSponge_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_73)
        (pickupable PepperShaker_bar__minus_01_dot_88_bar__plus_00_dot_55_bar__plus_02_dot_62)
        (pickupable Glassbottle_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_41)
        (pickupable Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (pickupable DishSponge_bar__plus_01_dot_20_bar__plus_00_dot_91_bar__minus_00_dot_73)
        (pickupable Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08)
        (pickupable Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34)
        (pickupable Fork_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_38)
        (pickupable SoapBottle_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__minus_01_dot_39)
        (pickupable Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44)
        (pickupable Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54)
        (pickupable Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75)
        (pickupable Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83)
        (pickupable Spatula_bar__plus_01_dot_11_bar__plus_00_dot_93_bar__minus_00_dot_21)
        (isReceptacleObject Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37)
        (isReceptacleObject Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35)
        (isReceptacleObject Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66)
        (isReceptacleObject Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12)
        (isReceptacleObject Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92)
        (isReceptacleObject Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15)
        (isReceptacleObject Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (isReceptacleObject Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08)
        (isReceptacleObject Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34)
        (isReceptacleObject Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44)
        (isReceptacleObject Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83)
        (openable Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30)
        (openable Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65)
        (openable Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24)
        (openable Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72)
        (openable Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65)
        (openable Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38)
        (openable Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (openable Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65)
        
        (atLocation agent1 loc_bar__minus_13_bar__minus_4_bar_0_bar_30)
        
        (cleanable Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37)
        (cleanable Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79)
        (cleanable Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35)
        (cleanable Spoon_bar__plus_00_dot_79_bar__plus_00_dot_16_bar__minus_00_dot_65)
        (cleanable Spatula_bar__plus_00_dot_75_bar__plus_00_dot_72_bar__minus_00_dot_61)
        (cleanable ButterKnife_bar__minus_01_dot_23_bar__plus_00_dot_93_bar__minus_00_dot_38)
        (cleanable Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58)
        (cleanable Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66)
        (cleanable Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12)
        (cleanable Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92)
        (cleanable Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54)
        (cleanable Knife_bar__minus_01_dot_10_bar__plus_00_dot_96_bar__minus_01_dot_17)
        (cleanable Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97)
        (cleanable Fork_bar__plus_00_dot_88_bar__plus_00_dot_49_bar__minus_00_dot_77)
        (cleanable DishSponge_bar__plus_00_dot_91_bar__plus_00_dot_15_bar__minus_00_dot_73)
        (cleanable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25)
        (cleanable Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56)
        (cleanable Knife_bar__minus_00_dot_70_bar__plus_00_dot_96_bar__minus_01_dot_46)
        (cleanable Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15)
        (cleanable Spatula_bar__minus_00_dot_81_bar__plus_00_dot_80_bar__minus_00_dot_75)
        (cleanable Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_03)
        (cleanable Fork_bar__plus_00_dot_79_bar__plus_00_dot_49_bar__minus_00_dot_65)
        (cleanable ButterKnife_bar__minus_01_dot_29_bar__plus_00_dot_93_bar__minus_00_dot_91)
        (cleanable Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13)
        (cleanable DishSponge_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_73)
        (cleanable Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (cleanable DishSponge_bar__plus_01_dot_20_bar__plus_00_dot_91_bar__minus_00_dot_73)
        (cleanable Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08)
        (cleanable Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34)
        (cleanable Fork_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_38)
        (cleanable Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44)
        (cleanable Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54)
        (cleanable Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83)
        (cleanable Spatula_bar__plus_01_dot_11_bar__plus_00_dot_93_bar__minus_00_dot_21)
        
        (heatable Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37)
        (heatable Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79)
        (heatable Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58)
        (heatable Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66)
        (heatable Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12)
        (heatable Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92)
        (heatable Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54)
        (heatable Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97)
        (heatable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25)
        (heatable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73)
        (heatable Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15)
        (heatable Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13)
        (heatable Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08)
        (heatable Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34)
        (heatable Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54)
        (heatable Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83)
        (coolable Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37)
        (coolable Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79)
        (coolable Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35)
        (coolable Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58)
        (coolable Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66)
        (coolable Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12)
        (coolable Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92)
        (coolable Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54)
        (coolable Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97)
        (coolable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25)
        (coolable Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56)
        (coolable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73)
        (coolable Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15)
        (coolable Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13)
        (coolable Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (coolable Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08)
        (coolable Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34)
        (coolable Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44)
        (coolable Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54)
        (coolable Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83)
        
        
        
        
        
        (sliceable Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79)
        (sliceable Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58)
        (sliceable Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54)
        (sliceable Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97)
        (sliceable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25)
        (sliceable Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56)
        (sliceable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73)
        (sliceable Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13)
        (sliceable Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54)
        
        (inReceptacle Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37 Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24)
        (inReceptacle Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50 StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50)
        (inReceptacle Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50 StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50)
        (inReceptacle Spatula_bar__plus_00_dot_75_bar__plus_00_dot_72_bar__minus_00_dot_61 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65)
        (inReceptacle CellPhone_bar__plus_00_dot_79_bar__plus_00_dot_70_bar__minus_00_dot_69 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65)
        (inReceptacle SaltShaker_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_77 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65)
        (inReceptacle Vase_bar__plus_01_dot_10_bar__plus_01_dot_67_bar__minus_02_dot_03 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38)
        (inReceptacle HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle SoapBottle_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__minus_01_dot_39 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle PaperTowelRoll_bar__minus_00_dot_48_bar__plus_01_dot_04_bar__plus_00_dot_32 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Knife_bar__minus_00_dot_70_bar__plus_00_dot_96_bar__minus_01_dot_46 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle ButterKnife_bar__minus_01_dot_23_bar__plus_00_dot_93_bar__minus_00_dot_38 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Knife_bar__minus_01_dot_10_bar__plus_00_dot_96_bar__minus_01_dot_17 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle ButterKnife_bar__minus_01_dot_29_bar__plus_00_dot_93_bar__minus_00_dot_91 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle DishSponge_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_73 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Fork_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_38 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle DishSponge_bar__plus_01_dot_20_bar__plus_00_dot_91_bar__minus_00_dot_73 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_03 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Spatula_bar__plus_01_dot_11_bar__plus_00_dot_93_bar__minus_00_dot_21 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle CellPhone_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__plus_00_dot_14 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle DishSponge_bar__plus_00_dot_91_bar__plus_00_dot_15_bar__minus_00_dot_73 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65)
        (inReceptacle Spoon_bar__plus_00_dot_79_bar__plus_00_dot_16_bar__minus_00_dot_65 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65)
        (inReceptacle Fork_bar__plus_00_dot_88_bar__plus_00_dot_49_bar__minus_00_dot_77 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65)
        (inReceptacle CreditCard_bar__plus_00_dot_92_bar__plus_00_dot_49_bar__minus_00_dot_69 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65)
        (inReceptacle Fork_bar__plus_00_dot_79_bar__plus_00_dot_49_bar__minus_00_dot_65 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65)
        (inReceptacle CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_01_dot_97 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05)
        (inReceptacle Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05)
        (inReceptacle SaltShaker_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_01_dot_88 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05)
        (inReceptacle Glassbottle_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_41 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78)
        (inReceptacle Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78)
        (inReceptacle Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14)
        (inReceptacle SaltShaker_bar__plus_01_dot_19_bar__plus_01_dot_66_bar__minus_00_dot_59 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76)
        (inReceptacle Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72)
        (inReceptacle CellPhone_bar__minus_01_dot_47_bar__plus_00_dot_55_bar__plus_02_dot_72 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72)
        (inReceptacle PepperShaker_bar__minus_01_dot_88_bar__plus_00_dot_55_bar__plus_02_dot_62 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72)
        (inReceptacle Vase_bar__minus_01_dot_42_bar__plus_00_dot_17_bar__plus_02_dot_62 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_16_bar__plus_02_dot_72)
        (inReceptacle Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58 GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58)
        (inReceptacle Spatula_bar__minus_00_dot_81_bar__plus_00_dot_80_bar__minus_00_dot_75 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34 Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30)
        (inReceptacle Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13 Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30)
        (inReceptacle Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        
        
        (receptacleAtLocation Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24 loc_bar__minus_1_bar_3_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72 loc_bar_0_bar__minus_8_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14 loc_bar_1_bar__minus_1_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76 loc_bar_1_bar__minus_3_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38 loc_bar_1_bar__minus_8_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78 loc_bar_1_bar__minus_7_bar_1_bar__minus_30)
        (receptacleAtLocation CoffeeMachine_bar__plus_01_dot_02_bar__plus_00_dot_90_bar__minus_02_dot_18 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (receptacleAtLocation Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65 loc_bar_0_bar__minus_6_bar_0_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65 loc_bar_0_bar__minus_6_bar_0_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65 loc_bar_0_bar__minus_4_bar_1_bar_60)
        (receptacleAtLocation Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25 loc_bar_0_bar_5_bar_1_bar_60)
        (receptacleAtLocation GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58 loc_bar_0_bar_4_bar_3_bar_60)
        (receptacleAtLocation Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30 loc_bar_1_bar__minus_5_bar_1_bar_0)
        (receptacleAtLocation Shelf_bar__minus_01_dot_69_bar__plus_00_dot_16_bar__plus_02_dot_72 loc_bar__minus_6_bar_6_bar_0_bar_45)
        (receptacleAtLocation Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72 loc_bar__minus_9_bar_6_bar_0_bar_45)
        (receptacleAtLocation Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72 loc_bar__minus_9_bar_7_bar_0_bar_45)
        (receptacleAtLocation Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin loc_bar_0_bar__minus_3_bar_3_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_10 loc_bar_1_bar__minus_4_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50 loc_bar_1_bar__minus_6_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_10 loc_bar_1_bar__minus_4_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50 loc_bar_1_bar__minus_6_bar_1_bar_45)
        (receptacleAtLocation Toaster_bar__plus_00_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_33 loc_bar_1_bar_1_bar_1_bar_45)
        (objectAtLocation Mug_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_66 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Cup_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_92 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation DishSponge_bar__plus_01_dot_20_bar__plus_00_dot_91_bar__minus_00_dot_73 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation ButterKnife_bar__minus_01_dot_23_bar__plus_00_dot_93_bar__minus_00_dot_38 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation SaltShaker_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_77 loc_bar_0_bar__minus_4_bar_1_bar_60)
        (objectAtLocation Tomato_bar__plus_00_dot_91_bar__plus_00_dot_90_bar__plus_00_dot_97 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Spatula_bar__plus_00_dot_75_bar__plus_00_dot_72_bar__minus_00_dot_61 loc_bar_0_bar__minus_4_bar_1_bar_60)
        (objectAtLocation Apple_bar__plus_01_dot_06_bar__plus_01_dot_85_bar__minus_01_dot_13 loc_bar_1_bar__minus_5_bar_1_bar_0)
        (objectAtLocation Plate_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_15 loc_bar_1_bar__minus_1_bar_1_bar__minus_30)
        (objectAtLocation Fork_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_38 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_03 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation CellPhone_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__plus_00_dot_14 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation CreditCard_bar__plus_00_dot_92_bar__plus_00_dot_49_bar__minus_00_dot_69 loc_bar_0_bar__minus_6_bar_0_bar_45)
        (objectAtLocation Apple_bar__plus_00_dot_84_bar__plus_01_dot_19_bar__plus_01_dot_54 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Mug_bar__plus_00_dot_76_bar__plus_00_dot_12_bar__plus_00_dot_37 loc_bar__minus_1_bar_3_bar_1_bar_60)
        (objectAtLocation SaltShaker_bar__plus_01_dot_19_bar__plus_01_dot_66_bar__minus_00_dot_59 loc_bar_1_bar__minus_3_bar_1_bar__minus_30)
        (objectAtLocation Cup_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_08 loc_bar_1_bar__minus_7_bar_1_bar__minus_30)
        (objectAtLocation Knife_bar__minus_01_dot_10_bar__plus_00_dot_96_bar__minus_01_dot_17 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Spatula_bar__minus_00_dot_81_bar__plus_00_dot_80_bar__minus_00_dot_75 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Fork_bar__plus_00_dot_88_bar__plus_00_dot_49_bar__minus_00_dot_77 loc_bar_0_bar__minus_6_bar_0_bar_45)
        (objectAtLocation DishSponge_bar__plus_00_dot_91_bar__plus_00_dot_15_bar__minus_00_dot_73 loc_bar_0_bar__minus_6_bar_0_bar_60)
        (objectAtLocation CellPhone_bar__plus_00_dot_79_bar__plus_00_dot_70_bar__minus_00_dot_69 loc_bar_0_bar__minus_4_bar_1_bar_60)
        (objectAtLocation Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 loc_bar__minus_9_bar_7_bar_0_bar_45)
        (objectAtLocation Glassbottle_bar__plus_01_dot_08_bar__plus_02_dot_21_bar__minus_01_dot_41 loc_bar_1_bar__minus_7_bar_1_bar__minus_30)
        (objectAtLocation Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__minus_00_dot_73 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_01_dot_97 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (objectAtLocation CellPhone_bar__minus_01_dot_47_bar__plus_00_dot_55_bar__plus_02_dot_72 loc_bar__minus_9_bar_6_bar_0_bar_45)
        (objectAtLocation LightSwitch_bar__minus_02_dot_37_bar__plus_01_dot_22_bar__plus_03_dot_05 loc_bar__minus_10_bar_10_bar_0_bar_45)
        (objectAtLocation Potato_bar__plus_00_dot_94_bar__plus_00_dot_94_bar__minus_01_dot_79 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (objectAtLocation Knife_bar__minus_00_dot_70_bar__plus_00_dot_96_bar__minus_01_dot_46 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_37 loc_bar_1_bar__minus_5_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_52 loc_bar_1_bar__minus_6_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_09 loc_bar_1_bar__minus_4_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_24 loc_bar_1_bar__minus_5_bar_1_bar_60)
        (objectAtLocation Fork_bar__plus_00_dot_79_bar__plus_00_dot_49_bar__minus_00_dot_65 loc_bar_0_bar__minus_6_bar_0_bar_45)
        (objectAtLocation Pan_bar__plus_00_dot_97_bar__plus_01_dot_40_bar__plus_01_dot_35 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Lettuce_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__minus_00_dot_56 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Plate_bar__minus_01_dot_10_bar__plus_00_dot_94_bar__minus_00_dot_12 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_01_dot_25 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Pot_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_50 loc_bar_1_bar__minus_6_bar_1_bar_45)
        (objectAtLocation Window_bar__plus_00_dot_02_bar__plus_01_dot_00_bar__minus_02_dot_64 loc_bar_0_bar__minus_8_bar_2_bar_45)
        (objectAtLocation Window_bar__minus_03_dot_00_bar__plus_01_dot_00_bar__minus_02_dot_64 loc_bar__minus_12_bar__minus_8_bar_2_bar_45)
        (objectAtLocation Spatula_bar__plus_01_dot_11_bar__plus_00_dot_93_bar__minus_00_dot_21 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation PaperTowelRoll_bar__minus_00_dot_48_bar__plus_01_dot_04_bar__plus_00_dot_32 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Tomato_bar__minus_00_dot_91_bar__plus_00_dot_22_bar__plus_00_dot_58 loc_bar_0_bar_4_bar_3_bar_60)
        (objectAtLocation Egg_bar__plus_00_dot_84_bar__plus_01_dot_44_bar__plus_01_dot_54 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation SaltShaker_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_01_dot_88 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (objectAtLocation PepperShaker_bar__minus_01_dot_88_bar__plus_00_dot_55_bar__plus_02_dot_62 loc_bar__minus_9_bar_6_bar_0_bar_45)
        (objectAtLocation Vase_bar__minus_01_dot_42_bar__plus_00_dot_17_bar__plus_02_dot_62 loc_bar__minus_6_bar_6_bar_0_bar_45)
        (objectAtLocation ButterKnife_bar__minus_01_dot_29_bar__plus_00_dot_93_bar__minus_00_dot_91 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation SoapBottle_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__minus_01_dot_39 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Vase_bar__plus_01_dot_10_bar__plus_01_dot_67_bar__minus_02_dot_03 loc_bar_1_bar__minus_8_bar_1_bar__minus_30)
        (objectAtLocation Bowl_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_44 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation DishSponge_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_73 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Chair_bar__minus_01_dot_93_bar__plus_00_dot_00_bar__minus_00_dot_03 loc_bar__minus_10_bar_0_bar_1_bar_60)
        (objectAtLocation Chair_bar__minus_01_dot_90_bar__plus_00_dot_00_bar__minus_01_dot_00 loc_bar__minus_9_bar__minus_3_bar_1_bar_60)
        (objectAtLocation Spoon_bar__plus_00_dot_79_bar__plus_00_dot_16_bar__minus_00_dot_65 loc_bar_0_bar__minus_6_bar_0_bar_60)
        (objectAtLocation Cup_bar__minus_00_dot_75_bar__plus_00_dot_77_bar__minus_00_dot_83 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Mug_bar__plus_01_dot_06_bar__plus_01_dot_79_bar__minus_01_dot_34 loc_bar_1_bar__minus_5_bar_1_bar_0)
        )
    

                (:goal
                    (and
                        (exists (?r - receptacle)
                            (and
                                (receptacleType ?r CounterTopType)
                                (exists (?o - object)
                                    (and
                                        (objectType ?o ButterKnifeType)
                                        (exists (?mo - object)
                                            (and
                                                (objectType ?mo CupType)
                                                (isReceptacleObject ?mo)
                                                (inReceptacleObject ?o ?mo)
                                                (inReceptacle ?mo ?r)
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            