
(define (problem plan_trial_T20190908_191121_189259)
(:domain alfred)
(:objects
agent1 - agent
Curtains - object
        SprayBottle - object
        Mirror - object
        HousePlant - object
        Watch - object
        TeddyBear - object
        WateringCan - object
        Bathtub - object
        LightSwitch - object
        Vase - object
        Candle - object
        Bread - object
        Statue - object
        HandTowel - object
        StoveKnob - object
        PaperTowelRoll - object
        Pan - object
        PepperShaker - object
        Painting - object
        CellPhone - object
        Plunger - object
        Spoon - object
        SaltShaker - object
        KeyChain - object
        Footstool - object
        Poster - object
        Television - object
        LaundryHamperLid - object
        Glassbottle - object
        AlarmClock - object
        WineBottle - object
        Bowl - object
        Sink - object
        TissueBox - object
        TennisRacket - object
        ToiletPaper - object
        ScrubBrush - object
        CreditCard - object
        Laptop - object
        Cloth - object
        Cup - object
        Chair - object
        BasketBall - object
        Kettle - object
        PaperTowel - object
        ShowerDoor - object
        BaseballBat - object
        Potato - object
        Pillow - object
        Lettuce - object
        RemoteControl - object
        Window - object
        DishSponge - object
        CD - object
        Boots - object
        Blinds - object
        Pen - object
        Newspaper - object
        Plate - object
        Mug - object
        ShowerGlass - object
        ToiletPaperRoll - object
        SoapBar - object
        FloorLamp - object
        SoapBottle - object
        Pot - object
        Pencil - object
        Spatula - object
        Towel - object
        Fork - object
        Ladle - object
        Knife - object
        Apple - object
        Box - object
        Tomato - object
        ButterKnife - object
        Egg - object
        Book - object
        DeskLamp - object
CurtainsType - otype
        SprayBottleType - otype
        MirrorType - otype
        HousePlantType - otype
        WatchType - otype
        TeddyBearType - otype
        WateringCanType - otype
        BathtubType - otype
        LightSwitchType - otype
        VaseType - otype
        CandleType - otype
        BreadType - otype
        StatueType - otype
        HandTowelType - otype
        StoveKnobType - otype
        PaperTowelRollType - otype
        PanType - otype
        PepperShakerType - otype
        PaintingType - otype
        CellPhoneType - otype
        PlungerType - otype
        SpoonType - otype
        SaltShakerType - otype
        KeyChainType - otype
        FootstoolType - otype
        PosterType - otype
        TelevisionType - otype
        LaundryHamperLidType - otype
        GlassbottleType - otype
        AlarmClockType - otype
        WineBottleType - otype
        BowlType - otype
        SinkType - otype
        TissueBoxType - otype
        TennisRacketType - otype
        ToiletPaperType - otype
        ScrubBrushType - otype
        CreditCardType - otype
        LaptopType - otype
        ClothType - otype
        CupType - otype
        ChairType - otype
        BasketBallType - otype
        KettleType - otype
        PaperTowelType - otype
        ShowerDoorType - otype
        BaseballBatType - otype
        PotatoType - otype
        PillowType - otype
        LettuceType - otype
        RemoteControlType - otype
        WindowType - otype
        DishSpongeType - otype
        CDType - otype
        BootsType - otype
        BlindsType - otype
        PenType - otype
        NewspaperType - otype
        PlateType - otype
        MugType - otype
        ShowerGlassType - otype
        ToiletPaperRollType - otype
        SoapBarType - otype
        FloorLampType - otype
        SoapBottleType - otype
        PotType - otype
        PencilType - otype
        SpatulaType - otype
        TowelType - otype
        ForkType - otype
        LadleType - otype
        KnifeType - otype
        AppleType - otype
        BoxType - otype
        TomatoType - otype
        ButterKnifeType - otype
        EggType - otype
        BookType - otype
        DeskLampType - otype
CabinetType - rtype
        ShelfType - rtype
        DiningTableType - rtype
        TowelHolderType - rtype
        PaintingHangerType - rtype
        TVStandType - rtype
        LaundryHamperType - rtype
        OttomanType - rtype
        SafeType - rtype
        CoffeeMachineType - rtype
        CounterTopType - rtype
        ToiletType - rtype
        FridgeType - rtype
        CoffeeTableType - rtype
        SinkBasinType - rtype
        GarbageCanType - rtype
        BathtubBasinType - rtype
        SideTableType - rtype
        CartType - rtype
        BedType - rtype
        DeskType - rtype
        SofaType - rtype
        ArmChairType - rtype
        MicrowaveType - rtype
        HandTowelHolderType - rtype
        ToasterType - rtype
        ToiletPaperHangerType - rtype
        StoveBurnerType - rtype
        DrawerType - rtype
        DresserType - rtype


        Bathtub_bar__minus_01_dot_41_bar_00_dot_00_bar__plus_00_dot_56 - object
        Candle_bar__plus_00_dot_42_bar__plus_00_dot_62_bar__plus_03_dot_84 - object
        Candle_bar__minus_00_dot_09_bar__plus_01_dot_16_bar__plus_03_dot_93 - object
        Cloth_bar__minus_01_dot_03_bar__plus_00_dot_07_bar__plus_00_dot_44 - object
        Cloth_bar__minus_01_dot_75_bar__plus_00_dot_07_bar__plus_02_dot_64 - object
        Faucet_bar__minus_01_dot_87_bar__plus_00_dot_46_bar__plus_00_dot_64 - object
        Faucet_bar__minus_01_dot_99_bar__plus_00_dot_95_bar__plus_02_dot_78 - object
        Faucet_bar__minus_01_dot_99_bar__plus_00_dot_95_bar__plus_03_dot_47 - object
        HandTowel_bar__minus_01_dot_73_bar__plus_01_dot_33_bar__plus_03_dot_96 - object
        LightSwitch_bar__plus_01_dot_25_bar__plus_01_dot_33_bar__plus_03_dot_62 - object
        Mirror_bar__minus_01_dot_99_bar__plus_01_dot_42_bar__plus_03_dot_11 - object
        Plunger_bar__minus_01_dot_89_bar_00_dot_00_bar__plus_03_dot_89 - object
        ScrubBrush_bar__minus_01_dot_66_bar_00_dot_00_bar__plus_03_dot_90 - object
        ShowerDoor_bar__plus_00_dot_53_bar__plus_01_dot_04_bar__plus_02_dot_12 - object
        ShowerHead_bar__plus_00_dot_97_bar__plus_01_dot_22_bar__plus_02_dot_02 - object
        Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_02_dot_78 - object
        Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_03_dot_47 - object
        SoapBar_bar__minus_00_dot_54_bar__plus_00_dot_45_bar__plus_00_dot_16 - object
        SoapBar_bar__minus_01_dot_80_bar__plus_00_dot_01_bar__plus_02_dot_22 - object
        SoapBottle_bar__minus_01_dot_91_bar__plus_00_dot_07_bar__plus_02_dot_57 - object
        SprayBottle_bar__plus_00_dot_30_bar__plus_01_dot_16_bar__plus_03_dot_83 - object
        SprayBottle_bar__minus_01_dot_87_bar__plus_00_dot_07_bar__plus_03_dot_32 - object
        ToiletPaper_bar__plus_00_dot_28_bar__plus_00_dot_87_bar__plus_03_dot_84 - object
        ToiletPaper_bar__minus_00_dot_37_bar__plus_00_dot_44_bar__plus_00_dot_24 - object
        ToiletPaper_bar__minus_01_dot_86_bar__plus_01_dot_04_bar__plus_02_dot_01 - object
        Towel_bar__minus_00_dot_07_bar__plus_01_dot_28_bar__plus_00_dot_11 - object
        Window_bar__minus_01_dot_04_bar__plus_01_dot_39_bar__plus_00_dot_02 - object
        Window_bar__minus_01_dot_99_bar__plus_01_dot_39_bar__plus_00_dot_71 - object
        Bathtub_bar__minus_01_dot_41_bar_00_dot_00_bar__plus_00_dot_56_bar_BathtubBasin - receptacle
        Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_02_dot_49 - receptacle
        Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_11 - receptacle
        Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_14 - receptacle
        Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_75 - receptacle
        CounterTop_bar__minus_01_dot_80_bar__plus_00_dot_75_bar__plus_03_dot_12 - receptacle
        Drawer_bar__plus_00_dot_21_bar__plus_00_dot_16_bar__plus_03_dot_79 - receptacle
        Drawer_bar__plus_00_dot_21_bar__plus_00_dot_42_bar__plus_03_dot_79 - receptacle
        Drawer_bar__plus_00_dot_21_bar__plus_00_dot_68_bar__plus_03_dot_79 - receptacle
        Drawer_bar__plus_00_dot_21_bar__plus_00_dot_94_bar__plus_03_dot_79 - receptacle
        Dresser_bar__plus_00_dot_21_bar__plus_00_dot_81_bar__plus_03_dot_77 - receptacle
        GarbageCan_bar__minus_01_dot_76_bar__minus_00_dot_02_bar__plus_02_dot_22 - receptacle
        HandTowelHolder_bar__minus_01_dot_73_bar__plus_01_dot_44_bar__plus_04_dot_00 - receptacle
        Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_02_dot_78_bar_SinkBasin - receptacle
        Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_03_dot_47_bar_SinkBasin - receptacle
        ToiletPaperHanger_bar__minus_01_dot_78_bar__plus_00_dot_68_bar__plus_02_dot_47 - receptacle
        Toilet_bar__minus_01_dot_57_bar_00_dot_00_bar__plus_01_dot_82 - receptacle
        TowelHolder_bar__minus_00_dot_07_bar__plus_01_dot_27_bar__plus_00_dot_00 - receptacle
        loc_bar_3_bar_14_bar_1_bar_30 - location
        loc_bar_0_bar_8_bar_1_bar_45 - location
        loc_bar__minus_3_bar_13_bar_3_bar_60 - location
        loc_bar__minus_5_bar_12_bar_3_bar_15 - location
        loc_bar__minus_5_bar_11_bar_3_bar_60 - location
        loc_bar__minus_5_bar_14_bar_3_bar_60 - location
        loc_bar__minus_3_bar_12_bar_3_bar_60 - location
        loc_bar__minus_4_bar_11_bar_3_bar_45 - location
        loc_bar__minus_5_bar_14_bar_0_bar_30 - location
        loc_bar__minus_3_bar_14_bar_3_bar_60 - location
        loc_bar__minus_2_bar_3_bar_3_bar_60 - location
        loc_bar__minus_5_bar_12_bar_3_bar_60 - location
        loc_bar_1_bar_13_bar_0_bar_60 - location
        loc_bar__minus_3_bar_11_bar_3_bar_60 - location
        loc_bar__minus_5_bar_13_bar_3_bar_60 - location
        loc_bar__minus_2_bar_3_bar_3_bar_15 - location
        loc_bar__minus_2_bar_3_bar_2_bar_15 - location
        loc_bar__minus_1_bar_4_bar_3_bar_45 - location
        loc_bar__minus_2_bar_10_bar_3_bar_60 - location
        loc_bar_0_bar_2_bar_2_bar_30 - location
        loc_bar__minus_5_bar_10_bar_3_bar_60 - location
        loc_bar__minus_4_bar_14_bar_2_bar_30 - location
        )
    

(:init


        (receptacleType Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_02_dot_78_bar_SinkBasin SinkBasinType)
        (receptacleType Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_03_dot_47_bar_SinkBasin SinkBasinType)
        (receptacleType TowelHolder_bar__minus_00_dot_07_bar__plus_01_dot_27_bar__plus_00_dot_00 TowelHolderType)
        (receptacleType Drawer_bar__plus_00_dot_21_bar__plus_00_dot_68_bar__plus_03_dot_79 DrawerType)
        (receptacleType Drawer_bar__plus_00_dot_21_bar__plus_00_dot_16_bar__plus_03_dot_79 DrawerType)
        (receptacleType Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_75 CabinetType)
        (receptacleType HandTowelHolder_bar__minus_01_dot_73_bar__plus_01_dot_44_bar__plus_04_dot_00 HandTowelHolderType)
        (receptacleType Dresser_bar__plus_00_dot_21_bar__plus_00_dot_81_bar__plus_03_dot_77 DresserType)
        (receptacleType GarbageCan_bar__minus_01_dot_76_bar__minus_00_dot_02_bar__plus_02_dot_22 GarbageCanType)
        (receptacleType Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_14 CabinetType)
        (receptacleType ToiletPaperHanger_bar__minus_01_dot_78_bar__plus_00_dot_68_bar__plus_02_dot_47 ToiletPaperHangerType)
        (receptacleType Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_11 CabinetType)
        (receptacleType Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_02_dot_49 CabinetType)
        (receptacleType Bathtub_bar__minus_01_dot_41_bar_00_dot_00_bar__plus_00_dot_56_bar_BathtubBasin BathtubBasinType)
        (receptacleType Toilet_bar__minus_01_dot_57_bar_00_dot_00_bar__plus_01_dot_82 ToiletType)
        (receptacleType Drawer_bar__plus_00_dot_21_bar__plus_00_dot_94_bar__plus_03_dot_79 DrawerType)
        (receptacleType CounterTop_bar__minus_01_dot_80_bar__plus_00_dot_75_bar__plus_03_dot_12 CounterTopType)
        (receptacleType Drawer_bar__plus_00_dot_21_bar__plus_00_dot_42_bar__plus_03_dot_79 DrawerType)
        (objectType SprayBottle_bar__minus_01_dot_87_bar__plus_00_dot_07_bar__plus_03_dot_32 SprayBottleType)
        (objectType Towel_bar__minus_00_dot_07_bar__plus_01_dot_28_bar__plus_00_dot_11 TowelType)
        (objectType SprayBottle_bar__plus_00_dot_30_bar__plus_01_dot_16_bar__plus_03_dot_83 SprayBottleType)
        (objectType Mirror_bar__minus_01_dot_99_bar__plus_01_dot_42_bar__plus_03_dot_11 MirrorType)
        (objectType Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_03_dot_47 SinkType)
        (objectType ToiletPaper_bar__minus_01_dot_86_bar__plus_01_dot_04_bar__plus_02_dot_01 ToiletPaperType)
        (objectType SoapBottle_bar__minus_01_dot_91_bar__plus_00_dot_07_bar__plus_02_dot_57 SoapBottleType)
        (objectType ToiletPaper_bar__minus_00_dot_37_bar__plus_00_dot_44_bar__plus_00_dot_24 ToiletPaperType)
        (objectType SoapBar_bar__minus_00_dot_54_bar__plus_00_dot_45_bar__plus_00_dot_16 SoapBarType)
        (objectType Candle_bar__minus_00_dot_09_bar__plus_01_dot_16_bar__plus_03_dot_93 CandleType)
        (objectType HandTowel_bar__minus_01_dot_73_bar__plus_01_dot_33_bar__plus_03_dot_96 HandTowelType)
        (objectType SoapBar_bar__minus_01_dot_80_bar__plus_00_dot_01_bar__plus_02_dot_22 SoapBarType)
        (objectType ToiletPaper_bar__plus_00_dot_28_bar__plus_00_dot_87_bar__plus_03_dot_84 ToiletPaperType)
        (objectType Window_bar__minus_01_dot_99_bar__plus_01_dot_39_bar__plus_00_dot_71 WindowType)
        (objectType Plunger_bar__minus_01_dot_89_bar_00_dot_00_bar__plus_03_dot_89 PlungerType)
        (objectType LightSwitch_bar__plus_01_dot_25_bar__plus_01_dot_33_bar__plus_03_dot_62 LightSwitchType)
        (objectType Cloth_bar__minus_01_dot_03_bar__plus_00_dot_07_bar__plus_00_dot_44 ClothType)
        (objectType Cloth_bar__minus_01_dot_75_bar__plus_00_dot_07_bar__plus_02_dot_64 ClothType)
        (objectType Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_02_dot_78 SinkType)
        (objectType Bathtub_bar__minus_01_dot_41_bar_00_dot_00_bar__plus_00_dot_56 BathtubType)
        (objectType Candle_bar__plus_00_dot_42_bar__plus_00_dot_62_bar__plus_03_dot_84 CandleType)
        (objectType ShowerDoor_bar__plus_00_dot_53_bar__plus_01_dot_04_bar__plus_02_dot_12 ShowerDoorType)
        (objectType Window_bar__minus_01_dot_04_bar__plus_01_dot_39_bar__plus_00_dot_02 WindowType)
        (objectType ScrubBrush_bar__minus_01_dot_66_bar_00_dot_00_bar__plus_03_dot_90 ScrubBrushType)
        (canContain SinkBasinType SoapBarType)
        (canContain SinkBasinType ClothType)
        (canContain SinkBasinType HandTowelType)
        (canContain SinkBasinType SoapBarType)
        (canContain SinkBasinType ClothType)
        (canContain SinkBasinType HandTowelType)
        (canContain TowelHolderType TowelType)
        (canContain DrawerType SprayBottleType)
        (canContain DrawerType SoapBarType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ToiletPaperType)
        (canContain DrawerType CandleType)
        (canContain DrawerType ClothType)
        (canContain DrawerType HandTowelType)
        (canContain DrawerType SprayBottleType)
        (canContain DrawerType SoapBarType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ToiletPaperType)
        (canContain DrawerType CandleType)
        (canContain DrawerType ClothType)
        (canContain DrawerType HandTowelType)
        (canContain CabinetType PlungerType)
        (canContain CabinetType SprayBottleType)
        (canContain CabinetType SoapBarType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType ToiletPaperType)
        (canContain CabinetType CandleType)
        (canContain CabinetType ClothType)
        (canContain CabinetType HandTowelType)
        (canContain HandTowelHolderType HandTowelType)
        (canContain DresserType SprayBottleType)
        (canContain DresserType ToiletPaperType)
        (canContain DresserType CandleType)
        (canContain DresserType ClothType)
        (canContain GarbageCanType SprayBottleType)
        (canContain GarbageCanType SoapBarType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType ToiletPaperType)
        (canContain GarbageCanType ClothType)
        (canContain GarbageCanType HandTowelType)
        (canContain CabinetType PlungerType)
        (canContain CabinetType SprayBottleType)
        (canContain CabinetType SoapBarType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType ToiletPaperType)
        (canContain CabinetType CandleType)
        (canContain CabinetType ClothType)
        (canContain CabinetType HandTowelType)
        (canContain ToiletPaperHangerType ToiletPaperType)
        (canContain CabinetType PlungerType)
        (canContain CabinetType SprayBottleType)
        (canContain CabinetType SoapBarType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType ToiletPaperType)
        (canContain CabinetType CandleType)
        (canContain CabinetType ClothType)
        (canContain CabinetType HandTowelType)
        (canContain CabinetType PlungerType)
        (canContain CabinetType SprayBottleType)
        (canContain CabinetType SoapBarType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType ToiletPaperType)
        (canContain CabinetType CandleType)
        (canContain CabinetType ClothType)
        (canContain CabinetType HandTowelType)
        (canContain BathtubBasinType HandTowelType)
        (canContain BathtubBasinType SoapBarType)
        (canContain BathtubBasinType ClothType)
        (canContain ToiletType ClothType)
        (canContain ToiletType SoapBarType)
        (canContain ToiletType HandTowelType)
        (canContain ToiletType ToiletPaperType)
        (canContain ToiletType SoapBottleType)
        (canContain ToiletType SprayBottleType)
        (canContain ToiletType CandleType)
        (canContain DrawerType SprayBottleType)
        (canContain DrawerType SoapBarType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ToiletPaperType)
        (canContain DrawerType CandleType)
        (canContain DrawerType ClothType)
        (canContain DrawerType HandTowelType)
        (canContain CounterTopType SprayBottleType)
        (canContain CounterTopType SoapBarType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType ToiletPaperType)
        (canContain CounterTopType CandleType)
        (canContain CounterTopType ClothType)
        (canContain CounterTopType HandTowelType)
        (canContain DrawerType SprayBottleType)
        (canContain DrawerType SoapBarType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType ToiletPaperType)
        (canContain DrawerType CandleType)
        (canContain DrawerType ClothType)
        (canContain DrawerType HandTowelType)
        (pickupable SprayBottle_bar__minus_01_dot_87_bar__plus_00_dot_07_bar__plus_03_dot_32)
        (pickupable Towel_bar__minus_00_dot_07_bar__plus_01_dot_28_bar__plus_00_dot_11)
        (pickupable SprayBottle_bar__plus_00_dot_30_bar__plus_01_dot_16_bar__plus_03_dot_83)
        (pickupable ToiletPaper_bar__minus_01_dot_86_bar__plus_01_dot_04_bar__plus_02_dot_01)
        (pickupable SoapBottle_bar__minus_01_dot_91_bar__plus_00_dot_07_bar__plus_02_dot_57)
        (pickupable ToiletPaper_bar__minus_00_dot_37_bar__plus_00_dot_44_bar__plus_00_dot_24)
        (pickupable SoapBar_bar__minus_00_dot_54_bar__plus_00_dot_45_bar__plus_00_dot_16)
        (pickupable Candle_bar__minus_00_dot_09_bar__plus_01_dot_16_bar__plus_03_dot_93)
        (pickupable HandTowel_bar__minus_01_dot_73_bar__plus_01_dot_33_bar__plus_03_dot_96)
        (pickupable SoapBar_bar__minus_01_dot_80_bar__plus_00_dot_01_bar__plus_02_dot_22)
        (pickupable ToiletPaper_bar__plus_00_dot_28_bar__plus_00_dot_87_bar__plus_03_dot_84)
        (pickupable Plunger_bar__minus_01_dot_89_bar_00_dot_00_bar__plus_03_dot_89)
        (pickupable Cloth_bar__minus_01_dot_03_bar__plus_00_dot_07_bar__plus_00_dot_44)
        (pickupable Cloth_bar__minus_01_dot_75_bar__plus_00_dot_07_bar__plus_02_dot_64)
        (pickupable Candle_bar__plus_00_dot_42_bar__plus_00_dot_62_bar__plus_03_dot_84)
        (pickupable ScrubBrush_bar__minus_01_dot_66_bar_00_dot_00_bar__plus_03_dot_90)
        
        (openable Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_75)
        (openable Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_14)
        (openable Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_11)
        (openable Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_02_dot_49)
        
        (atLocation agent1 loc_bar__minus_4_bar_14_bar_2_bar_30)
        
        (cleanable SoapBar_bar__minus_00_dot_54_bar__plus_00_dot_45_bar__plus_00_dot_16)
        (cleanable SoapBar_bar__minus_01_dot_80_bar__plus_00_dot_01_bar__plus_02_dot_22)
        (cleanable Cloth_bar__minus_01_dot_03_bar__plus_00_dot_07_bar__plus_00_dot_44)
        (cleanable Cloth_bar__minus_01_dot_75_bar__plus_00_dot_07_bar__plus_02_dot_64)
        
        
        
        
        
        
        
        
        
        
        (inReceptacle SoapBar_bar__minus_01_dot_80_bar__plus_00_dot_01_bar__plus_02_dot_22 GarbageCan_bar__minus_01_dot_76_bar__minus_00_dot_02_bar__plus_02_dot_22)
        (inReceptacle SprayBottle_bar__plus_00_dot_30_bar__plus_01_dot_16_bar__plus_03_dot_83 Dresser_bar__plus_00_dot_21_bar__plus_00_dot_81_bar__plus_03_dot_77)
        (inReceptacle Candle_bar__minus_00_dot_09_bar__plus_01_dot_16_bar__plus_03_dot_93 Dresser_bar__plus_00_dot_21_bar__plus_00_dot_81_bar__plus_03_dot_77)
        (inReceptacle Cloth_bar__minus_01_dot_03_bar__plus_00_dot_07_bar__plus_00_dot_44 Bathtub_bar__minus_01_dot_41_bar_00_dot_00_bar__plus_00_dot_56_bar_BathtubBasin)
        (inReceptacle Cloth_bar__minus_01_dot_75_bar__plus_00_dot_07_bar__plus_02_dot_64 Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_02_dot_49)
        (inReceptacle SoapBottle_bar__minus_01_dot_91_bar__plus_00_dot_07_bar__plus_02_dot_57 Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_02_dot_49)
        (inReceptacle ToiletPaper_bar__plus_00_dot_28_bar__plus_00_dot_87_bar__plus_03_dot_84 Drawer_bar__plus_00_dot_21_bar__plus_00_dot_94_bar__plus_03_dot_79)
        (inReceptacle Candle_bar__plus_00_dot_42_bar__plus_00_dot_62_bar__plus_03_dot_84 Drawer_bar__plus_00_dot_21_bar__plus_00_dot_68_bar__plus_03_dot_79)
        (inReceptacle SprayBottle_bar__minus_01_dot_87_bar__plus_00_dot_07_bar__plus_03_dot_32 Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_14)
        (inReceptacle Towel_bar__minus_00_dot_07_bar__plus_01_dot_28_bar__plus_00_dot_11 TowelHolder_bar__minus_00_dot_07_bar__plus_01_dot_27_bar__plus_00_dot_00)
        (inReceptacle HandTowel_bar__minus_01_dot_73_bar__plus_01_dot_33_bar__plus_03_dot_96 HandTowelHolder_bar__minus_01_dot_73_bar__plus_01_dot_44_bar__plus_04_dot_00)
        (inReceptacle ToiletPaper_bar__minus_01_dot_86_bar__plus_01_dot_04_bar__plus_02_dot_01 Toilet_bar__minus_01_dot_57_bar_00_dot_00_bar__plus_01_dot_82)
        
        
        (receptacleAtLocation Bathtub_bar__minus_01_dot_41_bar_00_dot_00_bar__plus_00_dot_56_bar_BathtubBasin loc_bar__minus_1_bar_4_bar_3_bar_45)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_02_dot_49 loc_bar__minus_3_bar_13_bar_3_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_11 loc_bar__minus_3_bar_14_bar_3_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_14 loc_bar__minus_3_bar_11_bar_3_bar_60)
        (receptacleAtLocation Cabinet_bar__minus_01_dot_61_bar__plus_00_dot_31_bar__plus_03_dot_75 loc_bar__minus_3_bar_12_bar_3_bar_60)
        (receptacleAtLocation CounterTop_bar__minus_01_dot_80_bar__plus_00_dot_75_bar__plus_03_dot_12 loc_bar__minus_4_bar_11_bar_3_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_21_bar__plus_00_dot_16_bar__plus_03_dot_79 loc_bar_1_bar_13_bar_0_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_21_bar__plus_00_dot_42_bar__plus_03_dot_79 loc_bar_1_bar_13_bar_0_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_21_bar__plus_00_dot_68_bar__plus_03_dot_79 loc_bar_1_bar_13_bar_0_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_21_bar__plus_00_dot_94_bar__plus_03_dot_79 loc_bar_1_bar_13_bar_0_bar_60)
        (receptacleAtLocation Dresser_bar__plus_00_dot_21_bar__plus_00_dot_81_bar__plus_03_dot_77 loc_bar_1_bar_13_bar_0_bar_60)
        (receptacleAtLocation GarbageCan_bar__minus_01_dot_76_bar__minus_00_dot_02_bar__plus_02_dot_22 loc_bar__minus_3_bar_11_bar_3_bar_60)
        (receptacleAtLocation HandTowelHolder_bar__minus_01_dot_73_bar__plus_01_dot_44_bar__plus_04_dot_00 loc_bar__minus_5_bar_14_bar_0_bar_30)
        (receptacleAtLocation Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_02_dot_78_bar_SinkBasin loc_bar__minus_5_bar_13_bar_3_bar_60)
        (receptacleAtLocation Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_03_dot_47_bar_SinkBasin loc_bar__minus_5_bar_12_bar_3_bar_60)
        (receptacleAtLocation ToiletPaperHanger_bar__minus_01_dot_78_bar__plus_00_dot_68_bar__plus_02_dot_47 loc_bar__minus_5_bar_10_bar_3_bar_60)
        (receptacleAtLocation Toilet_bar__minus_01_dot_57_bar_00_dot_00_bar__plus_01_dot_82 loc_bar__minus_2_bar_10_bar_3_bar_60)
        (receptacleAtLocation TowelHolder_bar__minus_00_dot_07_bar__plus_01_dot_27_bar__plus_00_dot_00 loc_bar_0_bar_2_bar_2_bar_30)
        (objectAtLocation Candle_bar__plus_00_dot_42_bar__plus_00_dot_62_bar__plus_03_dot_84 loc_bar_1_bar_13_bar_0_bar_60)
        (objectAtLocation SprayBottle_bar__minus_01_dot_87_bar__plus_00_dot_07_bar__plus_03_dot_32 loc_bar__minus_3_bar_11_bar_3_bar_60)
        (objectAtLocation Cloth_bar__minus_01_dot_03_bar__plus_00_dot_07_bar__plus_00_dot_44 loc_bar__minus_1_bar_4_bar_3_bar_45)
        (objectAtLocation ToiletPaper_bar__minus_00_dot_37_bar__plus_00_dot_44_bar__plus_00_dot_24 loc_bar__minus_1_bar_4_bar_3_bar_45)
        (objectAtLocation SoapBar_bar__minus_01_dot_80_bar__plus_00_dot_01_bar__plus_02_dot_22 loc_bar__minus_3_bar_11_bar_3_bar_60)
        (objectAtLocation Bathtub_bar__minus_01_dot_41_bar_00_dot_00_bar__plus_00_dot_56 loc_bar__minus_2_bar_3_bar_3_bar_60)
        (objectAtLocation ShowerDoor_bar__plus_00_dot_53_bar__plus_01_dot_04_bar__plus_02_dot_12 loc_bar_0_bar_8_bar_1_bar_45)
        (objectAtLocation Mirror_bar__minus_01_dot_99_bar__plus_01_dot_42_bar__plus_03_dot_11 loc_bar__minus_5_bar_12_bar_3_bar_15)
        (objectAtLocation Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_02_dot_78 loc_bar__minus_5_bar_11_bar_3_bar_60)
        (objectAtLocation Sink_bar__minus_01_dot_83_bar__plus_00_dot_69_bar__plus_03_dot_47 loc_bar__minus_5_bar_14_bar_3_bar_60)
        (objectAtLocation Towel_bar__minus_00_dot_07_bar__plus_01_dot_28_bar__plus_00_dot_11 loc_bar_0_bar_2_bar_2_bar_30)
        (objectAtLocation HandTowel_bar__minus_01_dot_73_bar__plus_01_dot_33_bar__plus_03_dot_96 loc_bar__minus_5_bar_14_bar_0_bar_30)
        (objectAtLocation SoapBar_bar__minus_00_dot_54_bar__plus_00_dot_45_bar__plus_00_dot_16 loc_bar__minus_1_bar_4_bar_3_bar_45)
        (objectAtLocation ToiletPaper_bar__minus_01_dot_86_bar__plus_01_dot_04_bar__plus_02_dot_01 loc_bar__minus_2_bar_10_bar_3_bar_60)
        (objectAtLocation ToiletPaper_bar__plus_00_dot_28_bar__plus_00_dot_87_bar__plus_03_dot_84 loc_bar_1_bar_13_bar_0_bar_60)
        (objectAtLocation Cloth_bar__minus_01_dot_75_bar__plus_00_dot_07_bar__plus_02_dot_64 loc_bar__minus_3_bar_13_bar_3_bar_60)
        (objectAtLocation Window_bar__minus_01_dot_04_bar__plus_01_dot_39_bar__plus_00_dot_02 loc_bar__minus_2_bar_3_bar_2_bar_15)
        (objectAtLocation Window_bar__minus_01_dot_99_bar__plus_01_dot_39_bar__plus_00_dot_71 loc_bar__minus_2_bar_3_bar_3_bar_15)
        (objectAtLocation SprayBottle_bar__plus_00_dot_30_bar__plus_01_dot_16_bar__plus_03_dot_83 loc_bar_1_bar_13_bar_0_bar_60)
        (objectAtLocation Candle_bar__minus_00_dot_09_bar__plus_01_dot_16_bar__plus_03_dot_93 loc_bar_1_bar_13_bar_0_bar_60)
        (objectAtLocation ScrubBrush_bar__minus_01_dot_66_bar_00_dot_00_bar__plus_03_dot_90 loc_bar__minus_5_bar_14_bar_3_bar_60)
        (objectAtLocation Plunger_bar__minus_01_dot_89_bar_00_dot_00_bar__plus_03_dot_89 loc_bar__minus_5_bar_14_bar_3_bar_60)
        (objectAtLocation SoapBottle_bar__minus_01_dot_91_bar__plus_00_dot_07_bar__plus_02_dot_57 loc_bar__minus_3_bar_13_bar_3_bar_60)
        (objectAtLocation LightSwitch_bar__plus_01_dot_25_bar__plus_01_dot_33_bar__plus_03_dot_62 loc_bar_3_bar_14_bar_1_bar_30)
        )
    

        (:goal
            (and
                (exists (?r - receptacle)
                    (exists (?o - object)
                        (and
                            (cleanable ?o)
                            (objectType ?o SoapBarType)
                            (receptacleType ?r BathtubBasinType)
                            (isClean ?o)
                            (inReceptacle ?o ?r)
                        )
                    )
                )
            )
        )
    )
    