
(define (problem plan_trial_T20190913_033141_859977)
(:domain alfred)
(:objects
agent1 - agent
RemoteControl - object
        Laptop - object
        Kettle - object
        Pen - object
        Fork - object
        Cloth - object
        HousePlant - object
        Plunger - object
        SoapBottle - object
        Cup - object
        Candle - object
        Tomato - object
        Television - object
        TennisRacket - object
        Towel - object
        SaltShaker - object
        Spoon - object
        Apple - object
        Poster - object
        Curtains - object
        Footstool - object
        AlarmClock - object
        Ladle - object
        PaperTowelRoll - object
        BaseballBat - object
        Knife - object
        Spatula - object
        SoapBar - object
        CreditCard - object
        Sink - object
        Newspaper - object
        LaundryHamperLid - object
        KeyChain - object
        Glassbottle - object
        ButterKnife - object
        Chair - object
        HandTowel - object
        ToiletPaperRoll - object
        Plate - object
        Pot - object
        WineBottle - object
        Boots - object
        PepperShaker - object
        PaperTowel - object
        Bowl - object
        SprayBottle - object
        ScrubBrush - object
        Box - object
        CD - object
        Pan - object
        Statue - object
        Vase - object
        ShowerGlass - object
        DishSponge - object
        Egg - object
        Lettuce - object
        Book - object
        TeddyBear - object
        ToiletPaper - object
        ShowerDoor - object
        Window - object
        Blinds - object
        CellPhone - object
        FloorLamp - object
        Pillow - object
        Mirror - object
        Painting - object
        TissueBox - object
        Pencil - object
        Potato - object
        LightSwitch - object
        StoveKnob - object
        Mug - object
        Bathtub - object
        DeskLamp - object
        Watch - object
        WateringCan - object
        BasketBall - object
        Bread - object
RemoteControlType - otype
        LaptopType - otype
        KettleType - otype
        PenType - otype
        ForkType - otype
        ClothType - otype
        HousePlantType - otype
        PlungerType - otype
        SoapBottleType - otype
        CupType - otype
        CandleType - otype
        TomatoType - otype
        TelevisionType - otype
        TennisRacketType - otype
        TowelType - otype
        SaltShakerType - otype
        SpoonType - otype
        AppleType - otype
        PosterType - otype
        CurtainsType - otype
        FootstoolType - otype
        AlarmClockType - otype
        LadleType - otype
        PaperTowelRollType - otype
        BaseballBatType - otype
        KnifeType - otype
        SpatulaType - otype
        SoapBarType - otype
        CreditCardType - otype
        SinkType - otype
        NewspaperType - otype
        LaundryHamperLidType - otype
        KeyChainType - otype
        GlassbottleType - otype
        ButterKnifeType - otype
        ChairType - otype
        HandTowelType - otype
        ToiletPaperRollType - otype
        PlateType - otype
        PotType - otype
        WineBottleType - otype
        BootsType - otype
        PepperShakerType - otype
        PaperTowelType - otype
        BowlType - otype
        SprayBottleType - otype
        ScrubBrushType - otype
        BoxType - otype
        CDType - otype
        PanType - otype
        StatueType - otype
        VaseType - otype
        ShowerGlassType - otype
        DishSpongeType - otype
        EggType - otype
        LettuceType - otype
        BookType - otype
        TeddyBearType - otype
        ToiletPaperType - otype
        ShowerDoorType - otype
        WindowType - otype
        BlindsType - otype
        CellPhoneType - otype
        FloorLampType - otype
        PillowType - otype
        MirrorType - otype
        PaintingType - otype
        TissueBoxType - otype
        PencilType - otype
        PotatoType - otype
        LightSwitchType - otype
        StoveKnobType - otype
        MugType - otype
        BathtubType - otype
        DeskLampType - otype
        WatchType - otype
        WateringCanType - otype
        BasketBallType - otype
        BreadType - otype
SinkBasinType - rtype
        GarbageCanType - rtype
        StoveBurnerType - rtype
        OttomanType - rtype
        CabinetType - rtype
        SideTableType - rtype
        DiningTableType - rtype
        CoffeeTableType - rtype
        SafeType - rtype
        DresserType - rtype
        DeskType - rtype
        BedType - rtype
        TowelHolderType - rtype
        ToiletPaperHangerType - rtype
        MicrowaveType - rtype
        SofaType - rtype
        CartType - rtype
        ArmChairType - rtype
        HandTowelHolderType - rtype
        TVStandType - rtype
        BathtubBasinType - rtype
        CoffeeMachineType - rtype
        ToasterType - rtype
        LaundryHamperType - rtype
        DrawerType - rtype
        FridgeType - rtype
        ToiletType - rtype
        ShelfType - rtype
        PaintingHangerType - rtype
        CounterTopType - rtype


        Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97 - object
        Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79 - object
        Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06 - object
        Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97 - object
        Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97 - object
        Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59 - object
        Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14 - object
        Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38 - object
        Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14 - object
        ButterKnife_bar__minus_00_dot_77_bar__plus_00_dot_93_bar__minus_00_dot_07 - object
        CellPhone_bar__plus_00_dot_83_bar__plus_00_dot_15_bar__minus_00_dot_69 - object
        CellPhone_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_69 - object
        CellPhone_bar__minus_00_dot_55_bar__plus_00_dot_93_bar__minus_01_dot_39 - object
        Chair_bar__minus_01_dot_90_bar__plus_00_dot_00_bar__minus_01_dot_00 - object
        Chair_bar__minus_01_dot_93_bar__plus_00_dot_00_bar__minus_00_dot_03 - object
        CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_00_dot_21 - object
        CreditCard_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_15 - object
        CreditCard_bar__minus_01_dot_47_bar__plus_00_dot_88_bar__plus_02_dot_77 - object
        Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56 - object
        Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14 - object
        DishSponge_bar__plus_00_dot_75_bar__plus_00_dot_49_bar__minus_00_dot_69 - object
        DishSponge_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_03 - object
        DishSponge_bar__minus_00_dot_91_bar__plus_00_dot_18_bar__plus_00_dot_58 - object
        Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88 - object
        Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88 - object
        Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34 - object
        Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64 - object
        Faucet_bar__minus_00_dot_87_bar__plus_01_dot_16_bar__minus_00_dot_65 - object
        Fork_bar__plus_00_dot_79_bar__plus_00_dot_15_bar__minus_00_dot_57 - object
        Fork_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_83 - object
        Fork_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_92 - object
        Glassbottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_09 - object
        Glassbottle_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_67 - object
        HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 - object
        Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_21 - object
        Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_23 - object
        Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_46 - object
        Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25 - object
        Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75 - object
        Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91 - object
        LightSwitch_bar__minus_02_dot_37_bar__plus_01_dot_22_bar__plus_03_dot_05 - object
        Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97 - object
        Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41 - object
        Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25 - object
        Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10 - object
        PaperTowelRoll_bar__minus_01_dot_01_bar__plus_00_dot_28_bar__plus_00_dot_64 - object
        PepperShaker_bar__plus_00_dot_83_bar__plus_00_dot_70_bar__minus_00_dot_52 - object
        PepperShaker_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_56 - object
        Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25 - object
        Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25 - object
        Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54 - object
        Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50 - object
        SaltShaker_bar__plus_00_dot_86_bar__plus_00_dot_91_bar__minus_00_dot_03 - object
        Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65 - object
        SoapBottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__minus_00_dot_40 - object
        SoapBottle_bar__minus_00_dot_85_bar__plus_00_dot_93_bar__minus_01_dot_46 - object
        Spatula_bar__minus_00_dot_59_bar__plus_00_dot_79_bar__minus_00_dot_66 - object
        Spatula_bar__minus_01_dot_10_bar__plus_00_dot_95_bar__minus_00_dot_12 - object
        Spoon_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_54 - object
        Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_09 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_24 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_37 - object
        StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_52 - object
        Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40 - object
        Vase_bar__plus_01_dot_13_bar__plus_02_dot_21_bar__minus_01_dot_08 - object
        Vase_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__plus_00_dot_16 - object
        Vase_bar__minus_01_dot_88_bar__plus_00_dot_56_bar__plus_02_dot_72 - object
        Window_bar__plus_00_dot_02_bar__plus_01_dot_00_bar__minus_02_dot_64 - object
        Window_bar__minus_03_dot_00_bar__plus_01_dot_00_bar__minus_02_dot_64 - object
        Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24 - receptacle
        Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38 - receptacle
        Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78 - receptacle
        CoffeeMachine_bar__plus_01_dot_02_bar__plus_00_dot_90_bar__minus_02_dot_18 - receptacle
        CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21 - receptacle
        CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05 - receptacle
        CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64 - receptacle
        Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65 - receptacle
        Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65 - receptacle
        Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65 - receptacle
        Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25 - receptacle
        GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58 - receptacle
        Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30 - receptacle
        Shelf_bar__minus_01_dot_69_bar__plus_00_dot_16_bar__plus_02_dot_72 - receptacle
        Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72 - receptacle
        Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72 - receptacle
        Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin - receptacle
        StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_10 - receptacle
        StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50 - receptacle
        StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_10 - receptacle
        StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50 - receptacle
        Toaster_bar__plus_00_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_33 - receptacle
        loc_bar__minus_10_bar_0_bar_1_bar_60 - location
        loc_bar_1_bar__minus_1_bar_1_bar_45 - location
        loc_bar__minus_3_bar__minus_8_bar_0_bar_30 - location
        loc_bar_1_bar__minus_7_bar_1_bar__minus_30 - location
        loc_bar_1_bar__minus_4_bar_1_bar_45 - location
        loc_bar_0_bar__minus_3_bar_3_bar_45 - location
        loc_bar_1_bar__minus_6_bar_1_bar_60 - location
        loc_bar_0_bar_4_bar_3_bar_60 - location
        loc_bar_1_bar_1_bar_1_bar_45 - location
        loc_bar_0_bar_5_bar_1_bar_60 - location
        loc_bar_1_bar__minus_8_bar_1_bar_45 - location
        loc_bar_1_bar__minus_5_bar_1_bar_60 - location
        loc_bar_1_bar__minus_8_bar_1_bar__minus_30 - location
        loc_bar_1_bar__minus_3_bar_1_bar__minus_30 - location
        loc_bar_0_bar__minus_6_bar_0_bar_45 - location
        loc_bar_1_bar__minus_1_bar_1_bar__minus_30 - location
        loc_bar__minus_6_bar_6_bar_0_bar_45 - location
        loc_bar_1_bar__minus_4_bar_1_bar_60 - location
        loc_bar__minus_1_bar_3_bar_1_bar_60 - location
        loc_bar_0_bar__minus_6_bar_0_bar_60 - location
        loc_bar_1_bar__minus_6_bar_1_bar_45 - location
        loc_bar_0_bar__minus_8_bar_1_bar_60 - location
        loc_bar__minus_9_bar__minus_3_bar_1_bar_60 - location
        loc_bar_1_bar__minus_5_bar_1_bar_0 - location
        loc_bar__minus_10_bar_10_bar_0_bar_45 - location
        loc_bar__minus_9_bar_7_bar_0_bar_45 - location
        loc_bar_0_bar__minus_4_bar_1_bar_60 - location
        loc_bar__minus_12_bar__minus_8_bar_2_bar_45 - location
        loc_bar__minus_9_bar_6_bar_0_bar_45 - location
        loc_bar_0_bar__minus_8_bar_2_bar_45 - location
        loc_bar__minus_13_bar__minus_1_bar_1_bar_30 - location
        )
    

(:init


        (receptacleType Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30 MicrowaveType)
        (receptacleType Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65 DrawerType)
        (receptacleType Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72 ShelfType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76 CabinetType)
        (receptacleType Shelf_bar__minus_01_dot_69_bar__plus_00_dot_16_bar__plus_02_dot_72 ShelfType)
        (receptacleType Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24 CabinetType)
        (receptacleType StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_10 StoveBurnerType)
        (receptacleType CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21 CounterTopType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14 CabinetType)
        (receptacleType Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72 CabinetType)
        (receptacleType StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_10 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78 CabinetType)
        (receptacleType Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65 DrawerType)
        (receptacleType CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64 CounterTopType)
        (receptacleType CoffeeMachine_bar__plus_01_dot_02_bar__plus_00_dot_90_bar__minus_02_dot_18 CoffeeMachineType)
        (receptacleType StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50 StoveBurnerType)
        (receptacleType Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38 CabinetType)
        (receptacleType Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin SinkBasinType)
        (receptacleType GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58 GarbageCanType)
        (receptacleType CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05 CounterTopType)
        (receptacleType StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50 StoveBurnerType)
        (receptacleType Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25 FridgeType)
        (receptacleType Toaster_bar__plus_00_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_33 ToasterType)
        (receptacleType Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72 ShelfType)
        (receptacleType Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65 DrawerType)
        (objectType HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 HousePlantType)
        (objectType Spoon_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_54 SpoonType)
        (objectType Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97 BowlType)
        (objectType Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41 MugType)
        (objectType Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97 AppleType)
        (objectType Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64 EggType)
        (objectType Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59 BowlType)
        (objectType Window_bar__plus_00_dot_02_bar__plus_01_dot_00_bar__minus_02_dot_64 WindowType)
        (objectType Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97 BowlType)
        (objectType Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88 EggType)
        (objectType Chair_bar__minus_01_dot_90_bar__plus_00_dot_00_bar__minus_01_dot_00 ChairType)
        (objectType Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25 LettuceType)
        (objectType Vase_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__plus_00_dot_16 VaseType)
        (objectType PepperShaker_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_56 PepperShakerType)
        (objectType Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38 BreadType)
        (objectType DishSponge_bar__plus_00_dot_75_bar__plus_00_dot_49_bar__minus_00_dot_69 DishSpongeType)
        (objectType SoapBottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__minus_00_dot_40 SoapBottleType)
        (objectType Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25 PlateType)
        (objectType DishSponge_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_03 DishSpongeType)
        (objectType Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34 EggType)
        (objectType Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50 PotType)
        (objectType CellPhone_bar__plus_00_dot_83_bar__plus_00_dot_15_bar__minus_00_dot_69 CellPhoneType)
        (objectType SoapBottle_bar__minus_00_dot_85_bar__plus_00_dot_93_bar__minus_01_dot_46 SoapBottleType)
        (objectType Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25 PanType)
        (objectType CreditCard_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_15 CreditCardType)
        (objectType Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75 LettuceType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_52 StoveKnobType)
        (objectType Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06 AppleType)
        (objectType PaperTowelRoll_bar__minus_01_dot_01_bar__plus_00_dot_28_bar__plus_00_dot_64 PaperTowelRollType)
        (objectType DishSponge_bar__minus_00_dot_91_bar__plus_00_dot_18_bar__plus_00_dot_58 DishSpongeType)
        (objectType Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_21 KnifeType)
        (objectType CreditCard_bar__minus_01_dot_47_bar__plus_00_dot_88_bar__plus_02_dot_77 CreditCardType)
        (objectType Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97 MugType)
        (objectType Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14 BreadType)
        (objectType Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79 AppleType)
        (objectType Glassbottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_09 GlassbottleType)
        (objectType PepperShaker_bar__plus_00_dot_83_bar__plus_00_dot_70_bar__minus_00_dot_52 PepperShakerType)
        (objectType Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91 LettuceType)
        (objectType LightSwitch_bar__minus_02_dot_37_bar__plus_01_dot_22_bar__plus_03_dot_05 LightSwitchType)
        (objectType Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_46 KnifeType)
        (objectType CellPhone_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_69 CellPhoneType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_37 StoveKnobType)
        (objectType Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65 SinkType)
        (objectType Fork_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_83 ForkType)
        (objectType Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54 PotatoType)
        (objectType Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56 CupType)
        (objectType Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40 TomatoType)
        (objectType Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10 PanType)
        (objectType Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_23 KnifeType)
        (objectType Fork_bar__plus_00_dot_79_bar__plus_00_dot_15_bar__minus_00_dot_57 ForkType)
        (objectType Chair_bar__minus_01_dot_93_bar__plus_00_dot_00_bar__minus_00_dot_03 ChairType)
        (objectType Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88 EggType)
        (objectType Spatula_bar__minus_01_dot_10_bar__plus_00_dot_95_bar__minus_00_dot_12 SpatulaType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_09 StoveKnobType)
        (objectType Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14 BreadType)
        (objectType Vase_bar__plus_01_dot_13_bar__plus_02_dot_21_bar__minus_01_dot_08 VaseType)
        (objectType CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_00_dot_21 CreditCardType)
        (objectType StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_24 StoveKnobType)
        (objectType ButterKnife_bar__minus_00_dot_77_bar__plus_00_dot_93_bar__minus_00_dot_07 ButterKnifeType)
        (objectType CellPhone_bar__minus_00_dot_55_bar__plus_00_dot_93_bar__minus_01_dot_39 CellPhoneType)
        (objectType Spatula_bar__minus_00_dot_59_bar__plus_00_dot_79_bar__minus_00_dot_66 SpatulaType)
        (objectType SaltShaker_bar__plus_00_dot_86_bar__plus_00_dot_91_bar__minus_00_dot_03 SaltShakerType)
        (objectType Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14 CupType)
        (objectType Window_bar__minus_03_dot_00_bar__plus_01_dot_00_bar__minus_02_dot_64 WindowType)
        (objectType Glassbottle_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_67 GlassbottleType)
        (objectType Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 StatueType)
        (objectType Fork_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_92 ForkType)
        (objectType Vase_bar__minus_01_dot_88_bar__plus_00_dot_56_bar__plus_02_dot_72 VaseType)
        (objectType Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25 PlateType)
        (canContain MicrowaveType AppleType)
        (canContain MicrowaveType GlassbottleType)
        (canContain MicrowaveType MugType)
        (canContain MicrowaveType TomatoType)
        (canContain MicrowaveType BowlType)
        (canContain MicrowaveType CupType)
        (canContain MicrowaveType PlateType)
        (canContain MicrowaveType EggType)
        (canContain MicrowaveType PotatoType)
        (canContain MicrowaveType BreadType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType DishSpongeType)
        (canContain ShelfType PepperShakerType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType SoapBottleType)
        (canContain ShelfType CupType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType StatueType)
        (canContain ShelfType SaltShakerType)
        (canContain ShelfType VaseType)
        (canContain ShelfType GlassbottleType)
        (canContain ShelfType MugType)
        (canContain ShelfType PlateType)
        (canContain ShelfType DishSpongeType)
        (canContain ShelfType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain ShelfType PepperShakerType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType SoapBottleType)
        (canContain ShelfType CupType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType StatueType)
        (canContain ShelfType SaltShakerType)
        (canContain ShelfType VaseType)
        (canContain ShelfType GlassbottleType)
        (canContain ShelfType MugType)
        (canContain ShelfType PlateType)
        (canContain ShelfType DishSpongeType)
        (canContain ShelfType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType SpatulaType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType CreditCardType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType StatueType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType VaseType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType GlassbottleType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType BreadType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType DishSpongeType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType SpatulaType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType CreditCardType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType StatueType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType VaseType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType GlassbottleType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType BreadType)
        (canContain CoffeeMachineType MugType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain CabinetType PepperShakerType)
        (canContain CabinetType BowlType)
        (canContain CabinetType SoapBottleType)
        (canContain CabinetType CupType)
        (canContain CabinetType PanType)
        (canContain CabinetType SaltShakerType)
        (canContain CabinetType VaseType)
        (canContain CabinetType MugType)
        (canContain CabinetType GlassbottleType)
        (canContain CabinetType PlateType)
        (canContain CabinetType DishSpongeType)
        (canContain CabinetType PotType)
        (canContain SinkBasinType ForkType)
        (canContain SinkBasinType KnifeType)
        (canContain SinkBasinType BowlType)
        (canContain SinkBasinType SpatulaType)
        (canContain SinkBasinType CupType)
        (canContain SinkBasinType TomatoType)
        (canContain SinkBasinType PanType)
        (canContain SinkBasinType PotatoType)
        (canContain SinkBasinType SpoonType)
        (canContain SinkBasinType AppleType)
        (canContain SinkBasinType GlassbottleType)
        (canContain SinkBasinType MugType)
        (canContain SinkBasinType ButterKnifeType)
        (canContain SinkBasinType PlateType)
        (canContain SinkBasinType DishSpongeType)
        (canContain SinkBasinType EggType)
        (canContain SinkBasinType PotType)
        (canContain SinkBasinType LettuceType)
        (canContain GarbageCanType SoapBottleType)
        (canContain GarbageCanType TomatoType)
        (canContain GarbageCanType PotatoType)
        (canContain GarbageCanType AppleType)
        (canContain GarbageCanType BreadType)
        (canContain GarbageCanType DishSpongeType)
        (canContain GarbageCanType EggType)
        (canContain GarbageCanType LettuceType)
        (canContain CounterTopType PepperShakerType)
        (canContain CounterTopType ForkType)
        (canContain CounterTopType CellPhoneType)
        (canContain CounterTopType KnifeType)
        (canContain CounterTopType BowlType)
        (canContain CounterTopType SpatulaType)
        (canContain CounterTopType SoapBottleType)
        (canContain CounterTopType CupType)
        (canContain CounterTopType CreditCardType)
        (canContain CounterTopType PanType)
        (canContain CounterTopType TomatoType)
        (canContain CounterTopType StatueType)
        (canContain CounterTopType SaltShakerType)
        (canContain CounterTopType PotatoType)
        (canContain CounterTopType VaseType)
        (canContain CounterTopType SpoonType)
        (canContain CounterTopType AppleType)
        (canContain CounterTopType GlassbottleType)
        (canContain CounterTopType MugType)
        (canContain CounterTopType ButterKnifeType)
        (canContain CounterTopType PlateType)
        (canContain CounterTopType DishSpongeType)
        (canContain CounterTopType EggType)
        (canContain CounterTopType PotType)
        (canContain CounterTopType LettuceType)
        (canContain CounterTopType BreadType)
        (canContain StoveBurnerType PanType)
        (canContain StoveBurnerType PotType)
        (canContain FridgeType BowlType)
        (canContain FridgeType CupType)
        (canContain FridgeType TomatoType)
        (canContain FridgeType PanType)
        (canContain FridgeType PotatoType)
        (canContain FridgeType AppleType)
        (canContain FridgeType GlassbottleType)
        (canContain FridgeType MugType)
        (canContain FridgeType PlateType)
        (canContain FridgeType BreadType)
        (canContain FridgeType EggType)
        (canContain FridgeType PotType)
        (canContain FridgeType LettuceType)
        (canContain ShelfType PepperShakerType)
        (canContain ShelfType CellPhoneType)
        (canContain ShelfType BowlType)
        (canContain ShelfType SoapBottleType)
        (canContain ShelfType CupType)
        (canContain ShelfType CreditCardType)
        (canContain ShelfType StatueType)
        (canContain ShelfType SaltShakerType)
        (canContain ShelfType VaseType)
        (canContain ShelfType GlassbottleType)
        (canContain ShelfType MugType)
        (canContain ShelfType PlateType)
        (canContain ShelfType DishSpongeType)
        (canContain ShelfType PotType)
        (canContain DrawerType PepperShakerType)
        (canContain DrawerType ForkType)
        (canContain DrawerType CellPhoneType)
        (canContain DrawerType KnifeType)
        (canContain DrawerType SpatulaType)
        (canContain DrawerType SoapBottleType)
        (canContain DrawerType CreditCardType)
        (canContain DrawerType SaltShakerType)
        (canContain DrawerType SpoonType)
        (canContain DrawerType ButterKnifeType)
        (canContain DrawerType DishSpongeType)
        (pickupable Spoon_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_54)
        (pickupable Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97)
        (pickupable Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41)
        (pickupable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97)
        (pickupable Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64)
        (pickupable Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59)
        (pickupable Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97)
        (pickupable Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (pickupable Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25)
        (pickupable Vase_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__plus_00_dot_16)
        (pickupable PepperShaker_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_56)
        (pickupable Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38)
        (pickupable DishSponge_bar__plus_00_dot_75_bar__plus_00_dot_49_bar__minus_00_dot_69)
        (pickupable SoapBottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__minus_00_dot_40)
        (pickupable Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25)
        (pickupable DishSponge_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_03)
        (pickupable Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34)
        (pickupable Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (pickupable CellPhone_bar__plus_00_dot_83_bar__plus_00_dot_15_bar__minus_00_dot_69)
        (pickupable SoapBottle_bar__minus_00_dot_85_bar__plus_00_dot_93_bar__minus_01_dot_46)
        (pickupable Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25)
        (pickupable CreditCard_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_15)
        (pickupable Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75)
        (pickupable Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06)
        (pickupable PaperTowelRoll_bar__minus_01_dot_01_bar__plus_00_dot_28_bar__plus_00_dot_64)
        (pickupable DishSponge_bar__minus_00_dot_91_bar__plus_00_dot_18_bar__plus_00_dot_58)
        (pickupable Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_21)
        (pickupable CreditCard_bar__minus_01_dot_47_bar__plus_00_dot_88_bar__plus_02_dot_77)
        (pickupable Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97)
        (pickupable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14)
        (pickupable Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79)
        (pickupable Glassbottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_09)
        (pickupable PepperShaker_bar__plus_00_dot_83_bar__plus_00_dot_70_bar__minus_00_dot_52)
        (pickupable Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91)
        (pickupable Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_46)
        (pickupable CellPhone_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_69)
        (pickupable Fork_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_83)
        (pickupable Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54)
        (pickupable Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56)
        (pickupable Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40)
        (pickupable Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10)
        (pickupable Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_23)
        (pickupable Fork_bar__plus_00_dot_79_bar__plus_00_dot_15_bar__minus_00_dot_57)
        (pickupable Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (pickupable Spatula_bar__minus_01_dot_10_bar__plus_00_dot_95_bar__minus_00_dot_12)
        (pickupable Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14)
        (pickupable Vase_bar__plus_01_dot_13_bar__plus_02_dot_21_bar__minus_01_dot_08)
        (pickupable CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_00_dot_21)
        (pickupable ButterKnife_bar__minus_00_dot_77_bar__plus_00_dot_93_bar__minus_00_dot_07)
        (pickupable CellPhone_bar__minus_00_dot_55_bar__plus_00_dot_93_bar__minus_01_dot_39)
        (pickupable Spatula_bar__minus_00_dot_59_bar__plus_00_dot_79_bar__minus_00_dot_66)
        (pickupable SaltShaker_bar__plus_00_dot_86_bar__plus_00_dot_91_bar__minus_00_dot_03)
        (pickupable Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14)
        (pickupable Glassbottle_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_67)
        (pickupable Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75)
        (pickupable Fork_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_92)
        (pickupable Vase_bar__minus_01_dot_88_bar__plus_00_dot_56_bar__plus_02_dot_72)
        (pickupable Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25)
        (isReceptacleObject Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97)
        (isReceptacleObject Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41)
        (isReceptacleObject Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59)
        (isReceptacleObject Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97)
        (isReceptacleObject Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25)
        (isReceptacleObject Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (isReceptacleObject Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25)
        (isReceptacleObject Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97)
        (isReceptacleObject Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56)
        (isReceptacleObject Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10)
        (isReceptacleObject Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14)
        (isReceptacleObject Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25)
        (openable Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30)
        (openable Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65)
        (openable Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24)
        (openable Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72)
        (openable Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65)
        (openable Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38)
        (openable Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (openable Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65)
        
        (atLocation agent1 loc_bar__minus_13_bar__minus_1_bar_1_bar_30)
        
        (cleanable Spoon_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_54)
        (cleanable Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97)
        (cleanable Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41)
        (cleanable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97)
        (cleanable Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64)
        (cleanable Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59)
        (cleanable Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97)
        (cleanable Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (cleanable Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25)
        (cleanable DishSponge_bar__plus_00_dot_75_bar__plus_00_dot_49_bar__minus_00_dot_69)
        (cleanable Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25)
        (cleanable DishSponge_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_03)
        (cleanable Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34)
        (cleanable Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (cleanable Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25)
        (cleanable Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75)
        (cleanable Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06)
        (cleanable DishSponge_bar__minus_00_dot_91_bar__plus_00_dot_18_bar__plus_00_dot_58)
        (cleanable Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_21)
        (cleanable Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97)
        (cleanable Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79)
        (cleanable Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91)
        (cleanable Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_46)
        (cleanable Fork_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_83)
        (cleanable Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54)
        (cleanable Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56)
        (cleanable Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40)
        (cleanable Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10)
        (cleanable Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_23)
        (cleanable Fork_bar__plus_00_dot_79_bar__plus_00_dot_15_bar__minus_00_dot_57)
        (cleanable Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (cleanable Spatula_bar__minus_01_dot_10_bar__plus_00_dot_95_bar__minus_00_dot_12)
        (cleanable ButterKnife_bar__minus_00_dot_77_bar__plus_00_dot_93_bar__minus_00_dot_07)
        (cleanable Spatula_bar__minus_00_dot_59_bar__plus_00_dot_79_bar__minus_00_dot_66)
        (cleanable Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14)
        (cleanable Fork_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_92)
        (cleanable Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25)
        
        (heatable Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41)
        (heatable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97)
        (heatable Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64)
        (heatable Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (heatable Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38)
        (heatable Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25)
        (heatable Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34)
        (heatable Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06)
        (heatable Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97)
        (heatable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14)
        (heatable Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79)
        (heatable Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54)
        (heatable Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56)
        (heatable Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40)
        (heatable Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (heatable Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14)
        (heatable Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14)
        (heatable Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25)
        (coolable Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97)
        (coolable Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41)
        (coolable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97)
        (coolable Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64)
        (coolable Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59)
        (coolable Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97)
        (coolable Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (coolable Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25)
        (coolable Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38)
        (coolable Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25)
        (coolable Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34)
        (coolable Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50)
        (coolable Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25)
        (coolable Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75)
        (coolable Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06)
        (coolable Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97)
        (coolable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14)
        (coolable Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79)
        (coolable Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91)
        (coolable Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54)
        (coolable Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56)
        (coolable Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40)
        (coolable Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10)
        (coolable Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (coolable Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14)
        (coolable Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14)
        (coolable Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25)
        
        
        
        
        
        (sliceable Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97)
        (sliceable Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64)
        (sliceable Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (sliceable Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25)
        (sliceable Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38)
        (sliceable Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34)
        (sliceable Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75)
        (sliceable Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06)
        (sliceable Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14)
        (sliceable Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79)
        (sliceable Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91)
        (sliceable Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54)
        (sliceable Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40)
        (sliceable Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88)
        (sliceable Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14)
        
        (inReceptacle Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10 StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_10)
        (inReceptacle Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50 StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50)
        (inReceptacle Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50 StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50)
        (inReceptacle PepperShaker_bar__plus_00_dot_83_bar__plus_00_dot_70_bar__minus_00_dot_52 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65)
        (inReceptacle CellPhone_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_69 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65)
        (inReceptacle HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Spoon_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_54 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle ButterKnife_bar__minus_00_dot_77_bar__plus_00_dot_93_bar__minus_00_dot_07 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_46 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle CellPhone_bar__minus_00_dot_55_bar__plus_00_dot_93_bar__minus_01_dot_39 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle SoapBottle_bar__minus_00_dot_85_bar__plus_00_dot_93_bar__minus_01_dot_46 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle CreditCard_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_15 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_23 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Vase_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__plus_00_dot_16 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Spatula_bar__minus_01_dot_10_bar__plus_00_dot_95_bar__minus_00_dot_12 CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64)
        (inReceptacle Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_00_dot_21 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle DishSponge_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_03 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle SaltShaker_bar__plus_00_dot_86_bar__plus_00_dot_91_bar__minus_00_dot_03 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_21 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21)
        (inReceptacle Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10 StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_10)
        (inReceptacle CellPhone_bar__plus_00_dot_83_bar__plus_00_dot_15_bar__minus_00_dot_69 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65)
        (inReceptacle Fork_bar__plus_00_dot_79_bar__plus_00_dot_15_bar__minus_00_dot_57 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65)
        (inReceptacle DishSponge_bar__plus_00_dot_75_bar__plus_00_dot_49_bar__minus_00_dot_69 Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65)
        (inReceptacle Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97 Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72)
        (inReceptacle Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05)
        (inReceptacle Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05)
        (inReceptacle Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88 CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05)
        (inReceptacle Vase_bar__plus_01_dot_13_bar__plus_02_dot_21_bar__minus_01_dot_08 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78)
        (inReceptacle Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78)
        (inReceptacle Glassbottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_09 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14)
        (inReceptacle Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76)
        (inReceptacle SoapBottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__minus_00_dot_40 Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76)
        (inReceptacle Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72)
        (inReceptacle CreditCard_bar__minus_01_dot_47_bar__plus_00_dot_88_bar__plus_02_dot_77 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72)
        (inReceptacle Glassbottle_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_67 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72)
        (inReceptacle PepperShaker_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_56 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72)
        (inReceptacle Vase_bar__minus_01_dot_88_bar__plus_00_dot_56_bar__plus_02_dot_72 Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72)
        (inReceptacle DishSponge_bar__minus_00_dot_91_bar__plus_00_dot_18_bar__plus_00_dot_58 GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58)
        (inReceptacle PaperTowelRoll_bar__minus_01_dot_01_bar__plus_00_dot_28_bar__plus_00_dot_64 GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58)
        (inReceptacle Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64 GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58)
        (inReceptacle Fork_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_83 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Spatula_bar__minus_00_dot_59_bar__plus_00_dot_79_bar__minus_00_dot_66 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Fork_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_92 Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin)
        (inReceptacle Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34 Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30)
        (inReceptacle Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        (inReceptacle Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25 Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25)
        
        
        (receptacleAtLocation Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__plus_00_dot_24 loc_bar__minus_1_bar_3_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_65_bar__plus_00_dot_48_bar__minus_01_dot_72 loc_bar_0_bar__minus_8_bar_1_bar_60)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_14 loc_bar_1_bar__minus_1_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_00_dot_76 loc_bar_1_bar__minus_3_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_16_bar__minus_02_dot_38 loc_bar_1_bar__minus_8_bar_1_bar__minus_30)
        (receptacleAtLocation Cabinet_bar__plus_00_dot_95_bar__plus_02_dot_44_bar__minus_01_dot_78 loc_bar_1_bar__minus_7_bar_1_bar__minus_30)
        (receptacleAtLocation CoffeeMachine_bar__plus_01_dot_02_bar__plus_00_dot_90_bar__minus_02_dot_18 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_00_dot_21 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__plus_00_dot_93_bar__plus_00_dot_95_bar__minus_02_dot_05 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (receptacleAtLocation CounterTop_bar__minus_01_dot_24_bar__plus_00_dot_97_bar__minus_00_dot_64 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (receptacleAtLocation Drawer_bar__plus_00_dot_64_bar__plus_00_dot_27_bar__minus_00_dot_65 loc_bar_0_bar__minus_6_bar_0_bar_60)
        (receptacleAtLocation Drawer_bar__plus_00_dot_64_bar__plus_00_dot_55_bar__minus_00_dot_65 loc_bar_0_bar__minus_6_bar_0_bar_45)
        (receptacleAtLocation Drawer_bar__plus_00_dot_64_bar__plus_00_dot_76_bar__minus_00_dot_65 loc_bar_0_bar__minus_4_bar_1_bar_60)
        (receptacleAtLocation Fridge_bar__plus_00_dot_97_bar__plus_00_dot_00_bar__plus_01_dot_25 loc_bar_0_bar_5_bar_1_bar_60)
        (receptacleAtLocation GarbageCan_bar__minus_00_dot_95_bar__plus_00_dot_00_bar__plus_00_dot_58 loc_bar_0_bar_4_bar_3_bar_60)
        (receptacleAtLocation Microwave_bar__plus_01_dot_04_bar__plus_01_dot_68_bar__minus_01_dot_30 loc_bar_1_bar__minus_5_bar_1_bar_0)
        (receptacleAtLocation Shelf_bar__minus_01_dot_69_bar__plus_00_dot_16_bar__plus_02_dot_72 loc_bar__minus_6_bar_6_bar_0_bar_45)
        (receptacleAtLocation Shelf_bar__minus_01_dot_69_bar__plus_00_dot_54_bar__plus_02_dot_72 loc_bar__minus_9_bar_6_bar_0_bar_45)
        (receptacleAtLocation Shelf_bar__minus_01_dot_69_bar__plus_00_dot_87_bar__plus_02_dot_72 loc_bar__minus_9_bar_7_bar_0_bar_45)
        (receptacleAtLocation Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65_bar_SinkBasin loc_bar_0_bar__minus_3_bar_3_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_10 loc_bar_1_bar__minus_4_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_00_dot_84_bar__plus_00_dot_92_bar__minus_01_dot_50 loc_bar_1_bar__minus_6_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_10 loc_bar_1_bar__minus_4_bar_1_bar_45)
        (receptacleAtLocation StoveBurner_bar__plus_01_dot_08_bar__plus_00_dot_92_bar__minus_01_dot_50 loc_bar_1_bar__minus_6_bar_1_bar_45)
        (receptacleAtLocation Toaster_bar__plus_00_dot_98_bar__plus_00_dot_90_bar__plus_00_dot_33 loc_bar_1_bar_1_bar_1_bar_45)
        (objectAtLocation Mug_bar__plus_01_dot_04_bar__plus_02_dot_20_bar__minus_01_dot_41 loc_bar_1_bar__minus_7_bar_1_bar__minus_30)
        (objectAtLocation Cup_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_00_dot_14 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation DishSponge_bar__plus_00_dot_75_bar__plus_00_dot_49_bar__minus_00_dot_69 loc_bar_0_bar__minus_6_bar_0_bar_45)
        (objectAtLocation Bowl_bar__plus_00_dot_91_bar__plus_00_dot_11_bar__minus_01_dot_97 loc_bar_0_bar__minus_8_bar_1_bar_60)
        (objectAtLocation Vase_bar__minus_01_dot_88_bar__plus_00_dot_56_bar__plus_02_dot_72 loc_bar__minus_9_bar_6_bar_0_bar_45)
        (objectAtLocation SoapBottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__minus_00_dot_40 loc_bar_1_bar__minus_3_bar_1_bar__minus_30)
        (objectAtLocation PepperShaker_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_56 loc_bar__minus_9_bar_6_bar_0_bar_45)
        (objectAtLocation Egg_bar__plus_01_dot_11_bar__plus_00_dot_95_bar__minus_01_dot_88 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (objectAtLocation Spatula_bar__minus_01_dot_10_bar__plus_00_dot_95_bar__minus_00_dot_12 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Apple_bar__plus_00_dot_78_bar__plus_00_dot_91_bar__plus_00_dot_97 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Plate_bar__plus_00_dot_97_bar__plus_01_dot_14_bar__plus_01_dot_25 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Lettuce_bar__minus_00_dot_64_bar__plus_00_dot_86_bar__minus_00_dot_75 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Pan_bar__plus_00_dot_97_bar__plus_01_dot_64_bar__plus_01_dot_25 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Fork_bar__minus_00_dot_64_bar__plus_00_dot_78_bar__minus_00_dot_83 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_46 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation CellPhone_bar__plus_00_dot_83_bar__plus_00_dot_15_bar__minus_00_dot_69 loc_bar_0_bar__minus_6_bar_0_bar_60)
        (objectAtLocation CreditCard_bar__plus_00_dot_77_bar__plus_00_dot_91_bar__minus_00_dot_21 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Bread_bar__plus_00_dot_86_bar__plus_00_dot_99_bar__minus_00_dot_38 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Glassbottle_bar__minus_01_dot_36_bar__plus_00_dot_55_bar__plus_02_dot_67 loc_bar__minus_9_bar_6_bar_0_bar_45)
        (objectAtLocation Apple_bar__plus_01_dot_03_bar__plus_01_dot_69_bar__plus_01_dot_06 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Bread_bar__plus_01_dot_11_bar__plus_00_dot_99_bar__plus_00_dot_14 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation Lettuce_bar__minus_01_dot_29_bar__plus_01_dot_01_bar__minus_00_dot_91 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Bowl_bar__plus_01_dot_15_bar__plus_01_dot_67_bar__minus_00_dot_59 loc_bar_1_bar__minus_3_bar_1_bar__minus_30)
        (objectAtLocation Egg_bar__plus_00_dot_94_bar__plus_00_dot_95_bar__minus_01_dot_88 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (objectAtLocation Egg_bar__plus_01_dot_13_bar__plus_01_dot_83_bar__minus_01_dot_34 loc_bar_1_bar__minus_5_bar_1_bar_0)
        (objectAtLocation Knife_bar__minus_00_dot_62_bar__plus_00_dot_96_bar__minus_01_dot_23 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Fork_bar__plus_00_dot_79_bar__plus_00_dot_15_bar__minus_00_dot_57 loc_bar_0_bar__minus_6_bar_0_bar_60)
        (objectAtLocation DishSponge_bar__plus_00_dot_94_bar__plus_00_dot_91_bar__minus_00_dot_03 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation CellPhone_bar__plus_00_dot_88_bar__plus_00_dot_70_bar__minus_00_dot_69 loc_bar_0_bar__minus_4_bar_1_bar_60)
        (objectAtLocation CreditCard_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_15 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Sink_bar__minus_00_dot_70_bar__plus_00_dot_93_bar__minus_00_dot_65 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Statue_bar__minus_01_dot_82_bar__plus_00_dot_87_bar__plus_02_dot_75 loc_bar__minus_9_bar_7_bar_0_bar_45)
        (objectAtLocation Glassbottle_bar__plus_01_dot_19_bar__plus_01_dot_67_bar__plus_00_dot_09 loc_bar_1_bar__minus_1_bar_1_bar__minus_30)
        (objectAtLocation Bread_bar__plus_00_dot_77_bar__plus_00_dot_99_bar__plus_00_dot_14 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation CreditCard_bar__minus_01_dot_47_bar__plus_00_dot_88_bar__plus_02_dot_77 loc_bar__minus_9_bar_7_bar_0_bar_45)
        (objectAtLocation CellPhone_bar__minus_00_dot_55_bar__plus_00_dot_93_bar__minus_01_dot_39 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation LightSwitch_bar__minus_02_dot_37_bar__plus_01_dot_22_bar__plus_03_dot_05 loc_bar__minus_10_bar_10_bar_0_bar_45)
        (objectAtLocation Potato_bar__plus_00_dot_84_bar__plus_01_dot_67_bar__plus_01_dot_54 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Knife_bar__plus_00_dot_94_bar__plus_00_dot_93_bar__minus_00_dot_21 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_37 loc_bar_1_bar__minus_5_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_52 loc_bar_1_bar__minus_6_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_09 loc_bar_1_bar__minus_4_bar_1_bar_60)
        (objectAtLocation StoveKnob_bar__plus_00_dot_67_bar__plus_00_dot_90_bar__minus_01_dot_24 loc_bar_1_bar__minus_5_bar_1_bar_60)
        (objectAtLocation Fork_bar__minus_00_dot_75_bar__plus_00_dot_78_bar__minus_00_dot_92 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Pan_bar__plus_01_dot_08_bar__plus_00_dot_95_bar__minus_01_dot_10 loc_bar_1_bar__minus_4_bar_1_bar_45)
        (objectAtLocation Lettuce_bar__plus_01_dot_03_bar__plus_01_dot_48_bar__plus_01_dot_25 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Plate_bar__plus_00_dot_84_bar__plus_00_dot_87_bar__plus_01_dot_25 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation Apple_bar__plus_00_dot_86_bar__plus_00_dot_96_bar__minus_01_dot_79 loc_bar_1_bar__minus_8_bar_1_bar_45)
        (objectAtLocation Pot_bar__plus_00_dot_84_bar__plus_00_dot_95_bar__minus_01_dot_50 loc_bar_1_bar__minus_6_bar_1_bar_45)
        (objectAtLocation Window_bar__plus_00_dot_02_bar__plus_01_dot_00_bar__minus_02_dot_64 loc_bar_0_bar__minus_8_bar_2_bar_45)
        (objectAtLocation Window_bar__minus_03_dot_00_bar__plus_01_dot_00_bar__minus_02_dot_64 loc_bar__minus_12_bar__minus_8_bar_2_bar_45)
        (objectAtLocation Spatula_bar__minus_00_dot_59_bar__plus_00_dot_79_bar__minus_00_dot_66 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation PaperTowelRoll_bar__minus_01_dot_01_bar__plus_00_dot_28_bar__plus_00_dot_64 loc_bar_0_bar_4_bar_3_bar_60)
        (objectAtLocation Tomato_bar__minus_00_dot_70_bar__plus_00_dot_82_bar__minus_00_dot_40 loc_bar_0_bar__minus_3_bar_3_bar_45)
        (objectAtLocation Egg_bar__minus_01_dot_10_bar__plus_00_dot_21_bar__plus_00_dot_64 loc_bar_0_bar_4_bar_3_bar_60)
        (objectAtLocation SaltShaker_bar__plus_00_dot_86_bar__plus_00_dot_91_bar__minus_00_dot_03 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation PepperShaker_bar__plus_00_dot_83_bar__plus_00_dot_70_bar__minus_00_dot_52 loc_bar_0_bar__minus_4_bar_1_bar_60)
        (objectAtLocation Vase_bar__plus_01_dot_13_bar__plus_02_dot_21_bar__minus_01_dot_08 loc_bar_1_bar__minus_7_bar_1_bar__minus_30)
        (objectAtLocation ButterKnife_bar__minus_00_dot_77_bar__plus_00_dot_93_bar__minus_00_dot_07 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation SoapBottle_bar__minus_00_dot_85_bar__plus_00_dot_93_bar__minus_01_dot_46 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Vase_bar__minus_00_dot_62_bar__plus_00_dot_93_bar__plus_00_dot_16 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Bowl_bar__plus_01_dot_03_bar__plus_01_dot_14_bar__plus_00_dot_97 loc_bar_0_bar_5_bar_1_bar_60)
        (objectAtLocation DishSponge_bar__minus_00_dot_91_bar__plus_00_dot_18_bar__plus_00_dot_58 loc_bar_0_bar_4_bar_3_bar_60)
        (objectAtLocation Chair_bar__minus_01_dot_93_bar__plus_00_dot_00_bar__minus_00_dot_03 loc_bar__minus_10_bar_0_bar_1_bar_60)
        (objectAtLocation Chair_bar__minus_01_dot_90_bar__plus_00_dot_00_bar__minus_01_dot_00 loc_bar__minus_9_bar__minus_3_bar_1_bar_60)
        (objectAtLocation Spoon_bar__minus_00_dot_48_bar__plus_00_dot_93_bar__minus_01_dot_54 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Cup_bar__plus_01_dot_03_bar__plus_00_dot_91_bar__minus_00_dot_56 loc_bar_1_bar__minus_1_bar_1_bar_45)
        (objectAtLocation HousePlant_bar__minus_01_dot_35_bar__plus_00_dot_92_bar__minus_01_dot_54 loc_bar__minus_3_bar__minus_8_bar_0_bar_30)
        (objectAtLocation Mug_bar__plus_00_dot_84_bar__plus_01_dot_40_bar__plus_00_dot_97 loc_bar_0_bar_5_bar_1_bar_60)
        )
    

                (:goal
                    (and
                        (exists (?r - receptacle)
                            (and
                                (receptacleType ?r CounterTopType)
                                (exists (?o - object)
                                    (and
                                        (objectType ?o EggType)
                                        (exists (?mo - object)
                                            (and
                                                (objectType ?mo BowlType)
                                                (isReceptacleObject ?mo)
                                                (inReceptacleObject ?o ?mo)
                                                (inReceptacle ?mo ?r)
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            