from __future__ import annotations

import asyncio

import gnougo_flow_core.runtime as _runtime
from gnougo_flow_core.json_schema_contract_validator import validate_instance, validate_structured_output
from gnougo_flow_core.llm_failure_classifier import classify_llm_failure
from gnougo_flow_core.runtime import *  # noqa: F401,F403


def _strip_markdown_code_fences(text: str) -> str:
    """Strip markdown code fences (```json...``` or ```...```) that LLMs sometimes
    wrap around structured JSON responses."""
    trimmed = text.strip()
    if not trimmed.startswith("```"):
        return trimmed
    first_newline = trimmed.find("\n")
    if first_newline < 0:
        return trimmed
    body = trimmed[first_newline + 1:]
    last_fence = body.rfind("```")
    if last_fence >= 0:
        body = body[:last_fence]
    return body.strip()


class LlmCallExecutor:
    step_type = "llm.call"
    step_description = "Call an LLM with prompt/model and optional structured output."
    dsl_snippet = """
### llm.call - Call a language model
IMPORTANT: use `prompt` (NOT `messages`). `prompt` is REQUIRED. `model` is required unless the runtime injects a default model.
IMPORTANT: `temperature` and `reasoning` are optional overrides.
Omit them unless the task explicitly needs them; the runtime removes unsupported parameters based on model capabilities.
Basic call:
```yaml
- id: summarize
  type: llm.call
  input:
    model: gpt-4                        # optional when runtime defaults are configured
    prompt: "Summarize: ${data.inputs.task}"  # required - plain string
    system: "You are a helpful assistant."    # optional
    temperature: 0.7                     # optional override; omit by default
    reasoning: high                      # optional override; omit by default
    max_tokens: 2048                     # optional
```
Structured output:
IMPORTANT for `strict: true` (OpenAI/GitHub Models response_format json_schema):
- Every schema object with `properties` MUST have `required` listing EVERY key from `properties`.
- Do NOT list only the fields that feel mandatory; strict mode rejects omitted property names.
- Optional fields must still be listed in `required`; represent them as nullable with `anyOf: [{ type: <type> }, { type: "null" }]`.
- Add `additionalProperties: false` on every object schema for portability. The OpenAI provider also patches/adapts it automatically in strict mode.
```yaml
- id: classify
  type: llm.call
  input:
    model: gpt-4
    prompt: "Classify this ticket and return JSON"
    structured_output:
      schema_inline:
        type: object
        properties:
          category: { type: string }
          priority: { type: string }
          notes:
            anyOf:
              - type: string
              - type: "null"
        required: [category, priority, notes]   # every property above is listed, including nullable optional fields
        additionalProperties: false
      strict: true
```
You can also use `structured_output.schema_ref` instead of `schema_inline`.
Output: `{ text, json?, usage?, raw? }`.
"""
    documented_exceptions = [
        (ErrorCodes.INPUT_VALIDATION, False, "llm.call input/model/prompt is invalid."),
        (ErrorCodes.LLM_TIMEOUT, True, "transient timeout while calling LLM provider."),
        (ErrorCodes.LLM_NETWORK, True, "transient network failure while calling LLM provider."),
        (ErrorCodes.LLM_PROVIDER, False, "the LLM provider rejected the request with a non-retryable client error."),
        (ErrorCodes.LLM_SCHEMA, False, "structured_output response was not valid JSON for the requested schema."),
    ]

    async def execute_async(self, ctx: StepExecutionContext) -> Any:
        client = ctx.engine.llm_client
        if client is None:
            raise WorkflowRuntimeException(ErrorCodes.LLM_NETWORK, "No LLM client configured")
        input_obj = ctx.engine.get_resolved_input(ctx)
        if not isinstance(input_obj, dict):
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "llm.call input must be object")

        provider, model = ctx.engine.resolve_llm_target(input_obj.get("provider"), input_obj.get("model"))
        if not model:
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "llm.call requires 'model' unless runtime default is configured")
        prompt = input_obj.get("prompt")
        if not isinstance(prompt, str):
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "llm.call requires 'prompt'")

        structured = input_obj.get("structured_output") if input_obj.get("structured_output") is not None else None
        structured_contract = None
        if structured is not None:
            structured_contract = validate_structured_output(structured, allow_dynamic_schema_reference=False)
            if structured_contract.errors:
                raise WorkflowRuntimeException(
                    ErrorCodes.INPUT_VALIDATION,
                    "llm.call structured_output is invalid: " + "; ".join(structured_contract.errors),
                )
        # Reasoning / thinking effort: "minimal"|"low"|"medium"|"high"|"max"|"auto".
        # When omitted, providers fall back to their own defaults ("auto").
        reasoning_raw = input_obj.get("reasoning")
        reasoning = reasoning_raw.strip() if isinstance(reasoning_raw, str) and reasoning_raw.strip() else None
        max_tokens = None
        if "max_tokens" in input_obj and input_obj["max_tokens"] is not None:
            max_tokens = int(ExpressionEvaluator.get_number(input_obj["max_tokens"]))
        request = LLMRequest(
            provider=provider,
            model=model,
            prompt=prompt,
            temperature=float(input_obj["temperature"]) if "temperature" in input_obj and input_obj["temperature"] is not None else None,
            structured_output_schema=structured_contract.schema if structured_contract is not None else None,
            structured_output_strict=structured_contract.strict if structured_contract is not None else None,
            reasoning=reasoning,
            max_tokens=max_tokens,
        )
        request = ctx.engine.sanitize_llm_request(request)

        ctx.set_telemetry_attribute("gen_ai.operation.name", "chat")
        ctx.set_telemetry_attribute("gen_ai.system", provider or "default")
        ctx.set_telemetry_attribute("gen_ai.request.model", model)
        if request.temperature is not None:
            ctx.set_telemetry_attribute("gen_ai.request.temperature", request.temperature)
        if request.reasoning is not None:
            ctx.set_telemetry_attribute("gen_ai.request.reasoning_effort", request.reasoning)
        if request.max_tokens is not None:
            ctx.set_telemetry_attribute("gen_ai.request.max_tokens", request.max_tokens)

        if ctx.limits.log_step_content:
            ctx.add_telemetry_event(
                "gen_ai.content.prompt",
                [("gen_ai.prompt", prompt), ("prompt.role", "user")],
            )

        ctx.add_telemetry_event(
            "gnougo-flow.step.thinking",
            [
                ("gnougo-flow.thinking.message", f"Calling LLM ({model})..."),
                ("gnougo-flow.thinking.level", "thinking"),
            ],
        )

        try:
            response = await ctx.engine.call_llm_async(request)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            classified = classify_llm_failure(exc)
            if classified is not None:
                if classified is exc:
                    raise
                raise classified from exc
            if isinstance(exc, WorkflowRuntimeException):
                raise
            raise WorkflowRuntimeException(ErrorCodes.LLM_NETWORK, f"LLM call failed: {exc}") from exc

        finish_reason = "tool_calls" if response.tool_calls else "stop"
        ctx.set_telemetry_attribute("gen_ai.response.model", model)
        ctx.set_telemetry_attribute("gen_ai.response.finish_reason", finish_reason)
        _runtime._extract_usage_telemetry(ctx, response.usage, model, provider)

        if response.text:
            preview = response.text[:120] + ("..." if len(response.text) > 120 else "")
            ctx.add_telemetry_event(
                "gnougo-flow.step.thinking",
                [
                    ("gnougo-flow.thinking.message", preview),
                    ("gnougo-flow.thinking.level", "response"),
                ],
            )

        if ctx.limits.log_step_content and (response.text or response.json_payload is not None):
            completion_payload = response.text if response.text else json.dumps(response.json_payload, ensure_ascii=False)
            ctx.add_telemetry_event(
                "gen_ai.content.completion",
                [
                    ("gen_ai.completion", completion_payload),
                    ("completion.role", "assistant"),
                    ("completion.finish_reason", finish_reason),
                ],
            )

        structured_json = response.json_payload
        schema = request.structured_output_schema
        if schema is not None and structured_json is None and response.text:
            try:
                structured_json = json.loads(_strip_markdown_code_fences(response.text))
            except Exception:
                structured_json = None
        schema_errors = validate_instance(structured_json, schema) if schema is not None and structured_json is not None else []
        if schema is not None and (structured_json is None or schema_errors):
            raise WorkflowRuntimeException(
                ErrorCodes.LLM_SCHEMA,
                "llm.call structured_output expected valid JSON but the LLM returned an incompatible response"
                + (": " + "; ".join(schema_errors) if schema_errors else ""),
                retryable=True,
            )

        out = {"text": response.text, "meta": {"model": model}}
        if structured_json is not None:
            out["json"] = structured_json
        if response.usage is not None:
            out["usage"] = response.usage
        if response.raw is not None:
            out["raw"] = response.raw
        return out
