﻿from __future__ import annotations

import asyncio
import copy
import inspect
import json
import os
import uuid
from dataclasses import dataclass
from typing import Any

import gnougo_flow_core.runtime as _runtime
from gnougo_flow_core.errors import ErrorCodes, WorkflowRuntimeException
from gnougo_flow_core.integrations.mcp import (
    ConfiguredMcpClientFactory,
    McpHumanInputSignal,
    McpHumanInputSignalPhase,
    McpRealtimeProgressEvent,
)
from gnougo_flow_core.json_schema_contract_validator import validate_instance
from gnougo_flow_core.mcp_cache import (
    cache_prompts,
    cache_tools,
    get_cached_prompts,
    get_cached_tools,
)
from gnougo_flow_core.models import LLMRequest, LLMTool, McpPromptInfo
from gnougo_flow_core.runtime import StepExecutionContext
from gnougo_flow_core.runtime_contracts import IMcpSession
from gnougo_flow_core.templating import MustacheEngine


@dataclass(slots=True)
class McpCorrelationContext:
    tenant_id: str | None = None
    traceparent: str | None = None
    tracestate: str | None = None
    trace_id: str | None = None
    span_id: str | None = None
    parent_span_id: str | None = None
    correlation_id: str | None = None
    run_id: str | None = None
    execution_id: str | None = None
    agent_id: str | None = None
    agent_name: str | None = None
    step_id: str | None = None
    step_type: str | None = None
    mcp_server: str | None = None
    mcp_method: str | None = None
    mcp_kind: str | None = None
    context: dict[str, Any] | None = None

    def to_mcp_meta(self) -> dict[str, Any]:
        gnougo: dict[str, Any] = {}
        _add_if_present(gnougo, "tenantId", self.tenant_id)
        _add_if_present(gnougo, "traceparent", self.traceparent)
        _add_if_present(gnougo, "tracestate", self.tracestate)
        _add_if_present(gnougo, "traceId", self.trace_id)
        _add_if_present(gnougo, "spanId", self.span_id)
        _add_if_present(gnougo, "parentSpanId", self.parent_span_id)
        _add_if_present(gnougo, "correlationId", self.correlation_id)
        _add_if_present(gnougo, "runId", self.run_id)
        _add_if_present(gnougo, "executionId", self.execution_id)
        _add_if_present(gnougo, "agentId", self.agent_id)
        _add_if_present(gnougo, "agentName", self.agent_name)
        _add_if_present(gnougo, "stepId", self.step_id)
        _add_if_present(gnougo, "stepType", self.step_type)
        _add_if_present(gnougo, "mcpServer", self.mcp_server)
        _add_if_present(gnougo, "mcpMethod", self.mcp_method)
        _add_if_present(gnougo, "mcpKind", self.mcp_kind)
        if self.context is not None:
            gnougo["context"] = copy.deepcopy(self.context)

        meta: dict[str, Any] = {"gnougo": gnougo}
        _add_if_present(meta, "traceparent", self.traceparent)
        _add_if_present(meta, "tracestate", self.tracestate)
        return meta


def _is_unsupported_capability(exc: Exception, method_name: str) -> bool:
    current: BaseException | None = exc
    while current is not None:
        msg = str(current).lower()
        if method_name.lower() in msg and any(
            phrase in msg
            for phrase in ("not available", "not implemented", "method not found", "no handler")
        ):
            return True
        current = current.__cause__ or current.__context__
    return False


async def _maybe_timeout(coro: Any, timeout: float | None) -> Any:
    return await (asyncio.wait_for(coro, timeout=timeout) if timeout is not None else coro)


def _resolve_effective_timeout_ms(input_obj: dict[str, Any], server_name: str, factory: Any) -> int | None:
    requested = input_obj.get("timeout_ms")
    requested_ms = int(requested) if isinstance(requested, (int, float)) else None
    configured_ms = _resolve_configured_call_timeout_ms(factory, server_name)
    if requested_ms is not None and configured_ms is not None:
        return max(requested_ms, configured_ms)
    return requested_ms if requested_ms is not None else configured_ms


def _resolve_configured_call_timeout_ms(factory: Any, server_name: str) -> int | None:
    for metadata in getattr(factory, "server_metadata", []) or []:
        name = _get_property(metadata, "name")
        if not isinstance(name, str) or name.lower() != server_name.lower():
            continue
        seconds = _get_property(metadata, "call_timeout_seconds")
        if seconds is None:
            seconds = _get_property(metadata, "CallTimeoutSeconds")
        try:
            seconds_int = int(seconds)
        except (TypeError, ValueError):
            return None
        return seconds_int * 1000 if seconds_int > 0 else None
    return None


async def _try_list_prompts(session: IMcpSession, server_name: str, ctx: StepExecutionContext, timeout: float | None) -> list[McpPromptInfo]:
    try:
        return await _maybe_timeout(session.list_prompts_async(), timeout)
    except Exception as exc:
        if not _is_unsupported_capability(exc, "prompts/list"):
            raise
        ctx.engine.logger.warning("mcp.call: prompts/list not supported on '%s': %s", server_name, exc)
        ctx.set_telemetry_attribute("mcp.prompts_unsupported", True)
        ctx.add_telemetry_event(
            "mcp.capability.unsupported",
            [("mcp.server.name", server_name), ("mcp.method", "prompts/list"), ("mcp.reason", str(exc))],
        )
        return []


def _build_unique_internal_name(method_name: str, kind: str, used_names: set[str]) -> str:
    if method_name not in used_names:
        used_names.add(method_name)
        return method_name
    prefixed = f"{kind}:{method_name}"
    if prefixed not in used_names:
        used_names.add(prefixed)
        return prefixed
    index = 2
    while f"{prefixed}:{index}" in used_names:
        index += 1
    internal = f"{prefixed}:{index}"
    used_names.add(internal)
    return internal


def _prompt_argument_schema(arguments: Any) -> dict[str, Any]:
    if not arguments:
        return {"type": "object"}
    properties: dict[str, Any] = {}
    required: list[str] = []
    for arg in arguments:
        name = arg.get("name") if isinstance(arg, dict) else getattr(arg, "name", None)
        if not name:
            continue
        description = arg.get("description") if isinstance(arg, dict) else getattr(arg, "description", None)
        is_required = arg.get("required", False) if isinstance(arg, dict) else getattr(arg, "required", False)
        properties[str(name)] = {"type": "string", "description": description}
        if bool(is_required):
            required.append(str(name))
    schema: dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        schema["required"] = required
    return schema

class McpCallExecutor:
    step_type = "mcp.call"
    step_description = "Call MCP tool/prompt directly or via LLM-assisted selection."
    dsl_snippet = """
### mcp.call - Execute MCP tool or prompt
When workflow.plan provides an `<available_mcp_servers>` section, pick one of those exact configured server names.
Direct MCP call pattern (preferred when tool names are known): use `mcp.call` directly with explicit `method` and `request`.
MCP errors raise workflow `on_error` by default. Set `raise_on_error: false` only when the workflow intentionally wants
to inspect `status: error` as normal output.
Set `error_policy.detect_result_errors: true` to treat common structured failure envelopes like `{ success: false, error_code, error_message }` as MCP errors.
```yaml
- id: browse
  type: mcp.call
  input:
    server: GnOuGo.Browser.Mcp
    kind: tool
    method: navigate
    request:
      url: "https://slimfaas.dev"

LLM-assisted MCP call pattern: provide a natural-language `prompt` + `model` (+ optional `temperature`) and discovered tools/prompts.
- id: smart_call
  type: mcp.call
  input:
    server: GnOuGo.Browser.Mcp
    model: gpt-4o-mini
    prompt: "Pick and call the best MCP capability for this task"
    tools: "${data.steps.discover_mcp.tools}"
```
Output: single `{ status, response }`, batch `{ status, results }`, or
assisted `{ status, selection_mode, text, tool_calls, results, json? }`.
Output (LLM-assisted): inspect `results[]` and optional `json` when `structured_output` is configured.
Output access patterns: `data.steps.<id>.status`, `data.steps.<id>.response`, `data.steps.<id>.results`, `data.steps.<id>.json`.
"""
    documented_exceptions = [
        (ErrorCodes.INPUT_VALIDATION, False, "mcp.call input/server/method is malformed."),
        (ErrorCodes.TEMPLATE_SYNTAX, False, "mcp.call request_template rendering failed."),
        (ErrorCodes.JSON_PARSE, False, "mcp.call request_template rendered invalid JSON."),
        (ErrorCodes.MCP_CALL_ERROR, False, "MCP tool execution failed."),
        (ErrorCodes.MCP_PROMPT_ERROR, False, "MCP prompt or selection failed."),
        (ErrorCodes.MCP_TIMEOUT, True, "mcp.call timed out."),
    ]

    async def execute_async(self, ctx: StepExecutionContext) -> Any:
        factory = ctx.engine.mcp_client_factory
        if factory is None:
            raise WorkflowRuntimeException(ErrorCodes.MCP_CONNECTION_ERROR, "No IMcpClientFactory configured")
        input_obj = ctx.engine.get_resolved_input(ctx)
        if not isinstance(input_obj, dict):
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call input must be object")

        server = input_obj.get("server")
        if not isinstance(server, str) or not server:
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call requires 'server'")

        kind = str(input_obj.get("kind", "tool")).lower()
        if kind not in {"tool", "prompt"}:
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, f"mcp.call 'kind' must be 'tool' or 'prompt', got '{kind}'")

        has_method = "method" in input_obj and input_obj.get("method") is not None
        has_methods = "methods" in input_obj
        method = input_obj.get("method")
        methods = None
        if has_methods:
            raw_methods = input_obj.get("methods")
            if not isinstance(raw_methods, list) or not raw_methods:
                raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call 'methods' must be a non-empty array of strings")
            methods = []
            for item in raw_methods:
                name = "" if item is None else str(item)
                if not name:
                    raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call 'methods' contains an empty or null entry")
                methods.append(name)
        elif has_method:
            method = str(method)
            if not method:
                raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call 'method' must be a non-empty string")
        else:
            method = None
        has_prompt_selection = input_obj.get("prompt") is not None

        ctx.set_telemetry_attribute("gen_ai.operation.name", "chat" if has_prompt_selection else ("prompt_get" if kind == "prompt" else "tool_call"))
        ctx.set_telemetry_attribute("mcp.server.name", server)
        ctx.set_telemetry_attribute("mcp.kind", kind)
        ctx.add_telemetry_event(
            "gnougo-flow.step.thinking",
            [
                ("gnougo-flow.thinking.message", f"Calling MCP server '{server}' ({kind})..."),
                ("gnougo-flow.thinking.level", "thinking"),
            ],
        )

        request = self._build_request_args(input_obj, ctx) if not has_prompt_selection else None
        timeout_ms = _resolve_effective_timeout_ms(input_obj, server, factory)
        timeout = float(timeout_ms) / 1000.0 if timeout_ms is not None else None
        if timeout_ms is not None:
            ctx.set_telemetry_attribute("mcp.timeout_ms", timeout_ms)
        error_policy = _resolve_mcp_error_policy(input_obj)
        if error_policy["raise_on_error"]:
            ctx.set_telemetry_attribute("mcp.raise_on_error", True)
        if error_policy["detect_result_errors"]:
            ctx.set_telemetry_attribute("mcp.detect_result_errors", True)
        target = "(llm-selection)" if has_prompt_selection else "(auto)"
        try:
            if hasattr(factory, "human_input_provider"):
                factory.human_input_provider = ctx.engine.human_input_provider
            request_context = _validate_mcp_request_context(input_obj.get("context"))
            correlation = _build_mcp_correlation_context(
                ctx,
                server,
                kind,
                method if isinstance(method, str) else (",".join(methods) if methods else None),
                request_context,
            )
            ctx.set_telemetry_attribute("gnougo.correlation_id", correlation.correlation_id)
            if correlation.trace_id:
                ctx.set_telemetry_attribute("gnougo.trace_id", correlation.trace_id)
            realtime_progress_fingerprints: set[str] = set()

            def on_realtime_progress(progress_event: McpRealtimeProgressEvent) -> None:
                realtime_progress_fingerprints.add(_build_progress_fingerprint(progress_event.event_kind, progress_event.message, progress_event.file))
                _emit_realtime_mcp_progress_event_as_thinking(ctx, progress_event, correlation)

            with (
                ConfiguredMcpClientFactory.push_progress_handler(correlation, on_realtime_progress),
                ConfiguredMcpClientFactory.push_human_input_handler(
                    correlation,
                    lambda signal: _emit_realtime_mcp_human_input_signal(ctx, signal),
                ),
            ):
                session = await _maybe_timeout(factory.get_client_async(server), timeout)
                if kind == "tool":
                    live_discovery = getattr(session, "ensure_tools_discovered_async", None)
                    if callable(live_discovery):
                        live_tools = await _maybe_timeout(live_discovery(), timeout)
                    else:
                        session_key = id(session)
                        session_lock = ctx.engine._mcp_live_tool_session_locks.setdefault(
                            session_key, asyncio.Lock()
                        )
                        async with session_lock:
                            initialized_session = ctx.engine._mcp_live_tool_sessions.get(session_key)
                            if initialized_session is session:
                                live_tools = get_cached_tools(ctx.engine.mcp_cache, server)
                            else:
                                live_tools = await _maybe_timeout(session.list_tools_async(), timeout)
                                ctx.engine._mcp_live_tool_sessions[session_key] = session
                            if live_tools is None:
                                live_tools = await _maybe_timeout(session.list_tools_async(), timeout)
                    cache_tools(ctx.engine.mcp_cache, server, live_tools)

                if has_prompt_selection:
                    return await self._execute_llm_assisted(
                        ctx,
                        session,
                        input_obj,
                        kind,
                        method if isinstance(method, str) else None,
                        methods,
                        error_policy,
                        timeout,
                        realtime_progress_fingerprints,
                        request_context,
                    )

                async def single(call_method: str, req: Any) -> dict[str, Any]:
                    item_correlation = _build_mcp_correlation_context(
                        ctx, server, kind, call_method, request_context
                    )
                    return await self._call_single(
                        ctx,
                        session,
                        kind,
                        call_method,
                        req,
                        item_correlation,
                        realtime_progress_fingerprints,
                        timeout,
                        error_policy["detect_result_errors"],
                    )

                if methods is not None:
                    target = ", ".join(methods)
                    results = []
                    has_error = False
                    for m in methods:
                        item = await single(m, copy.deepcopy(request))
                        item["method"] = m
                        has_error = has_error or item.get("status") == "error"
                        results.append(item)
                    ctx.set_telemetry_attribute("mcp.methods_count", len(methods))
                    ctx.set_telemetry_attribute("gen_ai.response.finish_reason", "error" if has_error else "stop")
                    batch_result = {"status": "error" if has_error else "ok", "results": results}
                    if error_policy["raise_on_error"] and has_error:
                        _raise_mcp_batch_error(kind, server, methods, batch_result)
                    return batch_result

                if not method:
                    cache = ctx.engine.mcp_cache
                    if kind == "prompt":
                        prompts = get_cached_prompts(cache, server)
                        if prompts is None:
                            prompts = await _try_list_prompts(session, server, ctx, timeout)
                            cache_prompts(cache, server, prompts)
                        methods = [p.name for p in prompts]
                    else:
                        tools = get_cached_tools(cache, server)
                        if tools is None:
                            tools = await _maybe_timeout(session.list_tools_async(), timeout)
                            cache_tools(cache, server, tools)
                        methods = [t.name for t in tools]
                    target = ", ".join(methods) if methods else "(auto)"
                    ctx.set_telemetry_attribute("mcp.auto_discover", True)
                    ctx.set_telemetry_attribute("mcp.methods_count", len(methods))
                    if not methods:
                        ctx.set_telemetry_attribute("gen_ai.response.finish_reason", "stop")
                        return {"status": "ok", "results": []}
                    batch = []
                    has_error = False
                    for m in methods:
                        item = await single(m, copy.deepcopy(request))
                        item["method"] = m
                        has_error = has_error or item.get("status") == "error"
                        batch.append(item)
                    ctx.set_telemetry_attribute("gen_ai.response.finish_reason", "error" if has_error else "stop")
                    batch_result = {"status": "error" if has_error else "ok", "results": batch}
                    if error_policy["raise_on_error"] and has_error:
                        _raise_mcp_batch_error(kind, server, methods, batch_result)
                    return batch_result

                target = method
                ctx.set_telemetry_attribute("mcp.method.name", method)
                single_result = await single(method, request)
                ctx.set_telemetry_attribute("gen_ai.response.finish_reason", "error" if single_result.get("status") == "error" else "stop")
                if error_policy["raise_on_error"] and single_result.get("status") == "error":
                    _raise_mcp_single_error(kind, server, method, single_result)
                return single_result
        except WorkflowRuntimeException:
            raise
        except (TimeoutError, asyncio.TimeoutError) as exc:
            raise WorkflowRuntimeException(ErrorCodes.MCP_TIMEOUT, f"mcp.call to '{server}/{target}' timed out after {timeout_ms}ms", retryable=True) from exc
        except asyncio.CancelledError as exc:
            current = asyncio.current_task()
            if (ctx.ct is not None and ctx.ct.is_set()) or (current is not None and current.cancelling() > 0):
                raise
            error_code = ErrorCodes.MCP_PROMPT_ERROR if kind == "prompt" else ErrorCodes.MCP_CALL_ERROR
            raise WorkflowRuntimeException(
                error_code,
                f"mcp.call ({kind}) to '{server}/{target}' was cancelled by the MCP transport.",
                retryable=True,
            ) from exc
        except Exception as exc:
            error_code = ErrorCodes.MCP_PROMPT_ERROR if kind == "prompt" else ErrorCodes.MCP_CALL_ERROR
            raise WorkflowRuntimeException(error_code, f"mcp.call ({kind}) to '{server}/{target}' failed: {exc}", retryable=False) from exc

    async def _call_single(
        self,
        ctx: StepExecutionContext,
        session: IMcpSession,
        kind: str,
        method: str,
        request_args: Any,
        correlation: McpCorrelationContext,
        realtime_progress_fingerprints: set[str] | None,
        timeout: float | None,
        detect_result_errors: bool,
    ) -> dict[str, Any]:
        if kind == "prompt":
            op = session.get_prompt_async(method, request_args)
            result = await (asyncio.wait_for(op, timeout=timeout) if timeout is not None else op)
            _runtime._extract_usage_telemetry(ctx, getattr(result, "usage", None), getattr(result, "model", None))
            messages = [m.model_dump() for m in result.messages]
            text = "\n".join(f"[{m.role}] {m.content}" for m in result.messages)
            return {"status": "ok", "description": result.description, "messages": messages, "text": text}

        request_args = _normalize_and_validate_tool_request(ctx, session, method, request_args)
        op = _call_tool_with_optional_meta(session, method, request_args, correlation.to_mcp_meta())
        result = await (asyncio.wait_for(op, timeout=timeout) if timeout is not None else op)
        _runtime._extract_usage_telemetry(ctx, result.usage, result.model)
        _emit_mcp_progress_events_as_thinking(ctx, result.content, correlation, realtime_progress_fingerprints)
        cleaned_content = _strip_progress_events(copy.deepcopy(result.content))
        is_error = bool(result.is_error) or (detect_result_errors and _is_mcp_result_error_envelope(cleaned_content))
        output: dict[str, Any] = {
            "status": "error" if is_error else "ok",
            "response": cleaned_content,
            "correlation_id": correlation.correlation_id,
            "trace_id": correlation.trace_id,
        }
        if is_error:
            output["error"] = _build_mcp_error_object(cleaned_content, correlation)
        return output

    def _build_request_args(self, input_obj: dict[str, Any], ctx: StepExecutionContext) -> Any:
        if input_obj.get("request") is not None:
            return input_obj.get("request")

        request_template = input_obj.get("request_template")
        if request_template is None:
            return None

        template_data = input_obj.get("template_data")
        if not isinstance(template_data, dict):
            template_data = ctx.data

        try:
            rendered = MustacheEngine.render(str(request_template), template_data)
        except Exception as exc:
            raise WorkflowRuntimeException(ErrorCodes.TEMPLATE_SYNTAX, f"mcp.call request_template rendering failed: {exc}") from exc

        try:
            return json.loads(rendered)
        except Exception as exc:
            raise WorkflowRuntimeException(ErrorCodes.JSON_PARSE, f"mcp.call request_template rendered invalid JSON: {exc}") from exc


    async def _execute_llm_assisted(
        self,
        ctx: StepExecutionContext,
        session: IMcpSession,
        input_obj: dict[str, Any],
        default_kind: str,
        single_method: str | None,
        batch_methods: list[Any] | None,
        error_policy: dict[str, bool],
        timeout: float | None,
        realtime_progress_fingerprints: set[str] | None,
        request_context: dict[str, Any] | None,
    ) -> dict[str, Any]:
        llm_client = ctx.engine.llm_client
        if llm_client is None:
            raise WorkflowRuntimeException(ErrorCodes.LLM_NETWORK, "mcp.call prompt mode requires an LLM client")

        provider, model = ctx.engine.resolve_llm_target(input_obj.get("provider"), input_obj.get("model"))
        if not model:
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call prompt mode requires 'model' unless runtime default is configured")

        prompt = input_obj.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call prompt mode requires a non-empty 'prompt'")

        temperature = None
        if input_obj.get("temperature") is not None:
            temperature = float(input_obj["temperature"])

        allowed = None
        if batch_methods is not None:
            allowed = {str(m) for m in batch_methods}
        elif single_method:
            allowed = {single_method}

        capabilities: list[dict[str, Any]] = []
        used_names: set[str] = set()

        for node in input_obj.get("tools", []) if isinstance(input_obj.get("tools"), list) else []:
            if not isinstance(node, dict):
                continue
            name = node.get("name")
            if not isinstance(name, str) or (allowed is not None and name not in allowed):
                continue
            internal = _build_unique_internal_name(name, "tool", used_names)
            capabilities.append(
                {
                    "internal": internal,
                    "method": name,
                    "kind": "tool",
                    "tool": LLMTool(name=internal, description=node.get("description"), input_schema=node.get("input_schema") or node.get("inputSchema")),
                }
            )

        for node in input_obj.get("prompts", []) if isinstance(input_obj.get("prompts"), list) else []:
            if not isinstance(node, dict):
                continue
            name = node.get("name")
            if not isinstance(name, str) or (allowed is not None and name not in allowed):
                continue
            internal = _build_unique_internal_name(name, "prompt", used_names)
            capabilities.append(
                {
                    "internal": internal,
                    "method": name,
                    "kind": "prompt",
                    "tool": LLMTool(name=internal, description=node.get("description"), input_schema=_prompt_argument_schema(node.get("arguments"))),
                }
            )

        if not capabilities:
            cache = ctx.engine.mcp_cache
            server_name = getattr(session, "server_name", input_obj.get("server", ""))
            if default_kind == "prompt":
                prompts = get_cached_prompts(cache, server_name)
                if prompts is None:
                    prompts = await _try_list_prompts(session, server_name, ctx, timeout)
                    cache_prompts(cache, server_name, prompts)
                for p in prompts:
                    if allowed is not None and p.name not in allowed:
                        continue
                    internal = _build_unique_internal_name(p.name, "prompt", used_names)
                    capabilities.append(
                        {
                            "internal": internal,
                            "method": p.name,
                            "kind": "prompt",
                            "tool": LLMTool(name=internal, description=p.description, input_schema=_prompt_argument_schema(p.arguments)),
                        }
                    )
            else:
                tools = get_cached_tools(cache, server_name)
                if tools is None:
                    tools = await _maybe_timeout(session.list_tools_async(), timeout)
                    cache_tools(cache, server_name, tools)
                for t in tools:
                    if allowed is not None and t.name not in allowed:
                        continue
                    internal = _build_unique_internal_name(t.name, "tool", used_names)
                    capabilities.append(
                        {
                            "internal": internal,
                            "method": t.name,
                            "kind": "tool",
                            "tool": LLMTool(name=internal, description=t.description, input_schema=t.input_schema),
                        }
                    )

        if not capabilities:
            ctx.set_telemetry_attribute("gen_ai.system", provider or "default")
            ctx.set_telemetry_attribute("gen_ai.request.model", model)
            ctx.set_telemetry_attribute("gen_ai.response.finish_reason", "stop")
            return {"status": "ok", "selection_mode": "llm", "tool_calls": [], "results": [], "text": "No MCP capabilities available for selection."}

        ctx.set_telemetry_attribute("gen_ai.system", provider or "default")
        ctx.set_telemetry_attribute("gen_ai.request.model", model)
        ctx.set_telemetry_attribute("mcp.capabilities_count", len(capabilities))

        selection_prompt = _runtime._build_llm_selection_prompt(prompt)
        selection_request = ctx.engine.sanitize_llm_request(
            LLMRequest(
                provider=provider,
                model=model,
                prompt=selection_prompt,
                temperature=temperature,
                tools=[c["tool"] for c in capabilities],
            )
        )
        if selection_request.temperature is not None:
            ctx.set_telemetry_attribute("gen_ai.request.temperature", selection_request.temperature)
        if ctx.limits.log_step_content:
            ctx.add_telemetry_event(
                "gen_ai.content.prompt",
                [("gen_ai.prompt", selection_prompt), ("prompt.role", "user"), ("gnougo-flow.mcp.phase", "selection")],
            )

        llm_response = await ctx.engine.call_llm_async(selection_request)

        finish_reason = "tool_calls" if llm_response.tool_calls else "stop"
        ctx.set_telemetry_attribute("gen_ai.response.model", model)
        ctx.set_telemetry_attribute("gen_ai.response.finish_reason", finish_reason)
        _runtime._extract_usage_telemetry(ctx, llm_response.usage, model, provider)

        if ctx.limits.log_step_content and (llm_response.text or llm_response.json_payload is not None):
            completion_payload = llm_response.text if llm_response.text else json.dumps(llm_response.json_payload, ensure_ascii=False)
            ctx.add_telemetry_event(
                "gen_ai.content.completion",
                [
                    ("gen_ai.completion", completion_payload),
                    ("completion.role", "assistant"),
                    ("completion.finish_reason", finish_reason),
                    ("gnougo-flow.mcp.phase", "selection"),
                ],
            )

        if not llm_response.tool_calls:
            err = ErrorCodes.MCP_PROMPT_ERROR if default_kind == "prompt" else ErrorCodes.MCP_CALL_ERROR
            raise WorkflowRuntimeException(err, "mcp.call prompt mode did not select any MCP tool or prompt")

        cap_map = {c["internal"]: c for c in capabilities}
        tool_calls_out: list[dict[str, Any]] = []
        results_out: list[dict[str, Any]] = []
        has_error = False

        for tc in llm_response.tool_calls:
            cap = cap_map.get(tc.name)
            if not cap:
                err = ErrorCodes.MCP_PROMPT_ERROR if default_kind == "prompt" else ErrorCodes.MCP_CALL_ERROR
                raise WorkflowRuntimeException(err, f"mcp.call prompt mode selected unknown MCP capability '{tc.name}'")

            correlation = _build_mcp_correlation_context(
                ctx,
                getattr(session, "server_name", input_obj.get("server", "")),
                cap["kind"],
                cap["method"],
                request_context,
            )
            result_item = await self._call_single(
                ctx,
                session,
                cap["kind"],
                cap["method"],
                tc.arguments,
                correlation,
                realtime_progress_fingerprints,
                timeout,
                error_policy["detect_result_errors"],
            )
            result_item["method"] = cap["method"]
            result_item["kind"] = cap["kind"]
            if tc.id:
                result_item["call_id"] = tc.id
            has_error = has_error or result_item.get("status") == "error"
            results_out.append(result_item)

            call_obj = {"name": cap["method"], "kind": cap["kind"], "arguments": tc.arguments}
            if tc.id:
                call_obj["id"] = tc.id
            tool_calls_out.append(call_obj)

        if len(llm_response.tool_calls) == 1:
            only = cap_map[llm_response.tool_calls[0].name]
            ctx.set_telemetry_attribute("mcp.method.name", only["method"])
            ctx.set_telemetry_attribute("mcp.kind", only["kind"])
        ctx.set_telemetry_attribute("mcp.methods_count", len(llm_response.tool_calls))

        response: dict[str, Any] = {
            "status": "error" if has_error else "ok",
            "selection_mode": "llm",
            "text": llm_response.text,
            "tool_calls": tool_calls_out,
            "results": results_out,
        }

        if error_policy["raise_on_error"] and has_error:
            _raise_mcp_llm_assisted_error(default_kind, getattr(session, "server_name", input_obj.get("server", "")), response)

        structured = input_obj.get("structured_output") if isinstance(input_obj.get("structured_output"), dict) else None
        schema = structured.get("schema_inline") or structured.get("schema_ref") if structured else None
        strict = bool(structured.get("strict")) if structured and "strict" in structured else None
        if schema is not None:
            finalize_prompt = _runtime._build_structured_post_process_prompt(prompt, tool_calls_out, results_out)
            if ctx.limits.log_step_content:
                ctx.add_telemetry_event(
                    "gen_ai.content.prompt",
                    [("gen_ai.prompt", finalize_prompt), ("prompt.role", "user"), ("gnougo-flow.mcp.phase", "finalize")],
                )

            finalize_request = ctx.engine.sanitize_llm_request(
                LLMRequest(
                    provider=provider,
                    model=model,
                    prompt=finalize_prompt,
                    temperature=temperature,
                    structured_output_schema=schema,
                    structured_output_strict=strict,
                )
            )
            finalize_response = await ctx.engine.call_llm_async(finalize_request)
            _runtime._extract_usage_telemetry(ctx, finalize_response.usage, model, provider)

            structured_json = finalize_response.json_payload
            if structured_json is None and finalize_response.text:
                try:
                    structured_json = json.loads(_strip_markdown_code_fences(finalize_response.text))
                except Exception:
                    structured_json = None

            if structured_json is None:
                raise WorkflowRuntimeException(
                    ErrorCodes.LLM_SCHEMA,
                    "mcp.call structured_output expected valid JSON but the LLM "
                    "returned an incompatible response",
                    retryable=True,
                )

            response["selection_text"] = llm_response.text
            response["json"] = structured_json
            if finalize_response.text:
                response["text"] = finalize_response.text

        return response


def _strip_markdown_code_fences(text: str) -> str:
    """Strip markdown code fences (```json...``` or ```...```) that LLMs sometimes
    wrap around structured JSON responses."""
    trimmed = text.strip()
    if not trimmed.startswith("```"):
        return trimmed
    first_newline = trimmed.find("\n")
    if first_newline < 0:
        return trimmed
    body = trimmed[first_newline + 1:]
    last_fence = body.rfind("```")
    if last_fence >= 0:
        body = body[:last_fence]
    return body.strip()


_PROGRESS_EVENT_KEYS = {"progressevents", "progress_events", "progress", "events"}


def _strip_progress_events(content: Any) -> Any:
    """Remove verbose progressEvents arrays from MCP tool call output (they are
    already emitted as telemetry thinking events and would bloat the step output)."""
    if not isinstance(content, dict):
        return content
    result = dict(content)
    for key in list(result.keys()):
        if key.lower() in _PROGRESS_EVENT_KEYS and isinstance(result[key], list):
            del result[key]
    return result


def _emit_mcp_progress_events_as_thinking(
    ctx: StepExecutionContext,
    content: Any,
    correlation: McpCorrelationContext,
    realtime_progress_fingerprints: set[str] | None,
) -> None:
    for progress_event in _enumerate_mcp_progress_events(content):
        message = _sanitize_thinking_message(_get_case_insensitive(progress_event, "message"))
        if not message:
            continue
        event_kind = _string_or_none(_get_case_insensitive(progress_event, "kind"))
        file = _string_or_none(_get_case_insensitive(progress_event, "file"))
        if realtime_progress_fingerprints is not None and _build_progress_fingerprint(event_kind, message, file) in realtime_progress_fingerprints:
            continue
        level = _normalize_thinking_level(_get_case_insensitive(progress_event, "level"))
        attributes: list[tuple[str, Any]] = [
            ("gnougo-flow.thinking.message", message),
            ("gnougo-flow.thinking.level", level),
            ("gnougo-flow.thinking.source", "mcp.progress"),
            ("mcp.server.name", correlation.mcp_server),
            ("mcp.method.name", correlation.mcp_method),
            ("mcp.kind", correlation.mcp_kind),
        ]
        if event_kind:
            attributes.append(("gnougo-flow.thinking.kind", event_kind))
        if file:
            attributes.append(("gnougo-flow.thinking.file", file))
        timestamp = _string_or_none(_get_case_insensitive(progress_event, "timestamp"))
        if timestamp:
            attributes.append(("gnougo-flow.thinking.timestamp", timestamp))
        ctx.add_telemetry_event("gnougo-flow.step.thinking", attributes)


def _emit_realtime_mcp_progress_event_as_thinking(
    ctx: StepExecutionContext,
    progress_event: McpRealtimeProgressEvent,
    fallback_correlation: McpCorrelationContext,
) -> None:
    message = _sanitize_thinking_message(progress_event.message)
    if not message:
        return
    attributes: list[tuple[str, Any]] = [
        ("gnougo-flow.thinking.message", message),
        ("gnougo-flow.thinking.level", _normalize_thinking_level(progress_event.level)),
        ("gnougo-flow.thinking.source", "mcp.realtime_progress"),
        ("mcp.server.name", progress_event.server_name or fallback_correlation.mcp_server),
        ("mcp.method.name", progress_event.method_name or fallback_correlation.mcp_method),
        ("mcp.kind", progress_event.kind or fallback_correlation.mcp_kind),
    ]
    if progress_event.event_kind:
        attributes.append(("gnougo-flow.thinking.kind", progress_event.event_kind))
    if progress_event.file:
        attributes.append(("gnougo-flow.thinking.file", progress_event.file))
    if progress_event.timestamp:
        attributes.append(("gnougo-flow.thinking.timestamp", progress_event.timestamp))
    if progress_event.correlation_id:
        attributes.append(("gnougo.correlation_id", progress_event.correlation_id))
    ctx.add_telemetry_event("gnougo-flow.step.thinking", attributes)


def _emit_realtime_mcp_human_input_signal(
    ctx: StepExecutionContext,
    signal: McpHumanInputSignal,
) -> None:
    correlation = signal.correlation
    request = signal.request
    common = [
        ("mcp.server.name", _first_correlation_value(correlation, "mcp_server", "server_name")),
        ("mcp.method.name", _first_correlation_value(correlation, "mcp_method", "method_name")),
        ("mcp.kind", _first_correlation_value(correlation, "mcp_kind", "kind")),
    ]
    if signal.phase == McpHumanInputSignalPhase.WAITING:
        ctx.add_telemetry_event(
            "gnougo-flow.step.waiting_for_human",
            [
                ("gnougo-flow.human.prompt", request.prompt),
                (
                    "gnougo-flow.human.request",
                    json.dumps(request.model_dump(), ensure_ascii=False, default=str),
                ),
                ("gnougo-flow.human.phase", "waiting"),
                *common,
            ],
        )
        return
    ctx.add_telemetry_event(
        "gnougo-flow.step.human_input_resumed",
        [
            ("gnougo-flow.human.run_id", request.run_id),
            ("gnougo-flow.human.step_id", request.step_id),
            ("gnougo-flow.human.phase", signal.phase.value),
            *common,
        ],
    )


def _first_correlation_value(correlation: Any, *names: str) -> Any:
    for name in names:
        value = getattr(correlation, name, None) if not isinstance(correlation, dict) else correlation.get(name)
        if value is not None:
            return value
    return None


def _enumerate_mcp_progress_events(content: Any) -> list[dict[str, Any]]:
    if not isinstance(content, dict):
        return []
    events = None
    for name in ("progressEvents", "progress_events", "progress", "events"):
        events = _get_case_insensitive(content, name)
        if isinstance(events, list):
            break
    if not isinstance(events, list):
        return []
    return [item for item in events if isinstance(item, dict)]


def _get_case_insensitive(values: dict[str, Any], name: str) -> Any:
    for key, value in values.items():
        if key.lower() == name.lower():
            return value
    return None


def _normalize_thinking_level(level: Any) -> str:
    text = str(level).strip().lower() if level is not None else ""
    if not text:
        return "thinking"
    if text == "warn":
        return "warning"
    return text if text in {"thinking", "info", "warning", "error", "debug"} else "thinking"


def _sanitize_thinking_message(message: Any) -> str | None:
    if message is None:
        return None
    text = str(message).strip()
    if not text:
        return None
    return text if len(text) <= 1000 else text[:1000] + "..."


def _build_progress_fingerprint(event_kind: str | None, message: str | None, file: str | None) -> str:
    return "\x1f".join((event_kind or "", message or "", file or ""))


def _extract_error_message(content: Any) -> str:
    if content is None:
        return "MCP tool returned an error without content."
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        for key in ("error_message", "message", "error", "detail", "response"):
            value = _get_case_insensitive(content, key)
            if isinstance(value, str) and value.strip():
                return value
    return json.dumps(content, ensure_ascii=False, default=str)


def _extract_error_code(content: Any) -> str | None:
    if not isinstance(content, dict):
        return None
    for key in ("error_code", "errorCode", "code"):
        value = _get_case_insensitive(content, key)
        if isinstance(value, str) and value.strip():
            return value
    return None


def _build_mcp_error_object(content: Any, correlation: McpCorrelationContext) -> dict[str, Any]:
    message = _extract_error_message(content)
    return {
        "message": message,
        "mcp_error_code": _extract_error_code(content),
        "mcp_error_message": message,
        "content": copy.deepcopy(content),
        "correlation_id": correlation.correlation_id,
        "run_id": correlation.run_id,
        "trace_id": correlation.trace_id,
        "span_id": correlation.span_id,
        "traceparent": correlation.traceparent,
        "server": correlation.mcp_server,
        "method": correlation.mcp_method,
        "kind": correlation.mcp_kind,
    }


def _resolve_mcp_error_policy(input_obj: dict[str, Any]) -> dict[str, bool]:
    raise_on_error = _optional_bool(_get_case_insensitive(input_obj, "raise_on_error"))
    if raise_on_error is None:
        raise_on_error = _optional_bool(_get_case_insensitive(input_obj, "raiseOnError"))
    raise_on_error = True if raise_on_error is None else bool(raise_on_error)

    detect_result_errors = raise_on_error
    policy = _get_case_insensitive(input_obj, "error_policy")
    if isinstance(policy, dict):
        configured = _optional_bool(_get_case_insensitive(policy, "detect_result_errors"))
        if configured is None:
            configured = _optional_bool(_get_case_insensitive(policy, "detectResultErrors"))
        if configured is not None:
            detect_result_errors = configured
    else:
        configured = _optional_bool(_get_case_insensitive(input_obj, "detect_result_errors"))
        if configured is None:
            configured = _optional_bool(_get_case_insensitive(input_obj, "detectResultErrors"))
        if configured is not None:
            detect_result_errors = configured

    return {"raise_on_error": raise_on_error, "detect_result_errors": bool(detect_result_errors)}


def _optional_bool(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized == "true":
            return True
        if normalized == "false":
            return False
    return None


def _is_mcp_result_error_envelope(content: Any) -> bool:
    if not isinstance(content, dict):
        return False

    success = _get_case_insensitive(content, "success")
    if success is False:
        return True

    ok = _get_case_insensitive(content, "ok")
    if ok is False:
        return True

    status = _get_case_insensitive(content, "status")
    if isinstance(status, str) and status.strip().lower() in {"error", "failed", "failure"}:
        return True

    if _extract_error_code(content):
        return True

    for key in ("error_message", "errorMessage"):
        value = _get_case_insensitive(content, key)
        if isinstance(value, str) and value.strip():
            return True

    error = _get_case_insensitive(content, "error")
    if error is not None and (not isinstance(error, str) or bool(error.strip())):
        return True

    code = _get_case_insensitive(content, "code")
    message = _get_case_insensitive(content, "message")
    return isinstance(code, str) and bool(code.strip()) and isinstance(message, str) and bool(message.strip()) and len(content) <= 3


def _raise_mcp_single_error(kind: str, server: str, method: str, result: dict[str, Any]) -> None:
    details = _build_mcp_exception_details(kind, server, method, result)
    message = str(details.get("message") or f"mcp.call ({kind}) to '{server}/{method}' returned an MCP error.")
    code = ErrorCodes.MCP_PROMPT_ERROR if kind == "prompt" else ErrorCodes.MCP_CALL_ERROR
    raise WorkflowRuntimeException(
        code,
        f"mcp.call ({kind}) to '{server}/{method}' returned an MCP error: {message}",
        retryable=False,
        details=details,
    )


def _raise_mcp_batch_error(kind: str, server: str, methods: list[Any], result: dict[str, Any]) -> None:
    method_text = ", ".join(str(m) for m in methods)
    details = _build_mcp_aggregate_exception_details(kind, server, method_text, result)
    message = str(details.get("message") or f"mcp.call ({kind}) to '{server}/{method_text}' returned one or more MCP errors.")
    code = ErrorCodes.MCP_PROMPT_ERROR if kind == "prompt" else ErrorCodes.MCP_CALL_ERROR
    raise WorkflowRuntimeException(
        code,
        f"mcp.call ({kind}) to '{server}/{method_text}' returned one or more MCP errors: {message}",
        retryable=False,
        details=details,
    )


def _raise_mcp_llm_assisted_error(kind: str, server: str, result: dict[str, Any]) -> None:
    details = _build_mcp_aggregate_exception_details(kind, server, "(llm-selection)", result)
    message = str(details.get("message") or f"mcp.call prompt mode on '{server}' returned one or more MCP errors.")
    code = ErrorCodes.MCP_PROMPT_ERROR if kind == "prompt" else ErrorCodes.MCP_CALL_ERROR
    raise WorkflowRuntimeException(
        code,
        f"mcp.call prompt mode on '{server}' returned one or more MCP errors: {message}",
        retryable=False,
        details=details,
    )


def _build_mcp_exception_details(kind: str, server: str, method: str, result: dict[str, Any]) -> dict[str, Any]:
    error = result.get("error")
    if isinstance(error, dict):
        details = copy.deepcopy(error)
    else:
        response = result.get("response")
        details = {
            "message": _extract_error_message(response),
            "mcp_error_code": _extract_error_code(response),
            "mcp_error_message": _extract_error_message(response),
            "content": copy.deepcopy(response),
        }
    details["server"] = details.get("server") or server
    details["method"] = details.get("method") or method
    details["kind"] = details.get("kind") or kind
    details["status"] = result.get("status")
    details["response"] = copy.deepcopy(result.get("response"))
    return details


def _build_mcp_aggregate_exception_details(kind: str, server: str, method: str, result: dict[str, Any]) -> dict[str, Any]:
    first_error = _find_first_error_result(result)
    if first_error is not None:
        details = _build_mcp_exception_details(
            str(first_error.get("kind") or kind),
            server,
            str(first_error.get("method") or method),
            first_error,
        )
    else:
        details = {"message": "MCP call returned one or more errors."}
    details["server"] = details.get("server") or server
    details["method"] = method
    details["kind"] = kind
    details["results"] = copy.deepcopy(result.get("results"))
    details["content"] = copy.deepcopy(result)
    return details


def _find_first_error_result(result: dict[str, Any]) -> dict[str, Any] | None:
    results = result.get("results")
    if not isinstance(results, list):
        return None
    for item in results:
        if isinstance(item, dict) and str(item.get("status", "")).lower() == "error":
            return item
    return None


def _string_or_none(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _get_property(value: Any, name: str) -> Any:
    if isinstance(value, dict):
        return value.get(name)
    return getattr(value, name, None)


def _build_mcp_correlation_context(
    ctx: StepExecutionContext,
    server_name: str,
    kind: str,
    method: str | None,
    request_context: dict[str, Any] | None = None,
) -> McpCorrelationContext:
    trace_context = _capture_current_trace_context(ctx)
    traceparent = trace_context.get("traceparent")
    parsed_trace_id, parsed_parent_span_id = _parse_traceparent(traceparent)
    trace_id = trace_context.get("trace_id") or parsed_trace_id
    span_id = trace_context.get("span_id") or parsed_parent_span_id

    return McpCorrelationContext(
        tenant_id=ctx.limits.tenant_id or os.environ.get("GNouGo__TenantId"),
        traceparent=traceparent,
        tracestate=trace_context.get("tracestate"),
        trace_id=trace_id,
        span_id=span_id,
        parent_span_id=trace_context.get("parent_span_id") or parsed_parent_span_id or span_id,
        correlation_id=ctx.limits.run_id or trace_id or uuid.uuid4().hex,
        run_id=ctx.limits.run_id,
        execution_id=ctx.limits.execution_id or ctx.limits.run_id,
        agent_id=ctx.limits.agent_id,
        agent_name=ctx.limits.agent_name,
        step_id=ctx.step.id,
        step_type=ctx.step.type,
        mcp_server=server_name,
        mcp_method=method,
        mcp_kind=kind,
        context=copy.deepcopy(request_context),
    )


_RESERVED_MCP_CONTEXT_KEYS = {
    "correlationid",
    "tenantid",
    "runid",
    "executionid",
    "agentid",
    "agentname",
    "traceid",
    "spanid",
    "parentspanid",
    "traceparent",
    "tracestate",
    "stepid",
    "steptype",
    "mcpserver",
    "mcpmethod",
    "mcpkind",
}


def _validate_mcp_request_context(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if not isinstance(value, dict):
        raise WorkflowRuntimeException(ErrorCodes.INPUT_VALIDATION, "mcp.call context must be an object.")

    def visit(node: Any, path: str) -> None:
        if isinstance(node, dict):
            for key, child in node.items():
                field_path = f"{path}.{key}"
                normalized = str(key).replace("-", "").replace("_", "").lower()
                if normalized in _RESERVED_MCP_CONTEXT_KEYS:
                    raise WorkflowRuntimeException(
                        ErrorCodes.INPUT_VALIDATION,
                        f"mcp.call context field '{field_path}' is reserved technical metadata.",
                    )
                if any(part in normalized for part in ("secret", "token", "password", "authorization", "credential", "apikey")):
                    raise WorkflowRuntimeException(
                        ErrorCodes.INPUT_VALIDATION,
                        f"mcp.call context field '{field_path}' is not allowed because context must not carry credentials or secrets.",
                    )
                visit(child, field_path)
        elif isinstance(node, list):
            for index, child in enumerate(node):
                visit(child, f"{path}[{index}]")

    visit(value, "context")
    return copy.deepcopy(value)


def _capture_current_trace_context(ctx: StepExecutionContext) -> dict[str, str]:
    from_otel = _capture_opentelemetry_context()
    if from_otel:
        return from_otel

    span = ctx.telemetry_span
    values: dict[str, str] = {}
    for source_name, target_name in (
        ("traceparent", "traceparent"),
        ("tracestate", "tracestate"),
        ("trace_state", "tracestate"),
        ("trace_id", "trace_id"),
        ("span_id", "span_id"),
        ("parent_span_id", "parent_span_id"),
    ):
        value = getattr(span, source_name, None)
        if isinstance(value, str) and value.strip():
            values[target_name] = value

    attributes = getattr(span, "attributes", None)
    if isinstance(attributes, dict):
        for source_name, target_name in (
            ("traceparent", "traceparent"),
            ("tracestate", "tracestate"),
            ("trace_id", "trace_id"),
            ("span_id", "span_id"),
            ("parent_span_id", "parent_span_id"),
        ):
            value = attributes.get(source_name)
            if isinstance(value, str) and value.strip():
                values.setdefault(target_name, value)

    values.setdefault("traceparent", os.environ.get("TRACEPARENT") or os.environ.get("GNouGo__TraceParent") or "")
    values.setdefault("tracestate", os.environ.get("TRACESTATE") or os.environ.get("GNouGo__TraceState") or "")
    values.setdefault("trace_id", os.environ.get("GNouGo__TraceId") or "")
    values.setdefault("span_id", os.environ.get("GNouGo__SpanId") or "")
    return {key: value for key, value in values.items() if value}


def _capture_opentelemetry_context() -> dict[str, str]:
    try:
        from opentelemetry import trace  # type: ignore[import-not-found]
        from opentelemetry.trace import INVALID_SPAN_CONTEXT  # type: ignore[import-not-found]
    except Exception:
        return {}

    try:
        span = trace.get_current_span()
        span_context = span.get_span_context()
        if span_context is INVALID_SPAN_CONTEXT or not getattr(span_context, "is_valid", False):
            return {}

        trace_id = f"{span_context.trace_id:032x}"
        span_id = f"{span_context.span_id:016x}"
        flags = int(getattr(span_context, "trace_flags", 0)) & 0xFF
        values = {
            "traceparent": f"00-{trace_id}-{span_id}-{flags:02x}",
            "trace_id": trace_id,
            "span_id": span_id,
        }
        trace_state = str(getattr(span_context, "trace_state", "") or "")
        if trace_state:
            values["tracestate"] = trace_state
        parent = getattr(span, "parent", None)
        parent_span_id = getattr(parent, "span_id", None)
        if isinstance(parent_span_id, int) and parent_span_id:
            values["parent_span_id"] = f"{parent_span_id:016x}"
        return values
    except Exception:
        return {}


def _parse_traceparent(traceparent: str | None) -> tuple[str | None, str | None]:
    if not traceparent:
        return None, None
    parts = traceparent.split("-")
    if len(parts) < 4:
        return None, None
    return parts[1], parts[2]


def _normalize_and_validate_tool_request(
    ctx: StepExecutionContext,
    session: IMcpSession,
    method: str,
    request_args: Any,
) -> Any:
    server_name = getattr(session, "server_name", "")
    tools = get_cached_tools(ctx.engine.mcp_cache, server_name)
    factory_metadata = getattr(ctx.engine.mcp_client_factory, "server_metadata", None)
    if tools == [] and not factory_metadata:
        tools = None
    if tools is None:
        return request_args

    tool = next((candidate for candidate in tools if candidate.name == method), None)
    if tool is None:
        available = sorted(candidate.name for candidate in tools if candidate.name)
        if not available:
            raise WorkflowRuntimeException(
                ErrorCodes.MCP_CALL_ERROR,
                f"MCP server '{server_name}' exposes no tools; '{method}' cannot be called.",
            )
        raise WorkflowRuntimeException(
            ErrorCodes.MCP_CALL_ERROR,
            f"MCP tool '{method}' does not exist on server '{server_name}'. Available tools: [{', '.join(available)}].",
        )
    schema = tool.input_schema
    if not isinstance(schema, dict):
        return request_args

    normalized = _omit_null_optional_properties(copy.deepcopy(request_args), schema)
    errors = validate_instance(normalized, schema)
    if errors:
        raise WorkflowRuntimeException(
            ErrorCodes.INPUT_VALIDATION,
            f"mcp.call request for '{server_name}/{method}' failed runtime JSON Schema validation: {'; '.join(errors)}",
            details={"server": server_name, "method": method, "validation_errors": errors},
        )
    return normalized


def _omit_null_optional_properties(value: Any, schema: Any) -> Any:
    if not isinstance(schema, dict):
        return value
    if isinstance(value, dict):
        properties = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
        required = {str(item) for item in schema.get("required", []) if isinstance(item, str)}
        for key in list(value):
            property_schema = properties.get(key)
            if value[key] is None and key not in required and property_schema is not None:
                value.pop(key)
                continue
            if property_schema is not None:
                value[key] = _omit_null_optional_properties(value[key], property_schema)
        return value
    if isinstance(value, list) and isinstance(schema.get("items"), dict):
        return [_omit_null_optional_properties(item, schema["items"]) for item in value]
    return value


async def _call_tool_with_optional_meta(
    session: IMcpSession,
    method: str,
    request_args: Any,
    mcp_meta: dict[str, Any],
) -> Any:
    call_tool = session.call_tool_async
    try:
        parameters = inspect.signature(call_tool).parameters
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in parameters.values()) or "mcp_meta" in parameters:
            return await call_tool(method, request_args, mcp_meta=mcp_meta)
    except (TypeError, ValueError):
        pass

    try:
        return await call_tool(method, request_args, mcp_meta)
    except TypeError:
        return await call_tool(method, request_args)


def _add_if_present(values: dict[str, Any], key: str, value: Any) -> None:
    if value is not None and str(value).strip():
        values[key] = value
