# quickstart — 5-minute walkthrough

🇨🇳 [简体中文](../cn/quickstart.md)

## 0. Install

```bash
pip install pavoz
```

Confirm which version is actually loaded — **trust `__version__` + the load path, not
`pip list`**:

```bash
python -c "import pavoz; print(pavoz.__version__, pavoz.__file__)"
```

`pip list` only reflects the dist-info **at install time**: with an editable install
(`pip install -e .`), repo code can change while `pip list` still shows the old version —
so "I changed the code and nothing happened" gets misdiagnosed as a code problem (field
report from ai@home, haomem id=3653).

## 1. Define a DAG

```python
# dags/my_pipeline.py
from pavoz import DAG

dag = DAG("my_pipeline")

@dag.stage()
async def s_fetch(ctx):
    # ctx.state is read-only. return dict writes state.
    return {"items": ["a", "b", "c"]}

@dag.stage(depends_on=["s_fetch"], retries=2, timeout=120)
async def s_process(ctx):
    items = ctx.state["items"]
    return {"count": len(items)}

@dag.stage(depends_on=["s_process"])
async def s_save(ctx):
    return {"saved": ctx.state["count"] > 0}
```

## 2. Run via CLI

```bash
python -m pavoz run dags/my_pipeline.py
# Outputs JSON: {task_id, dag, status, stage_statuses, state}
```

With initial state + checkpoint (resume):

```bash
PAVOZ_STORAGE=/data/sf \
python -m pavoz run dags/my_pipeline.py \
  --task-id task-1 --input '{"query": "north-china-tech"}'

# ⚠️ The next command is **not** a continuation of the one above — `--resume` is
#    for after an **interruption**. Resuming a task that already completed hits
#    the done guard: "already completed; rerun with resume=False (new run_id)".
#    (Copying the two lines above back-to-back always fails, and the error talks
#    about how to rerun, not about why --resume doesn't belong there.)
PAVOZ_STORAGE=/data/sf \
python -m pavoz run dags/my_pipeline.py --task-id task-1 --resume
```

## 3. Run from code

```python
import asyncio
from pavoz import Runtime, CheckpointStore
from pavoz.storage import FileStorage
from dags.my_pipeline import dag

async def main():
    rt = Runtime(checkpoint_store=CheckpointStore(FileStorage("/data/sf")))
    # First run: resume=False (default) — starts a fresh run_id.
    # If interrupted, rerun with resume=True to skip completed stages
    # (reuses the run_id; raises if the run already completed).
    result = await rt.run(dag, task_id="task-1", initial_state={"query": "x"})
    print(result.status, result.state, result.run_id)

asyncio.run(main())
```

## 4. External calls (`ctx.call`)

Stages don't import `requests`/`httpx` directly — all external calls go through `ctx.call(kind, op, params)`:

```python
@dag.stage()
async def s_search(ctx):
    results = await ctx.call("search", "my_engine", {"query": ctx.state["query"]})  # kind/op defined by business caller
    return {"sources": results["items"]}
```

The default caller is a no-op echo. Real calls are injected by your business code:

```python
rt = Runtime(caller=my_business_caller)  # async (kind, op, params) -> dict
```

## 5. Regression testing (`TestPipe`)

```python
import pytest
from pavoz import TestPipe
from dags.my_pipeline import dag

@pytest.mark.asyncio
async def test_pipeline_with_mocked_search():
    pipe = TestPipe(dag)
    pipe.mock("s_fetch", lambda state: {"items": ["a"]})
    result = await pipe.run()
    assert result.state["count"] == 1
```

## CLI commands (v0.5.1)

Every `run` persists a checkpoint after each completed stage (single runs
included, v0.5.1) — `trace`/`state`/`replay` work on any CLI run:

| Command | Purpose |
|---|---|
| `run <dag.py> [--task-id X] [--input JSON] [--resume]` | Run a DAG (persists checkpoints per stage) |
| `trace --task-id X` | Inspect checkpoint / stage records |
| `state --task-id X [--key K]` | Inspect state snapshot |
| `replay <dag.py> --task-id X --stage S [--patch P.py]` | Replay one stage on its checkpoint-rebuilt input (upstream stages are not re-run) |

Replay example — after tuning a stage's prompt/params, rerun only `s_process`:

```bash
python -m pavoz replay dags/my_pipeline.py --task-id task-1 --stage s_process
```

Further reading:
- [architecture.md](architecture.md) — architecture and design decisions
- [api.md](api.md) — public API reference
- [use-cases/](use-cases/) — reference business integrations
