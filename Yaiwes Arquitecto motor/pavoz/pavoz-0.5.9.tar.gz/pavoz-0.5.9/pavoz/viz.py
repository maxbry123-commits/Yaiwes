"""DAG viz export (v0.5.4): Mermaid + JSON Graph 数据.

只出数据, caller 自渲染 (嵌入 README / 飞书 Mermaid, 或 Vue dagre/cytoscape 接 JSON).
不出 UI / drag-drop / server (原则 #4 '保持独立性'). 零依赖, ≤50 行.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .dag import DAG


# Mermaid 的**保留字**: 不能直接当节点 ID 用。
#
# ⚠️ 这份清单是**尽力而为, 可能不全** —— Mermaid 的语法表不在本仓, 我们也无法在
# 离线环境核对它。所以机制不能只靠清单: `_safe_id` 同时用正则兜住"不合法的 ID
# 形状"。清单的作用是把"形状合法但语义撞车"的那部分显式化, 便于发现新的就补
# 一行 —— 而漏掉一条的后果与修复前相同 (那个名字渲染坏), 不会更糟。
#
# 全部都是 Python 侧**合法**的标识符 (实测 `async def end/graph/...` 都能定义),
# 所以这不是"理论上不可能", 而是撞上了就渲染坏。
_MERMAID_RESERVED = frozenset({
    "end",        # 关闭 subgraph 的关键字
    "graph",      # `graph LR` 这个声明本身
    "flowchart",  # 新图类型关键字
    "subgraph",   # 子图声明
    "direction",  # 子图内的方向声明
    "click",      # 交互声明
    "style",      # 样式声明
    "classDef",   # 样式类定义
    "linkStyle",  # 边的样式声明
    "o", "x",     # `--o-->` / `--x-->` 这两种箭头的名字, 单独作 ID 会歧义
})

# 合法的 Mermaid 节点 ID: 字母/数字/下划线, 且不以数字开头。
_SAFE_ID_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# 会改变"行结构"的字符 —— Mermaid 一行一条语句, 文本里混进换行就会多出碎片行。
# 这是**唯一能证明会破图**的一类字符 (见 `_mmd_text` 的说明)。
_MMD_LINE_BREAK_RE = re.compile(r"[\r\n\t]+")


def _safe_id(name: str) -> str:
    """Mermaid 节点 ID — 合法标识符形状, 且避开 Mermaid 保留字。

    **标签不受影响**: 调用方写成 `_safe_id(x)["<原名>"]`, 图上显示的始终是
    stage 原名, 替换只发生在 Mermaid 内部的 ID 上。

    ⚠️ 本函数原先的注释写着"字母数字 + _ -. (兜底防 hyphen)", 而实现只有
    `name.replace(" ", "_")` —— **连字符根本没防**, `_safe_id("load-data")`
    原样返回 `load-data`。注释声称的边界与实现不符, 让读注释的人以为有防护。
    """
    if _SAFE_ID_RE.match(name) and name not in _MERMAID_RESERVED:
        return name
    # 退化路径: 换成肯定合法的 ID。显示名由调用方单独给出, 所以这里不必可读。
    safe = "".join(ch if ch.isalnum() and ch.isascii() else "_" for ch in name)
    if not safe or not (safe[0].isalpha() or safe[0] == "_"):
        safe = f"n_{safe}"
    if safe in _MERMAID_RESERVED:          # 归一化后仍可能撞车 (如 "e-n-d" → "e_n_d" 不会, 但 "end" 变体要防)
        safe = f"n_{safe}"
    return safe


def _id_map(dag: "DAG") -> dict[str, str]:
    """stage 名 → Mermaid ID, 保证**全图唯一**。

    唯一性必须在这里保证而不能靠 `_safe_id`: 退化路径 (名字含非 ASCII 等) 会把
    不同名字归一化成同一个串 —— 实测 `"中文名"` 与 `"别的字"` 都变成 `___`,
    两个节点共用一个 ID 就是渲染错。`_safe_id` 是纯函数看不到全图, 冲突只在这里
    才暴露得出来。

    按 sorted 建映射 (而不是 topo_order): 同样内容的 DAG 每次生成同样的 ID,
    输出可复现。
    """
    used: set[str] = set()
    out: dict[str, str] = {}
    for name in sorted(dag.stages):
        base = _safe_id(name)
        cand, k = base, 1
        while cand in used:
            cand = f"{base}_{k}"
            k += 1
        used.add(cand)
        out[name] = cand
    return out


def _mmd_text(s: str, *, quoted: bool = False) -> str:
    """把任意用户文本收敛成**能安全放进单行 Mermaid 语法**的片段.

    存在的理由 (2026-10-17): 用户文本原先是**原样**拼进去的, 而条件边的
    mapping key 完全不受限 —— 它就是 `route_fn` 的返回值, `add_conditional_edges`
    对它零校验。实测 key = "line1\\nline2" 会把一条边劈成两行:

        gate -.line1          ← 悬空节点声明
    line2.-> tgt              ← 碎片

    Mermaid 解析到这里直接失败 —— 不是"标签难看", 是**整张图渲染不出来**。而
    看图的人恰恰是 debug 的人 (只有出事了才去看图), 偏偏这时候看不到。

    收敛两样, 且**只**收敛这两样:
      · 换行 / 回车 / 制表符 → 单个空格。它们是唯一能改变"行结构"的字符, 也就是
        唯一能证明会破图的字符。
      · 引号 —— 仅在**被双引号包住**的节点标签位 (`quoted=True`): 裸引号会提前
        闭合标签, 后面全是垃圾。转成 Mermaid 的 `#quot;` 实体, 显示不受影响。

    边标签位里的 `"` / `;` / `-->` **故意不处理**: 本地没有 Mermaid 解析器, 它们
    究竟被当字面文本还是当语法**验不了**, 而拿验不了的假设写成"已处理"就是另一种
    形式的假绿。那是渲染器的活, 不是这里能替它断的。
    """
    out = _MMD_LINE_BREAK_RE.sub(" ", s)
    return out.replace('"', "#quot;") if quoted else out


def to_mermaid(dag: DAG, *, direction: str = "LR") -> str:
    """DAG → Mermaid 图 (默认 LR 布局; 嵌 README / 飞书).

    R1 (0.5.5): 条件边渲染为带 key 标签的虚线 — 逻辑分叉/回路在图上一等可见.

    节点 ID 经 `_safe_id` 处理 (保留字 / 非法字符), 但**标签恒为 stage 原名** ——
    替换只发生在 Mermaid 内部的 ID 上, 图上看到的永远是原名 (换行/引号除外, 那两
    类会破坏语法, 见 `_mmd_text`)。
    """
    ids = _id_map(dag)
    # direction 也是原样拼进首行的 (且无校验) —— 同一条通路, 一起收敛
    lines = [f"graph {_mmd_text(direction)}"]
    for name in dag.topo_order():
        lines.append(f'    {ids[name]}["{_mmd_text(name, quoted=True)}"]')
    # `dag.stages` 是**每次访问都建 dict 副本**的 property (有意如此: 调用方不该改到
    # 内部状态), 放进循环就是 O(N) 次 O(N) 的拷贝 = 平方项。导出 N 个 stage 的 DAG
    # 原本访问 2N+2 次, 提到循环外是 2 次 (`_id_map` 那一次 + 这里这一次)。
    # 墙钟收益实测 (旧模块 vs 新模块, 两者输出逐字节相同; 取 5 次最小值):
    #   N=800 → 22.6ms/20.3ms (1.12x), N=2000 → 150/127ms (1.18x), N=4000 → 655/562ms (1.17x)
    # **别把它说成数量级的改善**: 导出的主成本是拼字符串, 拷贝只占其中约 10-20%。
    # 拿掉的是平方项 (占比随规模继续涨), 这个才是判据钉住的东西。
    # 与 runtime.py 的同一处修法一致 —— `dag.validate()` 已冻结 dag, 导出期间结构
    # 不变, 提出来安全; 拷贝是**浅**的, Stage 对象共享, 故不影响读到的内容。
    stages = dag.stages
    for name in stages:
        for dep in stages[name].depends_on:
            lines.append(f"    {ids[dep]} --> {ids[name]}")
    for fname, edge in dag.conditional_edges.items():
        for key, tgt in sorted(edge.mapping.items()):
            lines.append(f'    {ids[fname]} -.{_mmd_text(key)}.-> {ids[tgt]}')
    return "\n".join(lines) + "\n"


def to_graph_json(dag: DAG) -> dict:
    """DAG → JSON-serializable dict (nodes + edges + topo_order + dag_name).

    R1 (0.5.5): edges 增加 kind ("static" | "conditional"); 条件边另带 key
    (分支标签) 与 max_visits — admin UI 可见逻辑分叉, 叠加 route 事件显示实际走向.
    """
    # 同 to_mermaid: 提到循环外 (这里原本是 nodes 循环 V 次 + edges 推导 V+1 次)
    stages = dag.stages
    nodes = []
    for name in dag.topo_order():
        stage = stages[name]
        nodes.append({
            "id": name,
            "name": name,
            "depends_on": list(stage.depends_on),
            "retries": stage.retries,
            "timeout": stage.timeout,
        })
    edges: list[dict[str, Any]] = [{"from": dep, "to": name, "kind": "static"}
                                   for name in stages
                                   for dep in stages[name].depends_on]
    for fname, edge in dag.conditional_edges.items():
        for key, tgt in sorted(edge.mapping.items()):
            edges.append({"from": fname, "to": tgt, "kind": "conditional",
                          "key": key, "max_visits": edge.max_visits})
    return {
        "dag_name": dag.name,
        "nodes": nodes,
        "edges": edges,
        "topo_order": dag.topo_order(),
    }