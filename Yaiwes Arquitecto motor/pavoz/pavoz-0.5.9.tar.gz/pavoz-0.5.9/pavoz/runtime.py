"""Runtime: 执行 DAG. 顺序执行 + per-node retries + absolute deadline + state merge + checkpoint.

流程 (一次 run = 一个 run_id):
    runtime.run(dag, task_id=None, initial_state, resume=False)
      ├─ task_id: 省略 → UUID4; 入口校验 (A3: 非空/≤128/字符集受限)
      ├─ resume=True → 按指针加载该 task 最新 checkpoint (复用其 run_id):
      │    ├─ 无 cp → RuntimeError; 已全部完成 → RuntimeError (done guard)
      │    ├─ DAG hash 变了 → CheckpointMismatchError
      │    └─ 恢复 state/done_stages/producers, 只跑未完成 stage
      ├─ 按拓扑序跑未完成 stage:
      │    ├─ 每 stage: 构造 ctx (含 task_id/run_id/attempt) → 深拷贝 state 快照 → 调 fn(ctx)
      │    ├─ StageError → fail 终态 (不重试)
      │    ├─ RetryableError → 扣 retries, 指数退避重试; 耗尽 → fail
      │    ├─ FatalError → 立即 fail (不消耗 retries)
      │    ├─ timeout → fail (RetryableError 语义, 可重试)
      │    └─ return dict → merge_state (冲突 → StateConflictError → fail)
      └─ 每 stage 后: checkpoint.save (runs/{task_id}/{run_id}/checkpoint + latest 指针)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import time
from collections.abc import Awaitable, Callable
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any

from ._id import new_id
from .cancel import CancelRegistry, NotKillable, TaskIdInUse
from .checkpoint import (
    Checkpoint,
    CheckpointMismatchError,
    dag_mismatch_msg,
    CheckpointStore,
    _stage_source_id,
    stage_input_hash,
    workflow_hash,
)
from .dag import CycleError, ConditionalEdge, DAG, Stage, UnknownDepError
from .policy import EnginePolicy
from .storage import CorruptRecordError
from .state import (
    ReadOnlyStateView,
    _validate_dict_keys,
    apply_overrides,
    deep_validate_state,
    merge_state,
    snapshot,
    StateConflictError,
)
from .types import (
    FatalError,
    PavozError,
    MaxVisitsExceeded,
    OrphanStagesError,
    RetryableError,
    RunResult,
    StageError,
    UnmappedRouteError,
)

logger = logging.getLogger("pavoz")


def _fmt_secs(t: float) -> str:
    """秒数的显示格式: 不足 1 秒保留 1 位小数, 否则取整。

    存在的理由是超时消息: `f"{0.3:.0f}"` 是 `"0"`, 于是 `timeout=0.3` 的 stage 超时
    会被报成 "超时 (0s)" —— 而 sub-second 预算恰恰是最常见的一档 (测试 / 交互式调参
    / 快速失败)。够 1 秒就取整 (`5` → `"5"`, `300` → `"300"`), 免得长 run 的日志里
    拖一堆 `.0`。
    """
    return f"{t:.1f}" if t < 1 else f"{t:.0f}"

_DEFAULT_STAGE_ALIVE_INTERVAL = 30.0  # 无 EnginePolicy 时的心跳间隔 (秒)

__all__ = ["CallMeta", "CallResult", "Ctx", "Runtime"]


async def _noop_caller(kind: str, op: str, params: dict, meta: CallMeta) -> dict:
    """默认 caller: no-op echo. 真调用由业务注入 (业务 adapter / TestPipe mock).

    必须是 async — Ctx.call 恒 await caller (sync fn 会被 await 崩 TypeError).
    """
    return CallResult(kind=kind, op=op, params=params)


def _start_stage_alive_hb(emit_fn, *, task_id: str, run_id: str, stage: str,
                          visit: int, attempt: int, interval: float
                          ) -> tuple[asyncio.Event, asyncio.Task]:
    """R2: stage_alive 心跳 task — 跑满 interval 后每 interval 发一条, stop.set() 即停.

    独立工厂而非调用点闭包: 调用点在重试 while 循环内, 闭包引用循环变量
    (attempt/visit 等) 会触发 B023 且生命周期纠缠; 显式传参一次绑定.
    """
    stop = asyncio.Event()
    t0 = time.time()

    async def _hb() -> None:
        while True:
            await asyncio.sleep(interval)
            if stop.is_set():
                return
            emit_fn("stage_alive", {
                "task_id": task_id, "run_id": run_id, "stage": stage,
                "visit": visit, "attempt": attempt,
                "elapsed": round(time.time() - t0, 3)})

    return stop, asyncio.create_task(_hb())


def _fill_error_context(result: RunResult, stage_name: str,
                        err_class: str | None, state: dict,
                        err_category: str | None = None) -> None:
    """W1 (0.5.3) + D1.5 (0.5.4): caller-friendly 错误上下文.

    失败/取消时填 failed_stage / retryable / state_summary / error_category —
    caller 接到 RunResult 即有"哪个 stage 错、能否重试、state 现场、业务类别",
    不必重跑诊断.
    """
    result.failed_stage = stage_name
    result.retryable = None if err_class is None else err_class in (
        "RetryableError", "TimeoutError")
    result.error_category = err_category
    try:
        result.state_summary = json.dumps(
            state, ensure_ascii=False, default=str)[:2048]
    except (TypeError, ValueError):
        result.state_summary = None


# pavoz **自己**抛的、且用户能据以行动的错误类型。
#
# 存在的理由 (2026-10-17 实测): 单 producer 契约被违反时 (`StateConflictError`),
# 用户在 stderr 上看到的是
#     task=t3 run=0ef27a3f stage=s_b 未预期异常
#     Traceback (most recent call last): ... merge_state ... raise StateConflictError
# 也就是 —— 一句**已经写给读者看**的消息 (它自带成因与建议: "改用不同 key (语义
# key)"), 被当程序 bug 再配一屏栈, 而"未预期"这个标签本身是**错的**: 单 producer 是
# 文档化的规则, 不是意外。
#
# 为什么显式列举而不是 `except PavozError`: 一半的库错误**并不**继承它 ——
# StateConflictError / CycleError / UnknownDepError / NotKillable / TaskIdInUse /
# CheckpointMismatchError / CorruptRecordError 都直接继承 Exception。让它们统一继承
# PavozError 是更彻底的解法, 但那会扩大第三方 `except PavozError` 的捕获范围 (已发布的包,
# 属 breaking), 不在本轮擅自做。
#
# 代价要认: 以后新增一个用户可处置的错误类型而忘了加进这个元组, 表现就是多一条
# traceback —— 不会算错, 只是吵。根治办法是统一基类 (见上)。
_EXPECTED_USER_ERRORS = (
    PavozError,                 # StageError/FatalError/RetryableError 已被更靠前的分支接走;
                           # 留基类是兜住同族将来新增的类型
    CheckpointMismatchError,
    CorruptRecordError,
    CycleError,
    NotKillable,
    StateConflictError,
    TaskIdInUse,
    UnknownDepError,
)

# checkpoint 里每条 attempt 记录的错误摘要上限. 异常消息可能极长 (整段 HTTP body、
# 千行文本), 而审计记录随每次 _save_cp 落盘 —— 截断而不是丢弃: 诊断需要的是开头
# 那一句; 完整消息仍在 RunResult.error / 事件流 / 日志里.
_ATTEMPT_ERROR_MAX = 500


@dataclass
class _RunLedger:
    """一次 run 的**全部可落盘累积器** —— `_save_cp` 的唯一入参.

    这些字段原先以 11 个位置参数、在 `_run_inner` 的 6 个保存点逐个重复传递。
    2026-10-18 加 `stage_attempts` 时必须在 6 处各改一次; 少传任何一处都只会
    静默丢数据, 而 run 仍然报成功 (判据 `test_checkpoint_attempts.py` 正是为此
    而写)。集中成一个对象后, 新增落盘字段只加在这里和 `Checkpoint` 两处,
    保存点不再各自持有参数列表.

    字段与 `Checkpoint` 的同名参数一一对应; `initial_state` 对应
    `Checkpoint.initial_state` (run 起始 state, state 重建用).
    """

    done_stages: list[str]
    stage_statuses: dict[str, str]
    producers: dict[str, str]
    stage_deltas_visits: dict[str, list[dict]]
    stage_attempts: dict[str, list[dict]]
    stage_ts: dict[str, float]
    initial_state: dict
    fork_overrides: dict
    stage_input_hashes: dict[str, str]
    reset_pending: set[str]
    stage_fn_sources: dict[str, str]
    fork_keep_counts: dict[str, int]
    stage_skipped: list[str]


def _attempt_record(visit: int, attempt: int, status: str, started: float,
                    error: BaseException | str | None = None) -> dict[str, Any]:
    """一条落盘用的 attempt 记录 (Checkpoint.stage_attempts 的元素).

    ts 是 attempt **开始**时刻 (epoch, 毫秒精度), duration_ms 是结束减开始 ——
    不含 retry 的退避 sleep。纯 dict 构造, 不读 state / 不调外部对象: 它在异常
    处理路径上被调用, 自己不能成为新的失败点。
    """
    return {
        "visit": visit,
        "attempt": attempt,
        "status": status,
        "ts": round(started, 3),
        "duration_ms": int((time.time() - started) * 1000),
        "error": None if error is None else str(error)[:_ATTEMPT_ERROR_MAX],
    }


def _find_orphan_and_stale(
    dag: DAG,
    cond_edges: dict[str, ConditionalEdge],
    last_route: dict[str, tuple[str, int]],
    run_exec_order: list[str],
    order: list[str],
    done_stages: list[str],
) -> tuple[str, OrphanStagesError] | None:
    """条件边图正常终止时, 检查"孤儿 stage"与"过期路由决策".

    返回 `(stage_name, error)` 或 None。**纯计算**: 不写 result / 不落盘 / 不发事件 ——
    那些副作用留给调用方 (`_fail_route` 是 `_run_inner` 里的闭包, 需要一堆 run 级状态)。
    从 `_run_inner` 拆出来的理由: 那块是 51 行自成一体的判定, 而 `_run_inner` 当时 544 行。

    R1 (0.5.5, ai@home id=270 BUG 2): 正常终止时若仍有声明 stage 从未执行、且没有任何
    *已执行* router 的 mapping 覆盖它, 说明路由图没闭合 (回路断了 / 分支挂空), 决不允许
    报 done。已执行 router 声明的 target 属"本次路由未选中", 是合法豁免 (如 judge 直接
    pass)。

    两条检查:
      (a) 覆盖检: 未执行 stage 必须被某个 *决策未过期* 的已执行 router 声明 (本次路由
          未选中 = 合法豁免); 否则是孤儿 (router 没人触发 / 分支挂空)。
      (b) 决策过期检: router 决策后只允许跑所选目标可达集内的 stage —— 分支外 stage 在
          决策后执行 = 回路没闭合, 旧决策已过期却无人重判, 其 mapping 不再构成豁免
          (ai@home id=270 v1 wiring: judge 判 revise 后 s_review 在分支外跑完, s_save
          永远不会被 ship 到 → 决不允许静默 done)。
    """
    reach = dag._execution_reach()  # 同包私有: n → 传递闭包 (静态+条件边)
    stale: dict[str, list[str]] = {}
    covered: set[str] = set()
    for rname, edge in cond_edges.items():
        if rname not in last_route:
            continue  # 未执行的 router 不构成豁免 (其目标若也没跑 → 孤儿)
        target, decided_at = last_route[rname]
        allowed = reach[target] | {target}  # 闭包不含自身, 补上所选目标
        strays = [m for m in run_exec_order[decided_at:] if m not in allowed]
        if strays:
            stale[rname] = strays
        else:
            # 被声明的分支**整体**豁免, 不只是 target 本身 —— 还有它的可达闭包
            # (2026-10-16)。只豁免 target 时, "分支目标带静态下游"的形状里那个下游既没人
            # 跑、又不在豁免名单里 → 被判孤儿, 于是**"选了某分支"这件事本身让 run 永远
            # failed**。实测 (与 _gated_by 那条同源): router 选 end, 而 s_d 是 go 分支
            # s_c 的静态下游, s_c/s_d 都不该跑, s_d 却被报成 orphan。
            # 与"只豁免 target"并不矛盾: target 既然合法地没跑, 属于同一个未选中分支的
            # 下游同理。
            for _t in edge.mapping.values():
                covered.add(_t)
                covered |= reach[_t]

    orphans = [n for n in order if n not in done_stages and n not in covered]
    if not (orphans or stale):
        return None
    detail = "; ".join(
        f"router '{r}' 决策 {last_route[r][0]!r} 后分支外执行了 "
        f"{ss} (回路未闭合, 无人重判)" for r, ss in stale.items())
    return (
        orphans[0] if orphans else next(iter(stale)),
        OrphanStagesError(
            f"条件边图终止不合法, run 不能报 done: 未执行 stage "
            f"{orphans or '无'}; {detail or '路由声明不足以覆盖未执行 stage'}. "
            f"常见原因: 回路未闭合 (分支终点没有边/路由接回判断链) "
            f"或 router 被 topo 意外入场所致的一次性决策"),
    )


class CallResult(dict):
    """ctx.call 的返回: 标准 dict, 业务 adapter 决定内容."""


@dataclass(frozen=True)
class CallMeta:
    """ctx.call 自动携带的执行上下文 — caller 记录 trace 用.

    caller 落 trace/llm_calls 时用它关联执行现场: task/run/stage/attempt.
    """

    task_id: str
    run_id: str
    stage: str
    attempt: int


@dataclass
class Ctx:
    """传给 stage 的上下文. read-only state + call/log API.

    stage 拿到的 ctx.state 是 run 级 state 的 deep copy (defensive) —
    改它不影响 run state; 真正的写入靠 return dict.
    """

    task_id: str
    run_id: str           # 每次 runtime.run() 一个 UUID4 (resume 复用)
    attempt: int          # 1-based, RetryableError retries 时 +1
    dag: DAG
    stage_name: str
    state: ReadOnlyStateView
    caller: Callable[[str, str, dict, CallMeta], Awaitable[dict]] = field(
        default=_noop_caller
    )
    logger: logging.Logger = field(default_factory=lambda: logger)
    deadline: float | None = None  # absolute deadline (time.time()), 无 = 不限制
    cancel_check: Callable[[], bool] | None = None  # v0.9: bound 到本 task 的取消检查
    on_event: Callable[[str, dict], None] | None = None  # R3: 进度心跳出口 (Runtime._emit)
    _last_progress: float | None = field(
        default=None, repr=False, compare=False)  # R3: 同 fraction 去抖

    def set_progress(self, fraction: float, note: str | None = None) -> None:
        """Stage 内可选进度心跳 (R3, 2026-09-10 ai-research PR).

        长 stage (分钟级 LLM 调用) 期间 "在算还是卡死" 的观测信号. 语义:
        - **best-effort 瞬态信号**: 只进 on_event 事件流 (stage_progress),
          **不写 checkpoint**, 不影响 deadline / 重试 / 取消语义, 无顺序送达保证.
        - 同 fraction 去抖 (引擎内, 一次比较); 未启用事件 (on_event=None) 时 no-op.
        - fraction 约定 0.0~1.0; note 自由文本 (如 "batch 3/10").
        """
        if self.on_event is None:
            return
        if self._last_progress is not None and fraction == self._last_progress:
            return
        self._last_progress = fraction
        self.on_event("stage_progress", {
            "task_id": self.task_id, "run_id": self.run_id,
            "stage": self.stage_name, "attempt": self.attempt,
            "fraction": fraction, "note": note,
        })

    async def call(self, kind: str, op: str, params: dict | None = None) -> dict:
        """Outbound call entry point. `kind` is opaque (caller-defined: 'llm', 'search', 'http', ...).

        Caller (via Runtime's caller injection) decides actual execution.
        Default is a no-op (suitable for TestPipe mocks and demos).
        """
        meta = CallMeta(
            task_id=self.task_id,
            run_id=self.run_id,
            stage=self.stage_name,
            attempt=self.attempt,
        )
        return await self.caller(kind, op, params or {}, meta)

    def cancelled(self) -> bool:
        """协作式取消轮询: True = caller 要求取消本 task.

        stage 内长循环 (批量 LLM 调用等) 自行决定轮询频率与退出方式 —
        runtime 只在 stage 边界强制拦截.
        checker 异常 → 视为未取消 (fail-open, 与 Runtime._is_cancelled 同语义).
        """
        if self.cancel_check is None:
            return False
        try:
            return bool(self.cancel_check())
        except Exception:
            self.logger.exception(
                "cancel_check 异常 (视为未取消) task=%s stage=%s",
                self.task_id, self.stage_name,
            )
            return False


@dataclass
class Runtime:
    """执行引擎. 每次 run 一个 task (可复用实例跑多个 task)."""

    checkpoint_store: CheckpointStore | None = None
    caller: Callable[[str, str, dict, CallMeta], Awaitable[dict]] | None = None
    default_timeout: float | None = None  # 整个 run 的 absolute deadline (秒)
    on_event: Callable[[str, dict], None] | None = None  # v0.9: 生命周期事件钩子
    cancel_check: Callable[[str], bool] | None = None  # v0.9: task_id → 已取消?
    debug_dir: str | None = None  # W2: 每 stage 后落 state 快照 JSON (调试)
    cancel_registry: CancelRegistry | None = None  # R1a: graceful|hard 取消登记处
    policy: EnginePolicy | None = None  # W3: run 级策略 (additive, 显式参数优先)
    _run_sem: asyncio.Semaphore | None = field(
        default=None, init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        """`default_timeout=0` 在**构造期**就拒 (2026-10-16).

        `_effective_timeout()` 返回 `self.default_timeout` (显式值优先于
        policy), 而调用点是 `run_deadline = time.time() + _to if _to else None`
        —— 真值判断。于是 `Runtime(default_timeout=0)` 被放行却**等于没设**:
        实测一个跑 0.3s 的 stage 跑满 0.30s 报 done, 而 0.1 报 TimeoutError。
        而 `default_timeout` 的全部意义就是给 LLM 调用封顶, "0 = 完全不管" 是
        最坏的失效方向 —— 用户以为护栏在, 实际可以无限烧。

        与 `EnginePolicy` 那侧同一处理: 只拒 0 (亚秒超时合法), `None` 才是"不限"。
        与 `@dag.stage(timeout=0)` 不同 —— 那边用 `is not None` 判断, 0 是**真值设置**
        ⇒ 超时生效 (failed), 是对的, 不受影响。注: 那边的 0 并非"立即", `_with_timeout`
        有 0.1s 下限 (`max(0.1, deadline - now)`), 即"至少给 0.1s"。
        """
        if self.default_timeout is not None and self.default_timeout == 0:
            raise ValueError(
                "Runtime.default_timeout 不能为 0 (got 0): 调用点按真值判断, "
                "0 会被当成'没设' ⇒ 超时护栏静默消失。不限请显式传 None"
            )

    # ── 并发闸 (W3 EnginePolicy.max_concurrent_runs) ──────
    @asynccontextmanager
    async def _run_slot(self):
        """并发闸: `EnginePolicy.max_concurrent_runs` — 无策略则不限并发。

        **run() 与 run_stage() 必须共用这一处**。曾只有 run() 内联走闸门,
        run_stage (单 stage 重放) 直接绕过 → 同一 policy 下 3 个 run 串行
        (peak=1)、3 个重放全并发 (peak=3), 而这个策略的全部意义就是护住共享
        下游 (限流 / 连接池): 重放打的是同一批 stage、同样的外部调用, 绕过
        等于上限没设 (2026-10-16 实测)。

        注: 闸门按调用计数, 故"stage 里回调本 Runtime 的 run/run_stage"在
        上限=1 时会自锁 —— 这是既有语义 (run() 一直如此), 不是本改动引入的;
        重入式用法不在支持范围内。
        """
        if not (self.policy and self.policy.max_concurrent_runs):
            yield
            return
        if self._run_sem is None:
            self._run_sem = asyncio.Semaphore(self.policy.max_concurrent_runs)
        async with self._run_sem:
            yield

    # ── 事件 ────────────────────────────────────────────
    def _emit(self, event: str, data: dict) -> None:
        """生命周期事件 → on_event 回调. observer 异常隔离 (log + 忽略), 不影响 run."""
        if self.on_event is None:
            return
        try:
            self.on_event(event, data)
        except Exception:
            logger.exception("on_event 回调异常 (忽略) event=%s", event)

    def _effective_timeout(self) -> float | None:
        """有效 run 级 deadline (秒): 显式 `Runtime(default_timeout=)` 优先,
        缺省回退到 `policy.default_timeout` (W3, id=1132 口径)。

        **必须只有这一处解析**。曾因 `run_stage()` (单 stage 重放) 各自内联读
        `self.default_timeout` 而漏掉 policy 回退, 导致同一份 EnginePolicy 在
        run() 上拦得住、在重放上完全失效 —— 且是静默的 (2026-10-16 实测:
        deadline=0.2s 时 run() 超时报 failed, 同一 policy 的 run_stage() 跑满
        1s 报 done)。fork_run 最终也走 run(), 故三个入口天然一致。
        """
        if self.default_timeout is not None:
            return self.default_timeout
        return self.policy.default_timeout if self.policy else None

    def _is_cancelled(self, task_id: str) -> bool:
        """查取消状态. checker 异常 → 视为未取消 (fail-open, 检查器 bug 不杀业务 run)."""
        if self.cancel_check is not None:
            try:
                if bool(self.cancel_check(task_id)):
                    return True
            except Exception:
                logger.exception("cancel_check 异常 (视为未取消) task=%s", task_id)
        if self.cancel_registry is not None:
            return self.cancel_registry.is_cancelled(task_id)
        return False

    # ── 主入口 ──────────────────────────────────────────
    async def run(
        self,
        dag: DAG,
        task_id: str | None = None,
        *,
        initial_state: dict | None = None,
        resume: bool = False,
        skip_unchanged: bool | None = None,
    ) -> RunResult:
        """执行 DAG 一次 run.

        Args:
            dag: 要执行的 DAG
            task_id: caller 提供的 task ID (省略 → 自动 UUID4). 跨 retry/resume
                     稳定 — 幂等键. resume 时必填 (自动生成的 ID 不会有 cp).
            initial_state: 起始 state (默认 {}; 仅在无已完成 stage 时注入 — resume
                     命中 cp 且 cp 已有完成 stage 时忽略, 初始值已含在 cp.state)
            resume: True → 从该 task 最新 checkpoint 续跑 (复用原 run_id).
                     无 cp / 已全部完成 → RuntimeError. 重跑用 resume=False.
            skip_unchanged: 覆盖 `EnginePolicy.skip_unchanged`; None (缺省) 用
                     policy 值. 只影响 resume / fork 的"输入未变则复用历史结果"
                     判定, 不影响首次执行.

        Returns:
            RunResult: 终态、最终 state、各 stage 状态与错误信息.

        Raises:
            CheckpointMismatchError: resume 时 DAG 结构变了 (workflow_hash 不匹配).
            RuntimeError: resume=True 但未配置 checkpoint_store, 无 cp, 或该 run
                已全部完成.
            ValueError: task_id 非法 (空 / 过长 / 含路径分隔符).
        """
        # task_id: 省略 → UUID4; 显式传值 → A3 校验 (直接进 storage key 路径)
        if task_id is None:
            task_id = new_id()
        _validate_task_id(task_id)
        # R1a: 登记运行句柄 (registry 硬杀靠它 cancel 本 asyncio Task)
        if self.cancel_registry is not None:
            _ct = asyncio.current_task()
            assert _ct is not None, "run() 协程体内必有 running task"
            self.cancel_registry._register(task_id, _ct)
        _cancelled = False      # 本次 run 是否以 cancelled 收场 (下面的 finally 用)
        try:
            _res = await self._run_impl(
                dag, task_id, initial_state, resume, skip_unchanged)
            _cancelled = _res.status == "cancelled"
            return _res
        finally:
            if self.cancel_registry is not None:
                self.cancel_registry._unregister(task_id, _ct)
                # 本次 run **没有**被取消 ⇒ 清掉残留的取消标志 (2026-10-16)。
                #
                # 标志的清除此前完全是 caller 的责任 (`CancelRegistry.reset`), 而
                # 留着的后果比"caller 忘了"严重得多 —— 它污染的是**下一个** run:
                # 实测 run#1 正常 done (取消请求到达得比收尾还晚), 紧接着 run#2
                # 用同一 task_id 启动, **一个 stage 都没跑**就被判 cancelled, 而
                # 上一轮的日志还写着"已落 cp, resume 可续跑"。那种"正常结束却
                # 带着取消标志"的组合只有竞态能造出来, 没有任何语义要保留它。
                #
                # 边界: 被取消的 run **保留**标志 —— 那是 caller 明确表达过的
                # 意图 (取消这个 task), 复用前由 caller 决定何时 reset。
                # 抛异常的路径 `_cancelled` 保持 False ⇒ 也清标志 (异常不是取消)。
                if not _cancelled:
                    self.cancel_registry._flags.discard(task_id)

    async def _run_impl(
        self,
        dag: DAG,
        task_id: str,
        initial_state: dict | None,
        resume: bool,
        skip_unchanged: bool | None,
    ) -> RunResult:
        """run() 的闸门层 (W3): task_id 已解析, registry 已登记."""
        # W3: 有效 deadline = 显式参数优先, 缺省看 policy; 绝对时刻在 _run_inner
        # 获得并发闸门后才起算 (排队不烧 deadline).
        eff_timeout = self._effective_timeout()
        async with self._run_slot():
            return await self._run_inner(
                dag, task_id, initial_state, resume, eff_timeout, skip_unchanged)

    async def _run_inner(
        self,
        dag: DAG,
        task_id: str,
        initial_state: dict | None,
        resume: bool,
        eff_timeout: float | None,
        skip_unchanged: bool | None,
    ) -> RunResult:
        """run() 主体 (W3 拆出): 并发闸门之内. 语义与拆分前完全一致.

        task_id 恒为 str — run() 已解析 UUID4 缺省 (_run_impl 签名同).
        """

        dag.validate()
        # DAG 结构指纹**整次 run 只算一次** (2026-10-17): 它是 dag 的纯函数, 而
        # `_save_cp` 每个 stage 都要写进 cp ⇒ 此前 N 个 stage 重算 N 次。
        # 160 stage 的线性 DAG profile: _save_cp 占 92% 运行时, 其中 workflow_hash
        # 占 31% —— 全花在重算一个常量上, 且**所有规模都按这个比例** (不是到几百个
        # stage 才出现的规模问题)。resume 的指纹校验复用同一个值。
        #
        # 不做"缓存到 dag 对象上": dag.validate() 已把 dag 冻结, run 期间结构根本
        # 不可能变 —— 但把值当**参数**传下去比加一层带失效语义的缓存更简单, 也没有
        # "陈旧指纹"这一类风险 (那正是这个函数存在的理由)。
        wf_hash = workflow_hash(dag)
        result = RunResult(task_id=task_id, dag_name=dag.name)

        # ── run_id: 每次 run 一个 UUID4; resume 复用 cp 的 run_id ──
        cp: Checkpoint | None = None
        if resume:
            if self.checkpoint_store is None:
                raise RuntimeError("resume=True requires checkpoint_store")
            cp = self.checkpoint_store.load_latest(task_id)
            if cp is None:
                raise RuntimeError(
                    f"task_id={task_id} 无 checkpoint, 不能 resume. 首次跑用 resume=False."
                )
            # done guard: topo 全覆盖 + 无 failed = 已完成 → 明确报错防静默 no-op
            topo = set(dag.topo_order())
            if topo <= set(cp.done_stages) and not any(
                s == "failed" for s in cp.stage_statuses.values()
            ):
                raise RuntimeError(
                    f"task_id={task_id} run={cp.run_id[:8]} 已全部完成. "
                    f"重跑请用 resume=False (起新 run_id)."
                )
            run_id = cp.run_id  # Continue-As-New: 跨 worker 重启同 run_id
        else:
            run_id = new_id()
        result.run_id = run_id

        state: dict[str, Any] = {}
        done_stages: list[str] = []
        stage_statuses: dict[str, str] = {}
        # v0.1.1 链式覆盖: state key → producer stage
        producers: dict[str, str] = {}
        # v0.5.1 (M2): 每 stage return delta (按完成序) + run 初始 state — M3 replay 重建用
        # R1 (0.5.5): 值改为 list — 循环多轮按 visit 追加 (见 stage_deltas_visits)
        stage_deltas_visits: dict[str, list[dict]] = {}
        # 0.5.9: stage 名 → 历次 attempt 记录 (耗时/错误摘要). 纯审计数据, 不参与
        # 执行决策; resume 续记 (见下方 resume 段).
        stage_attempts: dict[str, list[dict]] = {}
        # v0.7: stage 完成 epoch ts — 恢复侧 TTL 判定 (内容过期 gate) 用
        stage_ts: dict[str, float] = {}
        initial_state_saved: dict = {}
        # v0.8: fork overrides 随每次 save 携带 — fork_cp 首写外, resume 续跑
        # 的每轮 _save_cp 都必须带上, 否则 overrides 只活到第一次 save 就被丢
        _fork_overrides: dict = {}
        # R2 (0.5.3): stage 名 → 执行输入 hash, 随 cp 持久化 (fork skip_unchanged 用)
        input_hashes: dict[str, str] = {}
        # 被 skip_unchanged 跳过的 stage 名 (结果是从 cp 重放的, **没有真的跑**)。
        # 为什么单独记一份: `stage_statuses` 对它们记的是 "done" —— 与真跑过无法区分,
        # 而"我改的那一段到底跑没跑"恰恰是调试 skip_unchanged 时唯一的疑问。实测
        # (fork from s_a + skip_unchanged=True + 无 override): 三个 stage 全被跳过、
        # 一个 fn 都没被调用, 而 stage_statuses / done_stages 全是 done —— 从结果上看
        # 与一次完整跑**完全无法区分**。只有事件流 (stage_end status="skipped") 知道。
        stage_skipped: list[str] = []
        # fork_keep_counts 与 _fork_overrides 同理: 它标着"done_stages 里哪些条目属于
        # fork 截断点**之前**", 重建时靠它把重跑段与 visits 尾部对齐 (见
        # Checkpoint._rebuild_state)。此前 _save_cp 根本没有这个参数 → fork 续跑的
        # 每一次 save 都把它清空成 {} → 重建退化成"按出现顺序索引", 对截断点后的
        # 重跑集取到**最老**那条 delta: 链式 fork 的活跑结果对、落盘 cp 错
        # (ai@home id=3241, tests/test_chained_fork_rebuild.py 曾 xfail 钉住)。
        _kcounts: dict[str, int] = {}

        # ── resume: 恢复 checkpoint 状态 ──
        if cp is not None:
            cur_hash = wf_hash          # run 开头已算 (见上)
            if cp.workflow_hash != cur_hash:
                raise CheckpointMismatchError(dag_mismatch_msg(
                    task_id, cp, dag, action="DAG 结构变了, 不能 resume",
                    hint=" 如需强制重跑: 删 checkpoint 或 Runtime(..., resume=False)"))
            state = cp.state  # property: 从 deltas 重建 (v0.8 不落盘)
            done_stages = list(cp.done_stages)
            stage_statuses = dict(cp.stage_statuses)
            producers = dict(cp.producers)
            stage_deltas_visits = {k: list(v) for k, v in cp.stage_deltas_visits.items()}
            # resume 续收集 (R1: 按 visit 列表)
            stage_attempts = {k: [dict(rec) for rec in v]
                              for k, v in cp.stage_attempts.items()}
            stage_ts = dict(cp.stage_ts)              # v0.7: resume 续记
            initial_state_saved = dict(cp.initial_state)
            _fork_overrides = dict(cp.fork_overrides)  # fork 分支续保
            input_hashes = dict(cp.stage_input_hashes)  # R2: resume 续记
            stage_skipped = list(cp.stage_skipped)      # 跳过记录同样续记 (否则断点一续就丢)
            _kcounts = dict(cp.fork_keep_counts)        # fork 截断点标记: 续传 (见上)
            result.state = state
            logger.info(
                "task=%s run=%s resume: 已完成 %d stages",
                task_id, run_id[:8], len(done_stages),
            )

        # initial_state 仅在无已完成 stage 时注入 (resume 且 cp 已有完成 stage → 已含在 cp.state)
        if not done_stages and initial_state:
            state = merge_state({}, initial_state, "<init>")
            initial_state_saved = dict(initial_state)  # 存初始 (rebuild 需要)
            for _k in initial_state:
                producers[_k] = "<init>"
            result.state = state

        deep_validate_state(state)

        run_deadline = time.time() + eff_timeout if eff_timeout else None

        self._emit("run_start", {"task_id": task_id, "run_id": run_id,
                                 "dag": dag.name, "resume": cp is not None})

        order = dag.topo_order()
        # R1 (0.5.5): 条件边执行模型 — router stage 完成后由编排器求值 route_fn
        # 选下一跳 (节点纯数据处置, 边决策归编排器). route-only 目标 (分支目标 /
        # 无静态父的循环体) 只经路由触发, 不入 topo auto 推进集; 回路头 (有静态父)
        # 参与 topo 初始触发. 无条件边图: auto_order == order, 行为与 0.5.4 一致.
        cond_edges = dag.conditional_edges
        _route_only = dag.route_only_targets()
        auto_order = [n for n in order if n not in _route_only]
        # 每个 stage 的**闸门前置**: 它静态上游闭包里那些 route-only 节点.
        #
        # ⚠️ `_next_auto` 从表头扫第一个"没 done"的, **完全不看静态依赖**。无环图靠
        # 拓扑序兜住 (上游没 done 时下游不会是第一个); 一旦 route-only 节点被从
        # auto_order 剔除, 它的静态下游就**失去位置约束** → 跑到自己的闸门之前去。
        # 实测 (2026-10-16): `s_a → s_b → s_gate{go→s_c, end→s_fin}`, `s_c → s_d`,
        # router 选 end 时执行序是 `s_a s_b s_d s_gate s_fin` —— **s_d 在它的闸门
        # s_gate 之前就跑了**, s_c 一次没跑, s_d 读到的上游值是"从未执行"的默认,
        # 而 run 报 `status=done`、无异常无日志。更糟的是 `cp.state == 活跑`, 所以
        # 一致性类的不可变测试也抓不到它 (静默错的**最终形态**)。
        #
        # 为什么是"闸门检查"而不是把下游踢出 auto_order: 踢出去是**永久**的, 而
        # 下游在路由目标真到达后**应该**被 auto 推进 (实测踩过: 那样 go 分支下 s_d
        # 永远不跑)。按闸门状态判, 才是"上游 route-only 跑完就放行"。
        # `dag.stages` 是 property, **每次访问都 dict(self._stages) 建一份新副本**。
        # 下面两个热位置都别在循环里反复取它 (2026-10-17):
        #   · 这个 _gated_by 循环: 外层 N 个 stage × 内层祖先闭包 ⇒ O(N²) 次拷贝
        #   · 主执行循环 `stage = dag.stages[name]`: 每个 stage 一次 ⇒ 又是 O(N²)
        # 实测 640 stage 的线性 DAG: 光是这些 dict 拷贝就占 profile 的 4%, 而它随
        # DAG 规模平方增长 (n=320 时 2%)。一次拷贝提到循环外即可 ——
        # dag.validate() 已把 dag 冻结 (stage()/add_conditional_edges() 都会抛),
        # run 期间结构不变; 拷贝是**浅**的, Stage 对象共享, 所以 TestPipe 那种
        # 换 fn 的写法照样看得见。
        _all_stages: dict[str, Stage] = dag.stages
        _gated_by: dict[str, frozenset[str]] = {}
        for _n in order:
            _anc: set[str] = set()
            _stack = list(_all_stages[_n].depends_on)
            while _stack:
                _x = _stack.pop()
                if _x not in _anc:
                    _anc.add(_x)
                    _stack.extend(_all_stages[_x].depends_on)
            _gated_by[_n] = frozenset(_anc & _route_only)
        visits: dict[str, int] = {}  # stage 执行次数 (含 resume 历史; 循环重入累加)
        for n in done_stages:
            visits[n] = visits.get(n, 0) + 1
        run_exec_order: list[str] = []  # R1: 本 run 完成序 (决策过期检用, 不含历史)
        last_route: dict[str, tuple[str, int]] = {}  # router → (所选目标, 决策时完成数)
        # R2 (id=433 评审): route 重入待重跑集 — 回跳落点的静态下游闭包中被
        # done_stages 拦截的成员, _next_auto 视为可再执行; 该 stage 重新完成时移出.
        reset_pending: set[str] = set(cp.reset_pending) if cp is not None else set()
        # R2 (id=1132): 各 stage 上次真实执行的 fn 源码指纹 (fork/replay 漂移检查用)
        fn_sources: dict[str, str] = dict(cp.stage_fn_sources) if cp is not None else {}
        steps_used = 0  # W3: stage attempt 总数 (max_steps 熔断计数)
        # R2: skip_replay — 非 done 的 stage 若历史 status=done 且输入 hash
        # 命中 (fn 源码 + 执行前 state 均未变) → 重放历史 delta, 不重跑.
        # 只信历史 status="done" (失败 stage 永远重跑); 副作用 stage 用
        # Stage.skip_unchanged=False 拒跳.
        skip_replay = skip_unchanged if skip_unchanged is not None else (
            self.policy.skip_unchanged if self.policy else False)

        def _save() -> None:
            """唯一的 checkpoint 保存点 —— 累积器只在这里被打包一次.

            所有可变累积器都在本闭包的作用域里, 调用时按**当时**的值打包 (闭包
            捕获的是变量, 不是快照), 与原先在每个保存点逐个传参等价.
            """
            self._save_cp(task_id, run_id, dag, _RunLedger(
                done_stages=done_stages,
                stage_statuses=stage_statuses,
                producers=producers,
                stage_deltas_visits=stage_deltas_visits,
                stage_attempts=stage_attempts,
                stage_ts=stage_ts,
                initial_state=initial_state_saved,
                fork_overrides=_fork_overrides,
                stage_input_hashes=input_hashes,
                reset_pending=reset_pending,
                stage_fn_sources=fn_sources,
                fork_keep_counts=_kcounts,
                stage_skipped=stage_skipped,
            ), wf_hash)

        def _next_auto() -> str | None:
            for n in auto_order:
                if n in done_stages and n not in reset_pending:
                    continue  # done 且不在重入重跑集 → 真正完成过, 跳过
                # 闸门未过: 静态上游闭包里还有 route-only 节点没跑 ⇒ 这个 stage
                # 在图上只能被路由拉进来, 不能由 topo 推进抢先执行 (见 _gated_by)
                if any(d not in done_stages for d in _gated_by.get(n, ())):
                    continue
                return n
            return None

        def _fail_route(stage_name: str, exc: Exception, err_class: str) -> RunResult:
            """路由失败终态 (设计 §5): router 本身 done, run failed 落在 from_node.

            fail-loud — 无隐式重试无 fallback; error_class 保留原始类型
            (UnmappedRouteError / MaxVisitsExceeded / route_fn 自己的异常类).
            """
            result.status = "failed"
            result.error = str(exc)
            result.error_class = err_class
            result.failed_stage = stage_name
            _fill_error_context(result, stage_name, err_class, state)
            result.stage_statuses = stage_statuses
            result.state = state
            _save()
            self._emit("run_end", {"task_id": task_id, "run_id": run_id,
                                   "dag": dag.name, "status": "failed"})
            logger.warning(
                "task=%s run=%s 路由失败 at stage=%s: %s",
                task_id, run_id[:8], stage_name, exc,
            )
            return result

        def _eval_route(name: str) -> tuple[str | None, RunResult | None]:
            """求值 router 的条件边 → 目标 stage 名. 非 router → (None, None)."""
            edge = cond_edges.get(name)
            if edge is None:
                return None, None
            try:
                key = edge.route_fn(ReadOnlyStateView(state))
            except Exception as exc:
                # route_fn 自己的 bug → 原样传播 error_class (编排器不包装不吞)
                return None, _fail_route(name, exc, type(exc).__name__)
            if key not in edge.mapping:
                return None, _fail_route(
                    name,
                    UnmappedRouteError(
                        f"route_fn 返回未声明 key {key!r} (router '{name}', "
                        f"声明 keys={sorted(edge.mapping)})"),
                    "UnmappedRouteError",
                )
            to = edge.mapping[key]
            last_route[name] = (to, len(run_exec_order))  # 决策过期检锚点
            # R2: 重入 = 显式再入执行流 — 落点静态下游若已 done, 标记待重跑
            # (循环静态链第二圈全链重跑; router 链环闭包为空集, 行为不变)
            for _n in dag.static_closure(to):
                if _n in done_stages:
                    reset_pending.add(_n)
            # declared (R2, id=436 P1): mapping 全部 key — 本轮未选分支 =
            # declared - [key] 可读, mis-wiring / 静默 skip 第一轮可见
            self._emit("route", {"task_id": task_id, "run_id": run_id,
                                 "from": name, "key": key, "to": to,
                                 "declared": sorted(edge.mapping)})
            return to, None

        def _advance(name: str) -> tuple[str | None, RunResult | None]:
            """stage 完成后的下一跳: router → 条件边求值; 否则 topo auto 推进."""
            if name in cond_edges:
                return _eval_route(name)
            return _next_auto(), None

        # 起点: resume 且最后完成 stage 是 router → 按其条件边重路由 (route_fn
        # 纯函数, 同 state 同路由); 否则 topo auto 序首个未完成 stage
        current: str | None = None
        if cp is not None and done_stages and done_stages[-1] in cond_edges:
            current, fail = _eval_route(done_stages[-1])
            if fail is not None:
                return fail
        if current is None:
            current = _next_auto()

        while current is not None:
            name = current
            stage = _all_stages[name]      # 见上面 _all_stages 的说明 (别在循环里取 dag.stages)
            edge = cond_edges.get(name)

            # R1: router 执行次数上限 (条件回路的烧钱护栏). 分支-only 图不限.
            if edge is not None and edge.max_visits is not None \
                    and visits.get(name, 0) >= edge.max_visits:
                return _fail_route(
                    name,
                    MaxVisitsExceeded(
                        f"router '{name}' 已执行 {visits.get(name, 0)} 次 "
                        f"(max_visits={edge.max_visits})"),
                    "MaxVisitsExceeded",
                )

            # R2: 重放命中 (在 pre-exec 记录覆写 input_hashes 之前比对)
            if skip_replay and stage.skip_unchanged \
                    and stage_statuses.get(name) == "done" \
                    and input_hashes.get(name) == stage_input_hash(stage.fn, state):
                _dl = (stage_deltas_visits.get(name) or [{}])[-1]
                state.update(_dl)
                for _k in _dl:
                    producers[_k] = name
                done_stages.append(name)
                run_exec_order.append(name)
                reset_pending.discard(name)
                stage_skipped.append(name)
                result.stage_statuses = stage_statuses
                # 显式给出去: 否则 caller 只能靠事件流才知道这些 stage 没真跑
                result.skipped_stages = list(stage_skipped)
                result.state = state
                _save()
                self._emit("stage_end", {"task_id": task_id, "run_id": run_id,
                                         "stage": name, "attempt": 0, "visit": 0,
                                         "status": "skipped", "duration": 0.0,
                                         "error": None})
                logger.info(
                    "task=%s run=%s stage=%s 输入 hash 命中, 重放历史结果 (skip_unchanged)",
                    task_id, run_id[:8], name,
                )
                current, fail = _advance(name)
                if fail is not None:
                    return fail
                continue

            # W3: max_steps 熔断 — attempt 预算耗尽, 当前 stage 记 failed 终止
            if self.policy and self.policy.max_steps is not None \
                    and steps_used >= self.policy.max_steps:
                stage_statuses[name] = "failed"
                result.stage_statuses = stage_statuses
                result.state = state
                result.status = "failed"
                result.error = (
                    f"max_steps ({self.policy.max_steps}) exceeded at stage '{name}'"
                )
                result.error_class = "MaxStepsExceeded"
                _fill_error_context(result, name, "MaxStepsExceeded", state)
                _save()
                self._emit("run_end", {"task_id": task_id, "run_id": run_id,
                                       "dag": dag.name, "status": "failed"})
                logger.warning(
                    "task=%s run=%s max_steps=%d 熔断 at stage=%s",
                    task_id, run_id[:8], self.policy.max_steps, name,
                )
                return result

            # per-stage timeout: min(stage.timeout, remaining run deadline)
            stage_deadline: float | None = None
            if stage.timeout is not None:
                stage_deadline = time.time() + stage.timeout
            if run_deadline is not None:
                stage_deadline = (
                    min(stage_deadline, run_deadline) if stage_deadline is not None else run_deadline
                )

            _st0 = time.time()
            # R1a: 记当前 stage (含 killable) — registry 硬杀时判定可否杀
            if self.cancel_registry is not None:
                self.cancel_registry._set_stage(task_id, name, stage.killable)
            # R2: 执行前记输入指纹 —— 但只在**有人会读**时才算 (2026-10-17):
            # 它的两个读者是 ① checkpoint.stage_input_hashes (resume 的跳过判定
            # 与 diff_runs 的诊断) 与 ② run 循环内的"重放命中"判定 (仅 skip_replay
            # 为真时才走)。没有 store 时 ① 不存在, 且 skip_replay 默认 False
            # (`policy.skip_unchanged`, 没传 policy 就是 False) ⇒ 算了没人读。
            # 实测 30 stage × 100KB 的无 store run: _run_inner 共 0.206s, 其中
            # stage_input_hash 0.195s = **95%** —— 纯内存跑法 (TestPipe 就是) 在
            # 为一个不会落盘的字段付 95% 的运行时。
            if self.checkpoint_store is not None or skip_replay:
                input_hashes[name] = stage_input_hash(stage.fn, state)
            visit_no = visits.get(name, 0) + 1  # R1: 本次执行序 (1 起; 事件/retry 外层不变)
            # 0.5.9: 本次 stage 调用的 attempt 审计记录. 单独一个 list 再合并 ——
            # 硬杀 (CancelledError) 时代码不走正常返回路径, 这里要能把"被杀的那次"
            # 补进去; `_run_stage` 在每次 attempt 终态前 append (retry 也 append).
            attempt_log: list[dict] = []
            try:
                status, new_state, err, err_class, err_category, producers, delta, attempts = \
                    await self._run_stage(
                        dag, stage.fn, name, task_id, run_id, state, stage.retries,
                        stage_deadline, producers, visit=visit_no,
                        attempt_log=attempt_log,
                    )
            except asyncio.CancelledError:
                # R1a: registry 来源的硬杀 → 落 cp 返 cancelled RunResult;
                # 非 registry 来源 (外部 task.cancel) → 照旧上抛, 行为保持.
                #
                # ⚠️ 判据必须是"_is_killing" (本进程**确实**向这个 task 发过
                # t.cancel), 不能是 `is_cancelled` (仅仅"有取消标志") —— 后者被
                # 遗留标志骗过, 于是**外部**取消也被当成硬杀吞掉 (2026-10-16 实测):
                # 上一轮取消的标志还在, 本轮 `asyncio.wait_for(rt.run(...), 0.1)`
                # 超时抛来的 CancelledError 被转成 RunResult(status="cancelled"),
                # **TimeoutError 不抛** —— 调用方的超时保护静默失效, 而那通常是
                # 防止 run 无限挂着的最后一道防线。
                if self.cancel_registry is None \
                        or task_id not in self.cancel_registry._killing:
                    raise
                stage_statuses[name] = "cancelled"
                result.stage_statuses = stage_statuses
                result.state = state
                result.status = "cancelled"
                result.error = "killed (hard kill by CancelRegistry)"
                result.error_class = None
                _fill_error_context(result, name, None, state)
                # ★ 补 stage_end, 与已在流里的 stage_start 配对 (2026-10-16 修)。
                # 硬杀是在 stage **执行途中**注入 CancelledError, 它的 stage_start
                # 早就发出去了 —— 此前这里直接跳到 save_cp/run_end, 那个 stage 就
                # 永远停在"进行中"。消费方按配对算 in-flight 时会一直挂着它, 超时
                # 告警反复响, 而 runtime 侧其实早已把它标成 cancelled 并落了 cp。
                # visit 用 `visit_no` (本轮真实轮次, 上面算的); attempt 在这条路径上
                # **不可知** —— 它是 `_run_stage` 的返回值, 而异常在赋值生效前就抛出
                # 了 (第一版直接写 `attempts` → UnboundLocalError, 6 个测试红)。
                # 填 1: 硬杀后不会继续重试, 而消费方按 (stage, visit) 配对, 这个
                # 字段只用于排序。要精确 attempt 就得让 `_run_stage` 在抛出前把它
                # 挂到异常上, 那个改动不值当。
                self._emit("stage_end", {
                    "task_id": task_id, "run_id": run_id, "stage": name,
                    "attempt": 1,
                    "visit": visit_no,
                    "status": "cancelled",
                    "duration": time.time() - _st0,
                    "error": "killed (hard kill by CancelRegistry)",
                })
                # 审计记录: attempt 号 = 本 visit 已结束的 attempt 数 + 1 (retry 记录
                # 已在 sleep 前 append). 硬杀时拿不到本 attempt 的起点, 用 stage 调用
                # 起点代替 —— duration_ms 因此可能偏大 (含退避), 这是这条罕见路径上
                # 可接受的近似; 事件流的 duration 本来就是同一口径.
                attempt_log.append(_attempt_record(
                    visit_no, len(attempt_log) + 1, "cancelled", _st0,
                    "killed (hard kill by CancelRegistry)"))
                stage_attempts.setdefault(name, []).extend(attempt_log)
                _save()
                self._emit("run_end", {"task_id": task_id, "run_id": run_id,
                                       "dag": dag.name, "status": "cancelled"})
                logger.warning(
                    "task=%s run=%s hard-killed at stage=%s (已完成 %d stages 已落 cp; "
                    "取消标志仍在, 要续跑或复用该 task_id 先 registry.reset(task_id))",
                    task_id, run_id[:8], name, len(done_stages),
                )
                return result
            # 正常返回才走到这里 (硬杀分支已在上面合并并 return). 空 list 不建 key:
            # 取消拦截发生在 attempt 之前时没有记录, 不该凭空造一个空条目.
            if attempt_log:
                stage_attempts.setdefault(name, []).extend(attempt_log)
            steps_used += attempts
            result.stage_timings[name] = result.stage_timings.get(name, 0) + (
                time.time() - _st0)  # R1: 循环多轮累计 (单轮图数值不变)
            state = new_state
            stage_statuses[name] = status
            result.stage_statuses = stage_statuses
            result.state = state
            self._dump_debug(task_id, run_id, name, status, state,
                             time.time() - _st0)

            if status == "cancelled":
                result.status = "cancelled"
                result.error = err
                result.error_class = err_class
                _fill_error_context(result, name, err_class, state)
                result.stage_statuses[name] = "cancelled"
                self._emit("run_end", {"task_id": task_id, "run_id": run_id,
                                       "dag": dag.name, "status": "cancelled"})
                logger.warning(
                    "task=%s run=%s cancelled at stage=%s (已完成 %d stages 已落 cp; "
                    "要续跑或复用该 task_id, 先 registry.reset(task_id) —— "
                    "取消标志仍在, 不 reset 的新 run 会立刻再次 cancelled)",
                    task_id, run_id[:8], name, len(done_stages),
                )
                return result

            if status == "failed":
                result.status = "failed"
                result.error = err
                result.error_class = err_class
                _fill_error_context(result, name, err_class, state, err_category)
                _save()
                self._emit("run_end", {"task_id": task_id, "run_id": run_id,
                                       "dag": dag.name, "status": result.status})
                return result

            # **无条件**追加, 空 delta 也要占一条 (2026-10-16 修)。
            # 这两个列表必须逐条对齐: done_stages 的第 n 个条目 ↔
            # stage_deltas_visits[name] 的第 n 条。重建 (Checkpoint._rebuild_state)
            # 按**序号位置**配对; 之前这里 `if delta:` 让"返回 {} / None 的那次执行"
            # 只进 done 不进 deltas ⇒ 永久错位。
            #
            # 实测后果 (循环图 + 某次访问返回空 delta + 其间有链式覆盖同名 key):
            #   活跑   {'n': 2, 'k': 'W2', 'report': 'final=W2'}
            #   cp     {'k': 'P',  'n': 2, 'report': 'final=W2'}   ← cp 自相矛盾
            #   $ pavoz state --key k      → "P"
            #   $ pavoz state --key report → "final=W2"          ← 同一份文件, 两种答案
            # 无异常、无日志。代价只是每个空 visit 多一个 {} (几十字节)。
            stage_deltas_visits.setdefault(name, []).append(delta or {})  # R1: 按 visit 追加
            stage_ts[name] = time.time()   # v0.7: 完成时刻 (内容过期 TTL 判定用)
            done_stages.append(name)
            run_exec_order.append(name)
            reset_pending.discard(name)
            fn_sources[name] = _stage_source_id(stage.fn)  # 真实执行才更新 (重放不覆盖)
            visits[name] = visit_no
            _save()
            logger.info(
                "task=%s run=%s stage=%s done (len state=%d)",
                task_id, run_id[:8], name, len(state),
            )

            # R1: 下一跳 — router 走条件边, 其余 topo auto 推进 (循环重入 =
            # 路由再次命中, 不受 done_stages 拦)
            current, fail = _advance(name)
            if fail is not None:
                return fail

        # R1 (0.5.5, ai@home id=270 BUG 2): 孤儿检查 — 正常终止时若仍有声明
        # stage 从未执行、且没有任何 *已执行* router 的 mapping 覆盖它, 说明
        # 路由图没闭合 (回路断了 / 分支挂空), 决不允许报 done. 已执行 router
        # 声明的 target 属"本次路由未选中", 是合法豁免 (如 judge 直接 pass)。
        if cond_edges:
            bad = _find_orphan_and_stale(
                dag, cond_edges, last_route, run_exec_order, order, done_stages)
            if bad is not None:
                return _fail_route(bad[0], bad[1], "OrphanStagesError")

        result.status = "done"
        self._emit("run_end", {"task_id": task_id, "run_id": run_id,
                               "dag": dag.name, "status": result.status})
        return result

    # ── 单 stage 重放 (M3 调试) ─────────────────────────
    def get_state(self, task_id: str) -> dict:
        """查 task 最新 run 的全量 state (R1b, 0.5.3, 同步只读).

        rebuild 自 initial + deltas + fork overrides (Checkpoint.state property).
        无 checkpoint_store / 无 checkpoint → RuntimeError.
        """
        if self.checkpoint_store is None:
            raise RuntimeError("get_state requires checkpoint_store")
        cp = self.checkpoint_store.load_latest(task_id)
        if cp is None:
            raise RuntimeError(f"task_id={task_id} 无 checkpoint")
        return cp.state

    async def run_stage(
        self,
        dag: DAG,
        task_id: str,
        stage_name: str,
    ) -> RunResult:
        """重放单 stage: 用已保存 cp 重建其执行前 state, 只跑该 stage.

        调试用 (改 prompt/参数后秒级看效果, 不重跑前序 stage).
        - 不落 checkpoint / 不动 latest pointer (A6/A7: 防 replay 污染 resume 目标)
        - ctx.run_id = 新 UUID4 (临时重放 run 标识, 只活在本次调用)
        - stage 已完成过 → rebuild_state_before; 未完成但依赖已全完成
          (如原始 run 里失败的 stage) → rebuild_state; 依赖未完成 → 明确报错
        - 覆盖判定用"执行时点 producers" (随 state 重建, 不用 cp 终态
          producers) — chain-overwrite 下重放中间 stage 改写上游 key 不误报冲突

        Args:
            dag: DAG (须与 cp 的 workflow_hash 一致, 否则 CheckpointMismatchError)
            task_id: 已有 checkpoint 的 task
            stage_name: 要重放的 stage (已完成过, 或依赖已完成 — 才有 delta 可重建)

        Returns:
            RunResult: 只含该 stage 的状态; run_id 是本次临时重放的新 UUID4.

        Raises:
            RuntimeError: 未配置 checkpoint_store / 无 checkpoint / 依赖未完成.
            CheckpointMismatchError: DAG 结构变了 (workflow_hash 不匹配).
            KeyError: stage_name 不在 DAG 里.
        """
        # R2 (0.5.5, ai@home id=272): 条件边图单 stage replay 已支持 — 输入
        # 重建走 rebuild_state_before (完成序逐 visit 折叠到该 stage 首次执行前,
        # 循环图亦正确). 单点隔离调试: 改 prompt/参数后只重放该 stage 看输出,
        # 不动 checkpoint (不落盘, latest 指针不变).
        if self.checkpoint_store is None:
            raise RuntimeError("run_stage requires checkpoint_store")
        _validate_task_id(task_id)
        dag.validate()

        cp = self.checkpoint_store.load_latest(task_id)
        if cp is None:
            raise RuntimeError(
                f"task_id={task_id} 无 checkpoint, 不能重放. 先 run 一次."
            )
        cur_hash = workflow_hash(dag)
        if cp.workflow_hash != cur_hash:
            raise CheckpointMismatchError(
                f"task {task_id} run {cp.run_id[:8]} checkpoint 的 DAG hash "
                f"{cp.workflow_hash} ≠ 当前 DAG hash {cur_hash}. DAG 结构变了, "
                f"不能重放 (改依赖/retries/timeout 会变 hash)."
            )
        stage = dag.stages.get(stage_name)
        if stage is None:
            raise KeyError(f"stage '{stage_name}' 不在 DAG {dag.name} 里")

        # 无 stage_deltas 的 cp (旧版产物 / 手工残缺) → rebuild 静默给出空输入 → 明确报错
        # v0.8: state 不落盘, 检查不能依赖 cp.state (property 重建恒有值) — 只看 deltas
        if cp.done_stages and not cp.stage_deltas:
            raise RuntimeError(
                "checkpoint 无 stage_deltas — 旧版产物, 请重新 run 一次再重放"
            )

        # R2 (id=1132): 源码漂移可见化 — 与 fork_run 同款, 重放执行当前代码
        _src = cp.stage_fn_sources.get(stage_name)
        if _src and _src != _stage_source_id(stage.fn):
            logger.warning(
                "task=%s replay: stage '%s' 源码较 checkpoint 记录已变化 — "
                "本次重放执行当前代码", task_id, stage_name)

        # 重建 stage 执行前 state + 执行时点 producers (覆盖判定用 — 不是终态
        # cp.producers: chain-overwrite 下终态 producer 是后写者, 会误拒中间重放):
        # 已完成 → before; 未完成但依赖已全完成 (原始 run 失败/中断的 stage) →
        # 全量 merge done deltas (F2)
        if stage_name in cp.done_stages:
            state, producers = cp.rebuild_state_and_producers_before(stage_name)
        else:
            missing = [d for d in stage.depends_on if d not in cp.done_stages]
            if missing:
                raise RuntimeError(
                    f"stage '{stage_name}' 的依赖未完成 ({missing}), 无法重建其执行前 "
                    f"state. 先跑完整 run 或 resume."
                )
            state, producers = cp.rebuild_state_and_producers()

        run_id = new_id()  # 临时重放 run; 不落 cp
        result = RunResult(task_id=task_id, dag_name=dag.name, run_id=run_id)
        result.state = state

        _to = self._effective_timeout()
        run_deadline = time.time() + _to if _to else None
        stage_deadline: float | None = None
        if stage.timeout is not None:
            stage_deadline = time.time() + stage.timeout
        if run_deadline is not None:
            stage_deadline = (
                min(stage_deadline, run_deadline) if stage_deadline is not None
                else run_deadline
            )

        async with self._run_slot():
            status, new_state, err, err_class, err_category, _producers, _delta, _attempts = \
                await self._run_stage(
                    dag, stage.fn, stage_name, task_id, run_id, state, stage.retries,
                    stage_deadline, producers, emit=False,
                )
        result.state = new_state
        result.stage_statuses = {stage_name: status}
        if status == "failed":
            result.status = "failed"
            result.error = err
            result.error_class = err_class
            _fill_error_context(result, stage_name, err_class, new_state, err_category)
        elif status == "cancelled":
            result.status = "cancelled"
            result.error = err
            result.error_class = err_class
            _fill_error_context(result, stage_name, err_class, new_state, err_category)
        else:
            result.status = "done"
        return result

    # ── Fork (v0.6, LangGraph fork 范式): 取历史节点输入 → 改 → 装回续跑 ──────
    async def fork_run(
        self,
        dag: DAG,
        task_id: str,
        *,
        from_stage: str,
        overrides: dict | None = None,
        run_id: str | None = None,
        skip_unchanged: bool | None = None,
    ) -> RunResult:
        """从历史 run 的 from_stage 分支续跑: 前序 stage 结果复用 (不重跑),
        from_stage 及其后继用注入的 overrides 重跑. 原 run 的 checkpoint 不动,
        fork 的新 checkpoint (新 run_id) 成为 latest (LangGraph: fork is latest).

        overrides: 顶层 state key 覆盖, 注入到 from_stage 的执行前 state
        (与 checkpoint state 同为 json-serializable dict).

        调试闭环 (user 2026-09-06 拍板 "任意过去节点取输入改一改装回去"):
            pavoz export-input --task-id X --from-stage s_b > in.json
            # 人编辑 in.json (改几个 key)
            pavoz fork-run --task-id X --from-stage s_b --input in.json
        from_stage 可以是: ① 已完成的 stage (截断重跑) ② 失败/未完成的 stage
        (其依赖已完成 — 修输入重跑失败点, 等价注入式 resume).

        skip_unchanged (R2, 0.5.3): True 时从 from_stage 起沿 topo 序逐 stage
        比对输入 hash (stage_input_hash = fn 源码 + 执行前 state) — 命中且该
        stage 未标 skip_unchanged=False → 复用历史结果不重跑; 首个未命中处
        截断, 其后全部重跑. from_stage 退化为"起点提示" (自身 hash 命中也被
        跳过); overrides 注入会改变输入 hash → 必然重跑. None (缺省) 取
        EnginePolicy.skip_unchanged. 副作用 stage 请标 skip_unchanged=False,
        或自行保证幂等 — 跳过 = 副作用不发生.

        Returns: RunResult (fork run 的最终状态). 调用方可用 checkpoint
        state_stats / CLI state 查看 fork 分支.
        """
        if self.checkpoint_store is None:
            raise RuntimeError("fork_run requires checkpoint_store")
        _validate_task_id(task_id)
        cp = self.checkpoint_store.load_latest(task_id)
        if cp is None:
            raise RuntimeError(f"task {task_id} 无 checkpoint, 不能 fork")
        cur_hash = workflow_hash(dag)
        if cp.workflow_hash != cur_hash:
            raise CheckpointMismatchError(
                f"task {task_id} run {cp.run_id[:8]} checkpoint 的 DAG hash "
                f"{cp.workflow_hash} ≠ 当前 DAG hash {cur_hash}. DAG 结构变了, 不能 fork."
            )
        if from_stage not in dag.stages:
            raise KeyError(
                f"stage '{from_stage}' 不在 DAG {dag.name}: {list(dag.stages)}"
            )
        # R2 (0.5.5, ai@home id=272, user 铁律 "单点调试必须能跑"): 条件边图
        # fork = 截断到 from_stage 首次完成处 + overrides + 交给 resume 的
        # 路由续跑 (route-driven, 与 run(resume=True) 同一执行模型). from_stage
        # 必须已执行过 — 从未跑到的 stage 没有截断点, 明确拒绝 (路由图里
        # "从 X 重跑" 若 X 没跑过, 续跑路由可能根本不到 X).
        if dag.conditional_edges and from_stage not in cp.done_stages:
            raise RuntimeError(
                f"stage '{from_stage}' 未在该 task 执行过, 无截断点. "
                f"条件边图 fork 要求 from_stage 已完成 "
                f"(done_stages={cp.done_stages})"
            )
        missing = [d for d in dag.stages[from_stage].depends_on if d not in cp.done_stages]
        if missing:
            raise RuntimeError(
                f"stage '{from_stage}' 的依赖未完成 ({missing}), 无法重建其执行前 state."
            )

        # truncate: 保留 from_stage 之前 (run 为线性 topo 序 → done_stages 即执行序)
        keep = []
        for _d in cp.done_stages:
            if _d == from_stage:
                break
            keep.append(_d)

        # state 重建 = initial + 保留 deltas (完成序逐 visit) + overrides (最后生效).
        # R1: from_stage 已完成 → 折叠到其首次出现前 (visit 序 — 循环图取第 1 次
        # visit 的现场); from_stage 未执行过 (静态图失败点 fork) → 全量折叠 done
        # deltas. 折叠实现复用 Checkpoint — 不在 runtime 再写一份同序循环.
        if from_stage in cp.done_stages:
            state, producers = cp.rebuild_state_and_producers_before(from_stage)
        else:
            state, producers = cp.rebuild_state_and_producers()

        # R2 (id=1132): 源码漂移可见化 — fn 体不计 workflow_hash (改 prompt 免
        # 全链重跑是有意的), 但复用/重跑 stage 的代码可能已变. 漂移不阻断不拒续,
        # log 一行把"静默"变"可见": 重跑将执行当前代码, 复用的结果是旧代码产物.
        _drifted = [
            _n for _n in cp.stage_fn_sources
            if _n in dag.stages
            and cp.stage_fn_sources[_n] != _stage_source_id(dag.stages[_n].fn)
        ]
        if _drifted:
            logger.warning(
                "task=%s fork: 以下 stage 源码较 checkpoint 记录已变化: %s — "
                "重跑 stage 将执行当前代码; 复用 stage 的结果是旧代码产物",
                task_id, _drifted,
            )

        # R2: fork_cp 携带全量历史 (deltas/statuses/ts/hashes 含 from_stage 之后的)
        # — run 循环在 skip_unchanged 开启时逐 stage 比对, 命中即重放. done_stages
        # 仍截到 keep: 历史 status="done" 的条目由 run 循环重放判定, 失败/未跑的重跑.
        _skip = skip_unchanged if skip_unchanged is not None else (
            self.policy.skip_unchanged if self.policy else False)
        if overrides:
            # v0.9 深合并: v0.8 的 state.update 顶层浅替换会把嵌套 dict 的兄弟键抹掉
            # (--set llm.model=x → temperature/chain 全丢). apply_overrides 只覆盖
            # patch leaf, 兄弟键保留; nested dict 与 dot-path key dict 双格式等价.
            _validate_dict_keys(overrides)  # dunder/非法 key 在 runtime 边界拒绝
            state = apply_overrides(state, overrides)
            for _k in overrides:
                producers[_k] = "<fork>"  # 仍按顶层 override key 记 producer
        deep_validate_state(state)

        fork_cp = Checkpoint(
            task_id=task_id,
            run_id=run_id or new_id(),
            dag_name=cp.dag_name,
            workflow_hash=cur_hash,
            stage_statuses=dict(cp.stage_statuses),
            done_stages=keep,
            producers=producers,
            initial_state=dict(cp.initial_state),
            stage_deltas_visits={k: list(v) for k, v in cp.stage_deltas_visits.items()},
            stage_ts=dict(cp.stage_ts),
            # ⚠️ 只带**本次**的 overrides, 不合并 cp.fork_overrides —— 这是契约不是
            # 疏漏 (2026-10-16 实测钉的)。链式 fork 的祖先 override 是**注入输入**,
            # 早已被 from_stage 那次重跑消费掉了; 而新 cp 的 keep 段**不重跑**, 那些
            # stage 的产出已经定死。携带祖先 override 的后果不是"落盘与活跑分叉"
            # (实测: 合并后 runtime 与重建同源, 那个不变式**仍然成立**), 而是
            # keep 段的真实产出被一个本次 run 里没发生过的注入盖掉, 于是**结果开始
            # 依赖历史链** —— 同一份 (dag, from_stage, overrides), fork 之前的历史
            # 不同, 结果就不同:
            #   fork#1 from s_a, a=A9 → s_a 重跑覆盖回 'A'
            #   fork#2 from s_c (keep=[s_a,s_b]) → 活跑 a='A'  (契约)
            #   合并祖先后               → 活跑 a='A9'  (s_a 的产出没了)
            # 见 docs 的"链式 fork 不继承祖先 overrides"。
            fork_overrides=dict(overrides or {}),
            stage_input_hashes=dict(cp.stage_input_hashes),
            # **每个带 visits 的 stage 都要有条目** (缺的记 0), 不能只记 keep 里的:
            # 语义是"这个 stage 的 done 条目里, 有几条来自 fork 截断点之前"。只记
            # keep 的 stage ⇒ from_stage 及其下游拿不到条目 ⇒ 重建时 `kc is None`
            # 退化成顺序索引 ⇒ 对截断点后重跑集取到**最老**那条 delta
            # (ai@home id=3241; 实测: 活跑 C[F2], 落盘 cp 重建出 C[none])。
            # 从第一个 stage fork 时 keep 为空, 只记 keep 会得到空 dict —— 连
            # "这是 fork cp" 都识别不出来, 故必须显式记 0。
            fork_keep_counts={
                n: keep.count(n) for n in set(keep) | set(cp.stage_deltas_visits)
            },
            stage_fn_sources=dict(cp.stage_fn_sources),
        )
        self.checkpoint_store.save(fork_cp)  # save 同时把 latest 指针移到 fork
        logger.info(
            "task=%s fork from_stage=%s overrides_keys=%s run=%s (原 run %s, 复用 %d 个前序 stage)",
            task_id, from_stage, list(overrides or {})[:8],
            fork_cp.run_id[:8], cp.run_id[:8], len(keep),
        )
        # 续跑: resume=True 读 latest (= fork cp), 跳过 keep, 从 from_stage 顺序执行
        return await self.run(dag, task_id, resume=True, skip_unchanged=_skip)

    # ── 单 stage ────────────────────────────────────────
    async def _run_stage(
        self,
        dag: DAG,
        fn: Callable,
        name: str,
        task_id: str,
        run_id: str,
        state: dict,
        retries: int,
        stage_deadline: float | None,
        producers: dict[str, str],
        emit: bool = True,
        visit: int = 0,
        attempt_log: list[dict[str, Any]] | None = None,
    ) -> tuple[str, dict, str | None, str | None, str | None, dict, dict | None, int]:
        """跑一个 stage (含 retry). 返 (status, new_state, error, error_class, error_category, producers, delta, attempts).

        error_class = 原始异常类名 (R2): 未知异常保真 (业务 PipelineError ≠ 引擎
        FatalError, 消费者分诊用); StageError/FatalError → 自身类名; cancelled → None.

        error_category = caller raise 时传的业务类别 (D1.5, 0.5.4); 未传 /
        /cancelled → None. 透传到 RunResult.error_category.

        未知异常 (非 StageError/FatalError/RetryableError/TimeoutError) 走 FatalError
        语义 (fail, 不重试), 但**若它自带 .category 属性则照样透传** —— 不要求
        必须继承 StageError 才能携带 category (ai@home id=2925 提出: 此前泛型分支
        硬编码 None, 导致 UnmappedRouteError 这类"支持 category 却没继承
        StageError"的异常丢失分流信息, 消费方只能退回字符串匹配猜)。

        delta = stage 的 return dict (成功, 可能 {}), 失败 = None.
        ctx.attempt = 1-based 当前尝试次数, RetryableError 重试时 +1.
        attempts = 实际执行 attempt 总数 (W3 max_steps 熔断计数用).
        visit = 本 stage 在本 run 内的第几次执行 (R1, 1 起; 循环重入 >1) — 事件观测用.
        emit=False → 不发生命周期事件 (单 stage 重放不是正式 run).
        attempt_log: 传入 list 时, 每次 attempt 结束追加一条落盘记录 (见
        `_attempt_record`); None = 不记录 (单 stage 重放等不落 cp 的场景).
        记录在各终态**返回前**追加, 所以 retry 的记录也留得住.
        """
        attempt = 0
        _t0 = time.time()
        _record = attempt_log.append if attempt_log is not None else (lambda _rec: None)
        while True:
            if self._is_cancelled(task_id):
                logger.warning("task=%s run=%s stage=%s 取消拦截 (attempt 前)",
                               task_id, run_id[:8], name)
                if emit:
                    # ★ 必须**成对**发 start/end (2026-10-16 修)。此前这里只发
                    # stage_end, 于是一条从未开始的 stage 在事件流里凭空出现一个
                    # end —— 消费方按"start→end 配对"算 stage 耗时/成功率时会
                    # 多算一次"瞬间完成", 而那个 stage 根本没跑。
                    # attempt 用同一个值 (下面 `attempt += 1` 还没执行), 否则配不上对。
                    self._emit("stage_start", {"task_id": task_id, "run_id": run_id,
                                               "stage": name, "attempt": attempt,
                                               "visit": visit})
                    self._emit("stage_end", {"task_id": task_id, "run_id": run_id,
                                             "stage": name, "attempt": attempt,
                                             "visit": visit,
                                             "status": "cancelled",
                                             "duration": time.time() - _t0,
                                             "error": "cancelled by caller"})
                return "cancelled", state, "stage 已取消 (cancelled by caller)", None, None, producers, None, attempt
            attempt += 1
            _a0 = time.time()   # 本 attempt 的起点 — 记录用, 不含退避 sleep
            if emit:
                self._emit("stage_start", {"task_id": task_id, "run_id": run_id,
                                           "stage": name, "attempt": attempt,
                                           "visit": visit})
            try:
                # 每 attempt 深拷贝 state (防 stage 意外 mutate 污染后续重试)
                ctx = Ctx(
                    task_id=task_id,
                    run_id=run_id,
                    attempt=attempt,
                    dag=dag,
                    stage_name=name,
                    state=ReadOnlyStateView(snapshot(state)),
                    caller=self.caller or _noop_caller,
                    deadline=stage_deadline,
                    cancel_check=(lambda: self._is_cancelled(task_id)) if self.cancel_check else None,
                    on_event=(self._emit if emit else None),
                )
                # R2 (id=1128 提案): stage_alive 心跳 — 长 stage 无 fraction
                # 汇报时的存活信号. 首条在跑满 interval 后 (快 stage 零噪音),
                # stage 结束心跳即停; 单 stage 重放 (emit=False) 不发.
                hb_stop: asyncio.Event | None = None
                hb_task: asyncio.Task | None = None
                if emit:
                    hb_interval = (
                        self.policy.stage_alive_interval if self.policy
                        else _DEFAULT_STAGE_ALIVE_INTERVAL)
                    if hb_interval:
                        hb_stop, hb_task = _start_stage_alive_hb(
                            self._emit, task_id=task_id, run_id=run_id,
                            stage=name, visit=visit, attempt=attempt,
                            interval=hb_interval)
                try:
                    delta = await self._with_timeout(fn, None, ctx, stage_deadline, name, task_id)
                finally:
                    if hb_stop is not None and hb_task is not None:
                        hb_stop.set()
                        hb_task.cancel()
                        await asyncio.gather(hb_task, return_exceptions=True)
                if delta is None:
                    delta = {}
                if not isinstance(delta, dict):
                    raise FatalError(
                        f"stage '{name}' 必须返回 dict, got {type(delta).__name__}"
                    )
                deep_validate_state(delta)
                # v0.1.1 链式覆盖: producer 是当前 stage 传递上游 → 允许覆盖 (流水线演进).
                # R2 (id=272): "<fork>" 是 fork overrides 的伪 producer — 用户
                # 显式注入的调试输入, 续跑链上 stage 改写它 = "改输入 → 重跑产出
                # 新输出" 的正常流程, 不按平行 producer 拒. "<init>" 不豁免:
                # initial_state 同样受单 producer 契约保护 (caller 基线不被静默改).
                _ow = {
                    k for k in delta
                    if k in state and producers.get(k)
                    and (producers[k] == "<fork>"
                         or dag.reachable(producers[k], name))
                }
                new_state = merge_state(state, delta, name, overwrite_keys=_ow)
                for _k in delta:
                    producers[_k] = name
                if emit:
                    self._emit("stage_end", {"task_id": task_id, "run_id": run_id, "stage": name,
                                             "attempt": attempt, "visit": visit,
                                             "status": "done",
                                             "duration": time.time() - _t0, "error": None})
                _record(_attempt_record(visit, attempt, "done", _a0))
                return "done", new_state, None, None, None, producers, delta, attempt

            except (StageError, FatalError) as e:
                # 业务错误 / 程序 bug: 不重试
                logger.warning(
                    "task=%s run=%s stage=%s %s: %s",
                    task_id, run_id[:8], name, type(e).__name__, e,
                )
                if emit:
                    self._emit("stage_end", {"task_id": task_id, "run_id": run_id, "stage": name,
                                             "attempt": attempt, "visit": visit,
                                             "status": "failed",
                                             "duration": time.time() - _t0, "error": str(e)})
                _record(_attempt_record(visit, attempt, "failed", _a0, e))
                return "failed", state, str(e), type(e).__name__, getattr(e, "category", None), producers, None, attempt
            except (RetryableError, TimeoutError) as e:
                if attempt <= retries:
                    # v0.9: full jitter (AWS 惯例) — 多 task 同步重试防雷群
                    # W3: 退避上限走 EnginePolicy.backoff_max (缺省 30, 原硬编码)
                    _bmax = self.policy.backoff_max if self.policy else 30.0
                    backoff = random.uniform(0, min(2 ** (attempt - 1), _bmax))
                    logger.warning(
                        "task=%s run=%s stage=%s attempt=%d/%d %s, 退避 %ss: %s",
                        task_id, run_id[:8], name, attempt, retries + 1,
                        type(e).__name__, backoff, e,
                    )
                    if emit:
                        self._emit("stage_retry", {"task_id": task_id, "run_id": run_id,
                                                   "stage": name, "attempt": attempt,
                                                   "backoff": backoff, "error": str(e)})
                    # 记录的是**这次失败的 attempt**, 不是最终结果 — 落在 sleep 之前:
                    # 退避期间进程若被杀, 已发生的失败仍留在 checkpoint 里.
                    _record(_attempt_record(visit, attempt, "retry", _a0, e))
                    await asyncio.sleep(backoff)
                    continue
                logger.warning(
                    "task=%s run=%s stage=%s retries 耗尽: %s",
                    task_id, run_id[:8], name, e,
                )
                if emit:
                    self._emit("stage_end", {"task_id": task_id, "run_id": run_id, "stage": name,
                                             "attempt": attempt, "visit": visit,
                                             "status": "failed",
                                             "duration": time.time() - _t0, "error": str(e)})
                _record(_attempt_record(visit, attempt, "failed", _a0, e))
                return "failed", state, str(e), type(e).__name__, getattr(e, "category", None), producers, None, attempt
            except _EXPECTED_USER_ERRORS as e:
                # pavoz 自己抛的、用户能据以行动的错误 (见 _EXPECTED_USER_ERRORS)。
                # ⚠️ 返回值与下面的 catch-all 分支**逐字相同** (含 "FatalError: " 前缀)
                # —— 那个前缀被 tests/test_prune_error_progress.py 断言着并标注了
                # "API 冻结"。本分支只改**日志级别与措辞**, 不动任何调用方可见的字段。
                logger.warning(
                    "task=%s run=%s stage=%s %s: %s",
                    task_id, run_id[:8], name, type(e).__name__, e,
                )
                if emit:
                    self._emit("stage_end", {"task_id": task_id, "run_id": run_id,
                                             "stage": name, "attempt": attempt,
                                             "status": "failed",
                                             "duration": time.time() - _t0, "error": str(e)})
                _record(_attempt_record(visit, attempt, "failed", _a0, e))
                return "failed", state, f"FatalError: {e}", type(e).__name__, getattr(e, "category", None), producers, None, attempt
            except Exception as e:  # 未知异常 → FatalError 语义 (category 仍透传)
                logger.exception("task=%s run=%s stage=%s 未预期异常", task_id, run_id[:8], name)
                if emit:
                    self._emit("stage_end", {"task_id": task_id, "run_id": run_id, "stage": name,
                                             "attempt": attempt, "status": "failed",
                                             "duration": time.time() - _t0, "error": str(e)})
                _record(_attempt_record(visit, attempt, "failed", _a0, e))
                return "failed", state, f"FatalError: {e}", type(e).__name__, getattr(e, "category", None), producers, None, attempt

    # ── timeout wrapper ─────────────────────────────────
    async def _with_timeout(self, fn, _req_unused, ctx, deadline, name, task_id):
        """包 asyncio.wait_for. stage fn 签名 fn(ctx) — v1 统一 ctx-only."""
        if deadline is None:
            return await fn(ctx)
        timeout = max(0.1, deadline - time.time())
        try:
            return await asyncio.wait_for(fn(ctx), timeout=timeout)
        except TimeoutError:
            # ⚠️ 精度: 这里曾用 `{timeout:.0f}` —— 于是 `timeout=0.3` 的超时被报成
            # "超时 (0s)"。实测 (stage 睡 1.0s, timeout=0.3): 0.30s 就失败, 消息却是
            # "(0s)"。用户读到"0s"会去找"是不是超时配成了 0"这种根本不存在的问题,
            # 而真实原因是**他的预算只有 0.3 秒、不够这个 stage 跑**。凡是 sub-second
            # 的预算, 消息里不写小数就等于在最基本的场景里说错话。
            raise TimeoutError(f"stage '{name}' 超时 ({_fmt_secs(timeout)}s)") from None

    # ── checkpoint ──────────────────────────────────────
    def _dump_debug(self, task_id: str, run_id: str, stage: str,
                    status: str, state: dict, duration: float) -> None:
        """W2 (0.5.3): debug_dir 每 stage 快照. 失败不杀 run (与 _save_cp 同语义)."""
        if self.debug_dir is None:
            return
        try:
            d = os.path.join(self.debug_dir, task_id)
            os.makedirs(d, exist_ok=True)
            seq = len([f for f in os.listdir(d) if f.endswith(".json")])
            path = os.path.join(d, f"{seq:02d}_{stage}_{status}.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"task_id": task_id, "run_id": run_id, "stage": stage,
                           "status": status, "duration": duration, "state": state},
                          f, ensure_ascii=False, default=str)
        except Exception:
            logger.exception("debug_dir 落盘失败 (non-fatal) task=%s stage=%s",
                             task_id, stage)

    def _save_cp(self, task_id: str, run_id: str, dag: DAG,
                 ledger: _RunLedger, wf_hash: str | None = None) -> None:
        """把 `_RunLedger` 落成 checkpoint (无 store 时 no-op; 失败不杀 run).

        唯一的序列化点 —— 新增落盘字段只需改 `Checkpoint` 与 `_RunLedger`,
        不再需要在各保存点逐个补参数 (那正是 `stage_attempts` 之前的结构性
        风险: 少传一处 = 静默丢数据, run 仍报成功).
        """
        if self.checkpoint_store is None:
            return
        try:
            cp = Checkpoint(
                task_id=task_id,
                run_id=run_id,
                dag_name=dag.name,
                # wf_hash 由调用点整次 run 算一次传下来 (见 _run_inner 的说明);
                # None = 自己算 (run_stage / fork_run / 库调用等单次场景)
                workflow_hash=wf_hash if wf_hash is not None else workflow_hash(dag),
                stage_statuses=dict(ledger.stage_statuses),
                done_stages=list(ledger.done_stages),
                producers=dict(ledger.producers),
                initial_state=dict(ledger.initial_state),
                stage_deltas_visits={
                    k: list(v) for k, v in ledger.stage_deltas_visits.items()},
                stage_ts=dict(ledger.stage_ts),
                fork_keep_counts=dict(ledger.fork_keep_counts),
                fork_overrides=dict(ledger.fork_overrides),
                stage_input_hashes=dict(ledger.stage_input_hashes),
                stage_skipped=list(ledger.stage_skipped),
                reset_pending=sorted(ledger.reset_pending),
                stage_fn_sources=dict(ledger.stage_fn_sources),
                stage_attempts={k: [dict(rec) for rec in v]
                                for k, v in ledger.stage_attempts.items()},
            )
            self.checkpoint_store.save(cp)
        except Exception:
            logger.exception(
                "task=%s run=%s checkpoint 保存失败 (non-fatal)", task_id, run_id[:8]
            )


def _validate_task_id(task_id: str) -> None:
    """task_id 直接进 storage key 路径 — 必须无 '/' 且字符集受限."""
    if not task_id:
        raise ValueError("task_id 不能为空")
    if len(task_id) > 128:
        raise ValueError(f"task_id 过长: {len(task_id)} > 128")
    # `.` 在允许字符集内 (合法名字要用: "v1.0-rc.1" / "a..b" / ".hidden"), 但
    # **整段等于 `.` 或 `..` 时它不是名字, 是路径操作** —— 而 task_id 会被直接
    # 当路径段拼进 debug_dir (`os.path.join(debug_dir, task_id)`), 也拼进 storage
    # key。2026-10-16 实测: `Runtime(debug_dir=D).run(dag, "..")` status=done,
    # 快照 `00_s_a_done.json` 落在 **D 的外面**; `"."` 则落在 D 根, 与各 task
    # 子目录混在一起。storage 侧因 key 走哈希而侥幸没出事, 但 debug 侧没有第二道
    # 防护 —— 所以在这里拒, 一处封住三个入口 (run / fork_run / run_stage)。
    #
    # 判据是"**整段**等于 . 或 ..", 不是"含 '..'": `a..b` / `..a` / `.hidden`
    # 都是正常名字, 按含子串去拒会把它们一起杀掉。
    if task_id in (".", "..") or set(task_id) == {"."}:
        raise ValueError(
            f"task_id {task_id!r} 全是点 — 它是相对路径操作 (当前目录/父目录), "
            f"不是名字。task_id 会直接进文件路径 (debug_dir / storage key), "
            f"用它会把文件写到目标目录之外。换个名字。"
        )
    # str.isalnum() 认 Unicode 字母 (如 "任务" isalpha=True) — 必须显式 ASCII-only
    if not all(c.isascii() and (c.isalnum() or c in "_.-") for c in task_id):
        raise ValueError(
            f"task_id 含非法字符: {task_id!r}. 只允许 [A-Za-z0-9_.-] "
            f"(不含 '/', 防止 storage key 路径注入)"
        )

